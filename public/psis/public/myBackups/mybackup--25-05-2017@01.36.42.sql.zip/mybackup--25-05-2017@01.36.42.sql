--
-- Database : db_panhasastra
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `ln_currency`
--
DROP TABLE  IF EXISTS `ln_currency`;
CREATE TABLE `ln_currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `curr_namekh` varchar(255) DEFAULT NULL,
  `curr_nameen` varchar(120) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL COMMENT '1kh,2=en',
  `country_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '1=active,0deactive',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `ln_currency`  VALUES ( "1","??????","Dollar","$","","1","1");
INSERT INTO `ln_currency`  VALUES ( "2","???","Riel","R","","2","1");
INSERT INTO `ln_currency`  VALUES ( "3","???","Bath","B","","3","1");


--
-- Tabel structure for table `ln_expense`
--
DROP TABLE  IF EXISTS `ln_expense`;
CREATE TABLE `ln_expense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `invoice` varchar(30) DEFAULT NULL,
  `curr_type` int(11) DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL COMMENT 'date input',
  `status` tinyint(4) DEFAULT '1' COMMENT '1 = use,0 = un use',
  `user_id` int(11) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ln_expense`  VALUES ( "1","3","aksok","0001","1","20","","2016-12-09","1","25","2016-12-09");
INSERT INTO `ln_expense`  VALUES ( "2","1","Salary","0001","1","1000","","2017-02-01","1","28","2017-02-01");
INSERT INTO `ln_expense`  VALUES ( "3","1","new","0003","1","50","","2017-02-04","1","28","2017-02-04");


--
-- Tabel structure for table `ln_income`
--
DROP TABLE  IF EXISTS `ln_income`;
CREATE TABLE `ln_income` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `invoice` varchar(30) DEFAULT NULL,
  `curr_type` int(11) DEFAULT NULL,
  `total_amount` float(12,2) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL COMMENT 'date input',
  `status` tinyint(4) DEFAULT '1' COMMENT '1use,1unuse',
  `user_id` int(11) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `ln_income`  VALUES ( "1","3","sdgsd","32r23r","1","3523.00","","2016-12-09","1","25","2016-12-09");
INSERT INTO `ln_income`  VALUES ( "2","3","testttt","0002","2","10000.00","new test","2016-12-09","1","25","2016-12-09");
INSERT INTO `ln_income`  VALUES ( "3","1","Other","0001","1","20.00","","2017-02-01","1","28","2017-02-01");
INSERT INTO `ln_income`  VALUES ( "4","1","ttt","0004","1","100.00","","2017-02-04","1","28","2017-02-04");
INSERT INTO `ln_income`  VALUES ( "5","1","a","0005","1","200.00","","2017-03-10","1","28","2017-03-10");


--
-- Tabel structure for table `ln_income_expense`
--
DROP TABLE  IF EXISTS `ln_income_expense`;
CREATE TABLE `ln_income_expense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `account_id` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `invoice` varchar(30) DEFAULT NULL,
  `curr_type` int(11) DEFAULT NULL,
  `total_amount` float(12,2) DEFAULT NULL,
  `fordate` int(11) DEFAULT NULL COMMENT '1to 12',
  `disc` text,
  `transaction_date` date DEFAULT NULL COMMENT 'transaction',
  `date` date DEFAULT NULL COMMENT 'date input',
  `status` tinyint(4) DEFAULT '1' COMMENT '1use,1unuse',
  `user_id` int(11) DEFAULT NULL,
  `tran_type` tinyint(4) DEFAULT NULL COMMENT '1 expense,2 income',
  `amount_in_kh` float(10,2) DEFAULT NULL,
  `amount_in_dollar` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_system_setting`
--
DROP TABLE  IF EXISTS `ln_system_setting`;
CREATE TABLE `ln_system_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keycode` varchar(150) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `ln_system_setting`  VALUES ( "1","work_saturday","1","1=work on saturday 0 not work");
INSERT INTO `ln_system_setting`  VALUES ( "2","work_sunday","1","1=work on sunday 0 not work");
INSERT INTO `ln_system_setting`  VALUES ( "3","servername","localhost","");
INSERT INTO `ln_system_setting`  VALUES ( "4","dbuser","root","");
INSERT INTO `ln_system_setting`  VALUES ( "5","dbpassword","","");
INSERT INTO `ln_system_setting`  VALUES ( "6","dbname","db_panhasastra","");
INSERT INTO `ln_system_setting`  VALUES ( "7","adminfee","1","10% of loan amount");
INSERT INTO `ln_system_setting`  VALUES ( "8","interest_late","2","????????????????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "9","graice_pariod_late","2","???????????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "10","reschedule_postfix","R","?????????????????????????????????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "11","claro","Claro","");
INSERT INTO `ln_system_setting`  VALUES ( "12","nihilo","Nihilo","");
INSERT INTO `ln_system_setting`  VALUES ( "13","soria","Soria","");
INSERT INTO `ln_system_setting`  VALUES ( "14","tundra","tundra","");
INSERT INTO `ln_system_setting`  VALUES ( "15","theme_setting","1","");
INSERT INTO `ln_system_setting`  VALUES ( "17","send_teller","1","??????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "18","co_prefix","1","");


--
-- Tabel structure for table `mrs_program_fee`
--
DROP TABLE  IF EXISTS `mrs_program_fee`;
CREATE TABLE `mrs_program_fee` (
  `id` int(11) DEFAULT NULL,
  `start_year` varchar(100) DEFAULT NULL,
  `end_year` varchar(100) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `study_type` tinyint(4) DEFAULT NULL,
  `note` mediumtext,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `mrs_programfee_detail`
--
DROP TABLE  IF EXISTS `mrs_programfee_detail`;
CREATE TABLE `mrs_programfee_detail` (
  `id` int(11) DEFAULT NULL,
  `programfeeid` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `total_hour` int(11) DEFAULT NULL,
  `fee` float DEFAULT NULL,
  `pay_type` tinyint(4) DEFAULT NULL,
  `note` mediumtext,
  `status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_academicperiod`
--
DROP TABLE  IF EXISTS `rms_academicperiod`;
CREATE TABLE `rms_academicperiod` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fromyear` varchar(50) DEFAULT NULL,
  `toyear` varchar(50) DEFAULT NULL,
  `batch` varchar(100) DEFAULT NULL,
  `study_start` varchar(20) DEFAULT NULL,
  `study_end` varchar(20) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `note` text,
  `status` tinyint(4) DEFAULT NULL,
  `quarter_start` varchar(20) DEFAULT NULL,
  `quarter_end` varchar(20) DEFAULT NULL,
  `semester_start` varchar(20) DEFAULT NULL,
  `semester_end` varchar(20) DEFAULT NULL,
  `yearly_start` varchar(20) DEFAULT NULL,
  `yearly_end` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_academicperiod`  VALUES ( "1","2014","2015","12","2016-03-05","2016-08-05","5","aaa","1","2016-03-01","2016-03-31","2016-03-05","2016-03-26","2016-03-02","2016-03-31","1","Mar 1, 2016 2:14:35 ");


--
-- Tabel structure for table `rms_acl_acl`
--
DROP TABLE  IF EXISTS `rms_acl_acl`;
CREATE TABLE `rms_acl_acl` (
  `acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '1: display in menu; 0: disable from menu',
  `rank` int(11) DEFAULT NULL COMMENT 'rank to show in submenu',
  `label` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`acl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO `rms_acl_acl`  VALUES ( "1","rsvacl","acl","add","1","1","");
INSERT INTO `rms_acl_acl`  VALUES ( "2","rsvacl","acl","edit","1","2","");
INSERT INTO `rms_acl_acl`  VALUES ( "3","rsvacl","acl","index","1","3","");
INSERT INTO `rms_acl_acl`  VALUES ( "4","rsvacl","user","add","1","4","");
INSERT INTO `rms_acl_acl`  VALUES ( "5","rsvacl","user","edit","1","5","");
INSERT INTO `rms_acl_acl`  VALUES ( "6","rsvacl","user","index","1","6","");
INSERT INTO `rms_acl_acl`  VALUES ( "7","rsvacl","useraccess","add","1","7","");
INSERT INTO `rms_acl_acl`  VALUES ( "8","rsvacl","useraccess","edit","1","8","");
INSERT INTO `rms_acl_acl`  VALUES ( "9","rsvacl","useraccess","index","1","9","");
INSERT INTO `rms_acl_acl`  VALUES ( "37","rsvacl","usertype","add","1","","");
INSERT INTO `rms_acl_acl`  VALUES ( "38","rsvacl","usertype","edit","1","","");
INSERT INTO `rms_acl_acl`  VALUES ( "39","rsvacl","usertype","index","1","","");


--
-- Tabel structure for table `rms_acl_user_access`
--
DROP TABLE  IF EXISTS `rms_acl_user_access`;
CREATE TABLE `rms_acl_user_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user_type_id` (`user_type_id`),
  KEY `acl_id` (`acl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

INSERT INTO `rms_acl_user_access`  VALUES ( "1","1","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "4","2","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "5","3","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "6","4","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "7","5","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "8","6","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "9","7","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "10","8","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "11","9","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "12","10","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "13","11","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "14","12","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "15","13","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "16","14","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "17","15","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "18","16","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "19","17","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "20","18","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "21","19","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "22","20","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "23","21","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "24","22","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "25","23","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "26","24","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "27","10","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "28","11","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "29","12","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "30","13","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "31","14","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "32","15","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "33","19","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "34","20","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "35","21","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "36","22","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "37","23","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "38","24","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "39","19","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "40","20","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "41","21","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "42","25","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "43","26","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "44","27","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "45","28","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "46","29","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "47","25","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "48","26","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "49","27","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "50","28","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "51","29","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "52","25","4","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "53","26","4","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "54","27","4","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "55","28","5","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "56","25","5","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "57","29","4","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "58","30","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "59","31","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "60","32","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "61","33","1","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "62","33","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "63","32","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "64","31","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "65","30","2","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "66","22","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "67","23","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "68","31","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "69","24","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "70","33","3","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "71","32","4","1");
INSERT INTO `rms_acl_user_access`  VALUES ( "72","30","4","1");


--
-- Tabel structure for table `rms_acl_user_type`
--
DROP TABLE  IF EXISTS `rms_acl_user_type`;
CREATE TABLE `rms_acl_user_type` (
  `user_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(50) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`user_type_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `rms_acl_user_type`  VALUES ( "1","Admin","0","1");
INSERT INTO `rms_acl_user_type`  VALUES ( "2","Manager","0","1");
INSERT INTO `rms_acl_user_type`  VALUES ( "3","Branch Manager","0","1");
INSERT INTO `rms_acl_user_type`  VALUES ( "4","Receptionist","0","1");
INSERT INTO `rms_acl_user_type`  VALUES ( "5","Deputy Branch Manager","0","1");


--
-- Tabel structure for table `rms_attendent`
--
DROP TABLE  IF EXISTS `rms_attendent`;
CREATE TABLE `rms_attendent` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `academic_id` int(11) DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_attendent_detail`
--
DROP TABLE  IF EXISTS `rms_attendent_detail`;
CREATE TABLE `rms_attendent_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `attd_id` int(11) DEFAULT NULL COMMENT 'id from attendent',
  `student_id` int(11) DEFAULT NULL COMMENT 'student id form studnet group_id',
  `student_code` varchar(50) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `grade_id` tinyint(4) DEFAULT NULL,
  `permission` int(11) DEFAULT NULL COMMENT '0=not permission,1=yes permission',
  `time_check` varchar(50) DEFAULT NULL,
  `note` text,
  `amount_stop` int(11) DEFAULT NULL COMMENT '?????????????',
  `att_type` tinyint(4) DEFAULT NULL COMMENT '0=out come, 1=come',
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_branch`
--
DROP TABLE  IF EXISTS `rms_branch`;
CREATE TABLE `rms_branch` (
  `br_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_namekh` varchar(200) DEFAULT NULL,
  `branch_nameen` varbinary(100) DEFAULT NULL,
  `br_address` varchar(100) DEFAULT NULL,
  `branch_code` varchar(100) DEFAULT NULL,
  `branch_tel` varchar(100) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `other` varchar(100) DEFAULT NULL,
  `prefix` varchar(10) DEFAULT NULL COMMENT '??????????? ??????????????',
  `status` tinyint(4) DEFAULT '1',
  `displayby` tinyint(4) DEFAULT '2',
  PRIMARY KEY (`br_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_branch`  VALUES ( "1","dfas","ស្ទឹងមានជ័យ2","Building#2D, Street 371 Trea Village, Sangkat Steung Meanchey, Khan Meanchey, Phnom Penh, Cambodia","C-001","023 631 6857, 017 68 34 75","10243015","","SMC","1","2");


--
-- Tabel structure for table `rms_car`
--
DROP TABLE  IF EXISTS `rms_car`;
CREATE TABLE `rms_car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carid` int(10) NOT NULL,
  `carname` varchar(30) DEFAULT NULL,
  `drivername` varchar(50) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `zone` varchar(100) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `status` varchar(5) DEFAULT '1',
  PRIMARY KEY (`carid`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_car`  VALUES ( "1","11","camry","sss","2345678","pp","sdfghj","1","1");


--
-- Tabel structure for table `rms_degree_language`
--
DROP TABLE  IF EXISTS `rms_degree_language`;
CREATE TABLE `rms_degree_language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modify_date` date NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1= active, 0= deactive',
  `user_id` int(11) NOT NULL,
  `note` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `rms_degree_language`  VALUES ( "1","Upper-intermediate","2016-09-28","1","1","");
INSERT INTO `rms_degree_language`  VALUES ( "2","Advanced","2016-09-20","1","1","");
INSERT INTO `rms_degree_language`  VALUES ( "3","Intermediate","2016-09-20","1","1","");
INSERT INTO `rms_degree_language`  VALUES ( "4","Pre-Intermediate ","2016-09-20","1","1","");
INSERT INTO `rms_degree_language`  VALUES ( "5","Beginner ","2016-09-20","1","1","");
INSERT INTO `rms_degree_language`  VALUES ( "6","Starter","2016-07-18","1","1","");


--
-- Tabel structure for table `rms_dept`
--
DROP TABLE  IF EXISTS `rms_dept`;
CREATE TABLE `rms_dept` (
  `dept_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `en_name` varchar(100) NOT NULL,
  `kh_name` varchar(100) NOT NULL,
  `shortcut` varchar(20) DEFAULT NULL COMMENT 'shortcut of term',
  `modify_date` varchar(30) NOT NULL,
  `is_active` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 active ,0 deactive',
  `user_id` int(11) NOT NULL COMMENT 'user modify and create',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `rms_dept`  VALUES ( "1","?????????","??????????????","PS","Jan 16, 2016 2:14:48 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "2","???????????","?????????","HS","Jan 16, 2016 2:15:22 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "3","English Kindergarten","????????????","EK","Oct 6, 2016 2:09:18 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "4","English FullTime","?????????","EF","Oct 6, 2016 2:09:18 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "5","English PartTime","GEP","EP","Oct 6, 2016 2:09:18 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "7","Writing and Speaking","","WS","Dec 15, 2016 2:43:04 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "8","Computer Skill","","CS","Dec 15, 2016 2:44:00 PM","1","25");
INSERT INTO `rms_dept`  VALUES ( "9","Test","","test","May 25, 2017 9:38:03 AM","1","28");
INSERT INTO `rms_dept`  VALUES ( "10","abc","","abc","May 25, 2017 10:54:44 AM","1","28");
INSERT INTO `rms_dept`  VALUES ( "11","DBC","","DBC","May 25, 2017 10:55:11 AM","1","28");


--
-- Tabel structure for table `rms_dept_subject_detail`
--
DROP TABLE  IF EXISTS `rms_dept_subject_detail`;
CREATE TABLE `rms_dept_subject_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

INSERT INTO `rms_dept_subject_detail`  VALUES ( "29","2","1","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "30","2","8","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "31","2","14","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "32","2","15","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "33","2","19","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "34","2","21","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "35","2","26","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "36","2","27","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "37","2","28","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "38","2","29","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "39","2","17","1","2017-02-08","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "44","1","1","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "45","1","2","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "46","1","3","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "47","1","4","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "48","3","5","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "49","3","6","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "50","3","7","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "51","3","8","1","2017-02-22","1","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "63","9","1","1","2017-05-25","28","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "64","9","8","1","2017-05-25","28","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "65","9","9","1","2017-05-25","28","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "66","9","10","1","2017-05-25","28","");
INSERT INTO `rms_dept_subject_detail`  VALUES ( "67","9","14","1","2017-05-25","28","");


--
-- Tabel structure for table `rms_exchange_rate`
--
DROP TABLE  IF EXISTS `rms_exchange_rate`;
CREATE TABLE `rms_exchange_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dollar` int(11) DEFAULT NULL COMMENT 'The Currency that we take from customer',
  `reil` int(11) DEFAULT NULL COMMENT 'The Currency that we give to customer',
  `create_date` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL COMMENT '1:active; 0:Disactive',
  `is_using` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_exchange_rate`  VALUES ( "1","1","4050","2014-02-03 12:07:58","1","","28");
INSERT INTO `rms_exchange_rate`  VALUES ( "2","1","3","2014-02-03 12:07:58","1","","");
INSERT INTO `rms_exchange_rate`  VALUES ( "3","2","3","2014-02-03 12:07:58","1","","");


--
-- Tabel structure for table `rms_group`
--
DROP TABLE  IF EXISTS `rms_group`;
CREATE TABLE `rms_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_code` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `from_academic` int(11) DEFAULT NULL,
  `to_academic` int(11) DEFAULT NULL,
  `academic_year` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `semester` tinyint(4) DEFAULT NULL,
  `session` tinyint(4) DEFAULT NULL,
  `degree` int(11) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `amount_month` int(11) DEFAULT NULL,
  `is_check` tinyint(4) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `create_date` date DEFAULT NULL,
  `note` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `is_use` tinyint(30) DEFAULT '0',
  `tuitionfee_id` int(11) DEFAULT NULL,
  `is_pass` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='????? ???????????????';

INSERT INTO `rms_group`  VALUES ( "1","???????? ? A","1","","","1","1","1","1","2","2","6","","2017-02-01","2017-08-01","28","1","","","2017-02-03","1","","0");
INSERT INTO `rms_group`  VALUES ( "2","???????? ? B","1","","","1","1","2","1","2","-1","6","","2017-02-01","2017-08-01","28","1","","","2017-02-03","0","","0");
INSERT INTO `rms_group`  VALUES ( "3","????????? A","2","","","1","1","1","1","3","-1","6","","2017-02-01","2017-08-01","28","1","","","2017-02-03","0","","0");
INSERT INTO `rms_group`  VALUES ( "4","????????? B","2","","","1","1","2","1","3","-1","6","","2017-02-03","2017-08-03","28","1","","","2017-02-03","0","","0");
INSERT INTO `rms_group`  VALUES ( "5","????????? A1","7","","","1","1","1","2","8","-1","6","","2017-02-01","2017-08-01","28","1","","","2017-02-06","0","","0");
INSERT INTO `rms_group`  VALUES ( "6","????????? A1","8","","","1","1","1","2","9","2","6","","2017-02-01","2017-08-01","1","1","","","2017-02-07","0","","0");
INSERT INTO `rms_group`  VALUES ( "7","????????? A1","6","","","1","1","1","1","7","1","6","","2017-02-07","2017-08-07","1","1","","","2017-02-07","0","","0");
INSERT INTO `rms_group`  VALUES ( "9","????????? A1","2","","","1","1","1","1","3","-1","6","","2018-01-01","2018-07-01","1","1","","","2017-02-07","0","","0");
INSERT INTO `rms_group`  VALUES ( "10","Eng Kind(Pre k)Morning ","7","","","1","1","1","3","14","2","6","","2017-05-17","2017-11-17","28","1","","new group","2017-05-17","0","","0");
INSERT INTO `rms_group`  VALUES ( "11","Test Group","12","","","1","1","1","2","13","2","12","","2017-05-18","2018-05-18","28","1","","","2017-05-18","0","","0");


--
-- Tabel structure for table `rms_group_detail_student`
--
DROP TABLE  IF EXISTS `rms_group_detail_student`;
CREATE TABLE `rms_group_detail_student` (
  `gd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `stu_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1' COMMENT '1=active,2=drop',
  `is_pass` int(4) DEFAULT '0' COMMENT '0 = still study in this group , 1 = pass to another group',
  `old_group` int(4) DEFAULT NULL COMMENT 'group ???????????',
  PRIMARY KEY (`gd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='????? ??? ??????????????';

INSERT INTO `rms_group_detail_student`  VALUES ( "1","1","1","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "2","1","5","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "3","1","6","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "4","1","7","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "5","1","8","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "6","1","9","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "7","1","10","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "8","1","11","28","1","2017-03-03","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "9","1","12","27","1","2017-03-07","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "10","6","13","28","1","2017-03-31","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "11","2","14","28","1","2017-04-05","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "12","10","16","28","1","2017-05-17","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "13","5","17","28","1","2017-05-18","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "14","3","18","28","1","2017-05-24","1","0","");
INSERT INTO `rms_group_detail_student`  VALUES ( "15","7","19","28","1","2017-05-24","1","0","");


--
-- Tabel structure for table `rms_group_exam`
--
DROP TABLE  IF EXISTS `rms_group_exam`;
CREATE TABLE `rms_group_exam` (
  `gexam_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_exam_code` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `intake` int(11) DEFAULT NULL,
  `academic_year` varchar(30) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `exam_date` date DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `session_exam` tinyint(4) DEFAULT NULL,
  `semester` tinyint(4) DEFAULT NULL,
  `year` tinyint(4) DEFAULT NULL,
  `major_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  PRIMARY KEY (`gexam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_group_exam_detail`
--
DROP TABLE  IF EXISTS `rms_group_exam_detail`;
CREATE TABLE `rms_group_exam_detail` (
  `gd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gexam_id` int(11) DEFAULT NULL,
  `stu_id` int(11) DEFAULT NULL,
  `is_id` int(11) DEFAULT NULL,
  `group_code` varchar(50) DEFAULT NULL COMMENT 'auto generate',
  PRIMARY KEY (`gd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_group_student_change_group`
--
DROP TABLE  IF EXISTS `rms_group_student_change_group`;
CREATE TABLE `rms_group_student_change_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_group` varchar(100) DEFAULT NULL COMMENT 'change from group',
  `to_group` varchar(100) DEFAULT NULL COMMENT 'change to group',
  `moving_date` date DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `array_checkbox` varchar(100) DEFAULT NULL COMMENT 'all checked checkbox',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_group_student_change_group`  VALUES ( "1","1","9","2017-02-07","","1","1","1,2");
INSERT INTO `rms_group_student_change_group`  VALUES ( "2","3","4","2017-03-02","","1","28","1,2");
INSERT INTO `rms_group_student_change_group`  VALUES ( "3","5","9","2017-03-03","","1","28","1,2,3");


--
-- Tabel structure for table `rms_group_subject_detail`
--
DROP TABLE  IF EXISTS `rms_group_subject_detail`;
CREATE TABLE `rms_group_subject_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL COMMENT 'teacher subject id',
  `status` tinyint(4) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='???????????????????????';

INSERT INTO `rms_group_subject_detail`  VALUES ( "5","1","1","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "6","1","9","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "7","1","8","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "8","1","10","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "13","2","1","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "14","2","8","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "15","2","9","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "16","2","10","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "17","3","1","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "18","3","8","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "19","3","9","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "20","3","10","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "21","4","1","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "22","4","8","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "23","4","9","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "24","4","10","1","2017-02-03","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "25","5","14","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "26","5","15","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "27","5","16","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "28","5","20","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "29","5","21","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "30","5","26","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "31","5","27","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "32","5","28","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "33","5","29","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "34","5","1","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "35","5","8","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "36","5","17","1","2017-02-06","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "37","6","1","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "38","6","8","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "39","6","9","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "40","6","10","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "41","6","14","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "42","6","15","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "43","6","16","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "44","6","17","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "45","6","18","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "46","6","21","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "47","6","26","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "48","6","27","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "49","6","28","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "50","6","29","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "51","7","1","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "52","7","8","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "53","7","9","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "54","7","10","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "55","7","14","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "60","9","1","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "61","9","8","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "62","9","9","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "63","9","10","1","2017-02-07","1","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "67","10","14","1","2017-05-17","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "68","11","1","1","2017-05-18","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "69","11","8","1","2017-05-18","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "70","11","10","1","2017-05-18","28","");
INSERT INTO `rms_group_subject_detail`  VALUES ( "71","11","26","1","2017-05-18","28","");


--
-- Tabel structure for table `rms_major`
--
DROP TABLE  IF EXISTS `rms_major`;
CREATE TABLE `rms_major` (
  `major_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `major_enname` varchar(100) NOT NULL,
  `major_khname` varchar(100) NOT NULL,
  `shortcut` varchar(20) DEFAULT NULL COMMENT 'shortcut of term',
  `modify_date` varchar(30) NOT NULL,
  `is_active` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1 active ,0 deactive',
  `user_id` int(11) NOT NULL COMMENT 'user modify and create',
  PRIMARY KEY (`major_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

INSERT INTO `rms_major`  VALUES ( "1","1","?????????????????","","KK","Dec 15, 2016 2:45:25 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "2","1","?????????","","G1","Dec 15, 2016 2:46:06 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "3","1","?????????","","G2","Dec 15, 2016 2:46:25 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "4","1","?????????","","G3","Dec 15, 2016 2:46:43 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "5","1","?????????","","G4","Dec 15, 2016 2:46:57 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "6","1","?????????","","G5","Dec 15, 2016 2:47:15 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "7","1","?????????","","G6","Dec 15, 2016 2:47:26 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "8","2","?????????","","G7","Dec 15, 2016 2:49:09 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "9","2","?????????","","G8","Dec 15, 2016 2:49:18 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "10","2","?????????","","G9","Dec 15, 2016 2:48:05 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "11","2","??????????","","G10","Dec 15, 2016 2:48:20 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "12","2","??????????","","G11","Dec 15, 2016 2:48:32 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "13","2","??????????","","G12","Dec 15, 2016 2:48:46 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "14","3","Pre-K","","PK","Dec 15, 2016 2:50:05 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "15","3","k1","","k1","Dec 15, 2016 2:50:21 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "16","3","K2","","K2","Dec 15, 2016 2:50:36 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "17","3","K3","","K3","Dec 15, 2016 2:50:47 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "18","4","Foundation","","FD","Dec 15, 2016 2:51:15 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "19","4","Level 1","","L1","Dec 15, 2016 2:51:51 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "20","4","Level 2","","L2","Dec 15, 2016 2:52:02 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "21","4","Level 3","","L3","Dec 15, 2016 2:52:14 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "22","4","Level 4","","L4","Dec 15, 2016 2:52:26 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "23","4","Level 5","","L5","Dec 15, 2016 2:52:36 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "24","4","Level 6","","L6","Dec 15, 2016 2:52:46 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "25","4","Level 7","","L7","Dec 15, 2016 2:52:55 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "26","4","Level 8","","L8","Dec 15, 2016 2:53:05 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "27","4","Level 9","","L9","Dec 15, 2016 2:53:14 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "28","4","Level 10","","L10","Dec 15, 2016 2:53:57 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "29","4","Level 11","","L11","Dec 15, 2016 2:54:07 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "30","4","Level 12","","L12","Dec 15, 2016 2:54:18 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "31","5","Starter 1","","ST1","Dec 15, 2016 2:54:54 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "32","5","Starter 2","","ST2","Dec 15, 2016 2:55:10 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "33","5","Level 1","","L1","Dec 15, 2016 2:55:32 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "34","5","Level 2","","L2","Dec 15, 2016 2:56:39 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "35","5","Level 3","","L3","Dec 15, 2016 2:56:50 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "36","5","Level 4","","L4","Dec 15, 2016 2:57:00 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "37","5","Level 5","","L5","Dec 15, 2016 2:57:23 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "38","5","Level 6","","L6","Dec 15, 2016 2:57:34 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "39","5","Level 7","","L7","Dec 15, 2016 2:57:50 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "40","5","Level 8","","L8","Dec 15, 2016 2:57:59 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "41","5","Level 9","","L9","Dec 15, 2016 2:58:12 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "42","5","Level 10","","L10","Dec 15, 2016 2:58:22 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "43","5","Level 11","","L11","Dec 15, 2016 2:58:32 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "44","5","Level 12","","L12","Dec 15, 2016 2:58:53 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "48","7","Level 1","","L1","Dec 15, 2016 3:04:11 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "49","7","Level 2","","L2","Dec 15, 2016 3:04:25 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "50","7","Level 3","","L3","Dec 15, 2016 3:04:35 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "51","7","Level 4","","L4","Dec 15, 2016 3:04:47 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "52","7","Level 5","","L5","Dec 15, 2016 3:04:57 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "53","7","Level 6","","L6","Dec 15, 2016 3:05:05 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "54","7","Level 7","","L7","Dec 15, 2016 3:05:19 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "55","7","Level 8","","L8","Dec 15, 2016 3:05:28 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "56","7","Level 9","","L9","Dec 15, 2016 3:05:42 PM","1","25");
INSERT INTO `rms_major`  VALUES ( "57","10","Test1a","","Test1a","May 25, 2017 10:54:46 AM","1","28");
INSERT INTO `rms_major`  VALUES ( "58","11","test2","","test2","May 25, 2017 10:55:15 AM","1","28");


--
-- Tabel structure for table `rms_occupation`
--
DROP TABLE  IF EXISTS `rms_occupation`;
CREATE TABLE `rms_occupation` (
  `occupation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occu_name` varchar(100) DEFAULT NULL,
  `occu_enname` varchar(130) DEFAULT NULL,
  `create_date` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `user_id` int(4) DEFAULT NULL,
  PRIMARY KEY (`occupation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `rms_occupation`  VALUES ( "18","??????????","","Sep 29, 2015 12:05:52 AM","1","1");
INSERT INTO `rms_occupation`  VALUES ( "19","????????????????????????????","","Sep 29, 2015 12:05:55 AM","1","1");
INSERT INTO `rms_occupation`  VALUES ( "20","?????????","","Sep 29, 2015 12:05:59 AM","1","1");
INSERT INTO `rms_occupation`  VALUES ( "21","?????????????","","Sep 29, 2015 12:06:06 AM","1","1");
INSERT INTO `rms_occupation`  VALUES ( "22","?????????????????","","Sep 29, 2015 12:06:13 AM","1","1");
INSERT INTO `rms_occupation`  VALUES ( "23","?????","","Sep 29, 2015 8:23:45 AM","1","1");
INSERT INTO `rms_occupation`  VALUES ( "24","?????????????","","Sep 29, 2015 8:23:55 AM","1","1");


--
-- Tabel structure for table `rms_pro_category`
--
DROP TABLE  IF EXISTS `rms_pro_category`;
CREATE TABLE `rms_pro_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_kh` varchar(100) DEFAULT NULL,
  `name_en` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `type_id` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `rms_pro_category`  VALUES ( "1","?????","Book","2016-09-26","1","1","1");
INSERT INTO `rms_pro_category`  VALUES ( "2","??????????????","Application  Form","2016-10-27","1","12","1");
INSERT INTO `rms_pro_category`  VALUES ( "3","????????","Uniform","2016-09-26","1","1","1");
INSERT INTO `rms_pro_category`  VALUES ( "4","??????","Other","2016-10-26","1","12","1");
INSERT INTO `rms_pro_category`  VALUES ( "5","??????","1Set","2016-09-26","2","1","1");
INSERT INTO `rms_pro_category`  VALUES ( "6","?????","","2016-09-16","2","1","1");
INSERT INTO `rms_pro_category`  VALUES ( "7","?????","","2016-09-16","2","1","0");
INSERT INTO `rms_pro_category`  VALUES ( "8","????????","","2016-09-16","2","1","1");
INSERT INTO `rms_pro_category`  VALUES ( "9","??????","T-Shirt","2016-10-26","1","12","1");


--
-- Tabel structure for table `rms_product`
--
DROP TABLE  IF EXISTS `rms_product`;
CREATE TABLE `rms_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(150) DEFAULT NULL,
  `pro_code` varchar(50) DEFAULT NULL,
  `cat_id` tinyint(4) DEFAULT NULL,
  `measur_id` tinyint(4) DEFAULT NULL,
  `pro_size` varchar(50) DEFAULT NULL,
  `pro_price` float(15,2) DEFAULT NULL,
  `pro_des` varchar(250) DEFAULT NULL,
  `pro_img` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

INSERT INTO `rms_product`  VALUES ( "1","??????????????","P-00001","2","5","","2.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "2","??????????????","P-00002","2","5","","1.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "3","Hello JoJo","P-00003","1","8","","8.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "4","Phonic 1","P-00004","1","8","","3.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "5","Phonic 2","P-00005","1","8","","3.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "6","Phonic 3","P-00006","1","8","","3.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "7","Phonic 4","P-00007","1","8","","3.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "8","N.W I","P-00008","1","8","","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "9","N.W 2","P-00009","1","8","","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "10","N.W 3","P-00010","1","8","","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "11","N.W 4","P-00011","1","8","","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "12","N.W 5","P-00012","1","8","","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "13","N.W 6","P-00013","1","8","","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "14","First Friend 2","P-00014","1","8","","3.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "15","Family and Friend 2","P-00015","1","8","","3.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "16","Mega Goal 1","P-00016","1","8","","20.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "17","Mega Goal 2","P-00017","1","8","","20.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "18","Mega Goal 3","P-00018","1","8","","20.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "19","Khmer 1","P-00019","1","8","","5.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "20","Khmer 2","P-00020","1","8","","5.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "21","Khmer 3","P-00021","1","8","","5.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "22","Khmer 4","P-00022","1","8","","5.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "23","Khmer 5","P-00023","1","8","","5.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "24","Khmer 6","P-00024","1","8","","5.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "25","English 1A","P-00025","1","8","","10.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "26","English 1B","P-00026","1","8","","10.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "27","???????? ?????????????????","P-00027","3","5","S","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "28","???????? ?????????????????","P-00028","3","5","M","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "29","???????? ?????????????????","P-00029","3","5","L","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "30","???????? ?????????????????","P-00030","3","5","XL","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "31","???????? ?????????????????","P-00031","3","5","XXL","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "32","???????? ?????????????????","P-00032","3","5","XXX","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "33","???????? ????????????????","P-00033","3","5","S","11.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "34","???????? ????????????????","P-00034","3","5","M","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "35","???????? ????????????????","P-00035","3","5","L","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "36","???????? ????????????????","P-00036","3","5","XL","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "37","???????? ????????????????","P-00037","3","8","XXL","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "38","???????? ????????????????","P-00038","3","5","XXX","12.00","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "39","T-Shirt","P-00039","9","5","S","3.25","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "40","T-Shirt","P-00040","9","5","M","3.25","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "41","T-Shirt","P-00041","9","5","L","3.25","","","2016-09-26","1","1");
INSERT INTO `rms_product`  VALUES ( "42","160p","P-00042","1","8","","1500.00","","","2016-10-06","1","1");
INSERT INTO `rms_product`  VALUES ( "43","Female Uniform (Size S)","P-00043","3","5","S","11.00","","","2016-10-27","12","0");
INSERT INTO `rms_product`  VALUES ( "44","Female Uniform (Size S)","P-00044","3","5","S","11.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "45","Female Uniform (Size M)","P-00045","3","5","M","12.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "46","Female Uniform (Size L)","P-00046","3","5","L","12.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "47","Female Uniform (Size XL)","P-00047","3","5","XL","12.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "48","Female Uniform (Size XXL)","P-00048","3","5","XXL","13.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "49","Female Uniform (Size XXXL)","P-00049","3","5","XXXL","13.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "50","Male Uniform (Size S)","P-00050","3","5","S","11.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "51","Male Uniform (Size M)","P-00051","3","5","M","12.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "52","Male Uniform (Size L)","P-00052","3","5","L","12.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "53","Male Uniform (Size XL)","P-00053","3","5","XL","12.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "54","Male Uniform (Size XXL)","P-00054","3","5","XXL","13.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "55","Male Uniform (Size XXXL)","P-00055","3","5","XXXL","13.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "56","T-shirt (Size S***)","P-00056","3","5","S***","3.25","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "57","T-shirt (Size M***)","P-00057","3","5","M***","3.25","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "58","T-shirt (size L***)","P-00058","3","5","L***","3.25","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "59","T-shirt (size Ss)","P-00059","3","5","SS","3.75","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "60","T-shirt (size S)","P-00060","3","5","S","4.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "61","T-shirt Size L","P-00061","3","5","L","4.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "62","Phonics 1","P-00062","1","8","Pre-Kindergarten","3.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "63","Phonics 2","P-00063","1","8","Pre-Kindergarten 2","3.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "64","Phonics 3","P-00064","1","8","Kindergarten 1","3.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "65","Phonics 4","P-00065","1","8","Kindergarten 2","3.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "66","English 1A","P-00066","1","5","YL1A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "67","English 1B","P-00067","1","5","YL1B","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "68","Mega. Intro","P-00068","1","5","Level 1","11.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "69","Mega 1","P-00069","1","5","Level 3-4","11.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "70","Mega 2","P-00070","1","5","Level 5-6","11.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "71","Mega 3","P-00071","1","5","level 7-8","12.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "72","Mega 4","P-00072","1","5","Level 9-10","12.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "73","Mega 5","P-00073","1","5","Level 11-12","12.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "74","???????????????????","P-00074","1","5","?????????","5.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "75","???????????????????","P-00075","1","5","?????????","5.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "76","???????????????????","P-00076","1","5","?????????","5.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "77","???????????????????","P-00077","1","5","?????????","6.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "78","???????????????????","P-00078","1","5","?????????","6.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "79","???????????????????","P-00079","1","5","?????????","6.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "80","First Friends ","P-00080","1","5","1","3.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "81","First Friends (Color)","P-00081","1","5","First Friends (Color)","7.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "82","New World 1","P-00082","1","5","NW1","10.50","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "83","New World 2","P-00083","1","5","NW2","10.50","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "84","New World 3","P-00084","1","5","NW3","10.50","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "85","New World 4","P-00085","1","5","NW4","10.50","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "86","New World 5","P-00086","1","5","NW5","10.50","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "87","New World 6","P-00087","1","5","NW6","11.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "88","Family and Friends","P-00088","1","5","FF","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "89","Science 1A","P-00089","1","5","Science 1A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "90","Science 1B","P-00090","1","5","Science 1B","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "91","Hello JoJo","P-00091","1","5","JoJo","8.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "92","You and Me 1","P-00092","1","5","You 1","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "93","You and Me 2","P-00093","1","5","You 2","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "94","Science 2A","P-00094","1","5","Science 2A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "95","Science 2B","P-00095","1","5","Science 2B","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "96","Science 3A","P-00096","1","5","Science 3A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "97","Science 3B","P-00097","1","5","Science 3B","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "98","Science 4A","P-00098","1","5","Science 4A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "99","Science 4B","P-00099","1","5","Science 4B","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "100","Science 5A","P-00100","1","5","Science 5A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "101","Science 5B","P-00101","1","5","Science 5B","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "102","Science 6A","P-00102","1","5","Science 6A","10.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "103","Application Form ","P-00103","2","5","NA","2.00","","","2016-10-26","12","1");
INSERT INTO `rms_product`  VALUES ( "104","Application Form (SR)","P-00104","2","5","NA","1.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "105","Science 6B","P-00105","1","5","Science 6B","10.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "106","T-shirt (Size M)","P-00106","3","5","M","4.00","","","2016-10-27","12","1");
INSERT INTO `rms_product`  VALUES ( "107","GoGo 1","P-00107","1","8","","15.00","new book","","2016-11-25","1","1");
INSERT INTO `rms_product`  VALUES ( "108","Uniform size s (female)","P-00108","3","5","","11.00","","","2017-02-01","28","1");
INSERT INTO `rms_product`  VALUES ( "109","Phonics 2","P-00109","1","","","4.00","","","2017-03-07","28","1");
INSERT INTO `rms_product`  VALUES ( "110","TestProduct","P-00110","4","","","7.00","","","2017-03-27","28","1");


--
-- Tabel structure for table `rms_product_location`
--
DROP TABLE  IF EXISTS `rms_product_location`;
CREATE TABLE `rms_product_location` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pro_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `pro_qty` float(15,2) DEFAULT NULL,
  `total_amount` float(15,2) DEFAULT NULL,
  `note` varchar(250) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=505 DEFAULT CHARSET=utf8;

INSERT INTO `rms_product_location`  VALUES ( "1","1","4","10.00","20.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "2","1","3","10.00","20.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "3","1","1","10.00","20.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "4","2","2","10.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "5","3","4","10.00","80.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "6","3","3","110.00","80.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "7","3","2","10.00","80.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "8","3","1","10.00","80.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "9","4","4","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "10","4","3","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "11","4","2","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "12","4","1","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "13","5","4","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "14","5","3","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "15","5","2","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "16","5","1","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "17","6","4","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "18","6","3","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "19","6","2","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "20","6","1","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "21","7","4","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "22","7","3","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "23","7","2","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "24","7","1","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "25","8","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "26","8","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "27","8","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "28","8","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "29","9","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "30","9","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "31","9","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "32","9","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "33","10","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "34","10","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "35","10","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "36","10","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "37","11","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "38","11","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "39","11","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "40","11","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "41","12","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "42","12","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "43","12","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "44","12","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "45","13","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "46","13","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "47","13","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "48","13","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "49","14","4","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "50","14","3","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "51","14","2","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "52","14","1","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "53","15","4","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "54","15","3","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "55","15","2","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "56","15","1","10.00","30.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "57","16","4","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "58","16","3","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "59","16","2","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "60","16","1","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "61","17","4","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "62","17","3","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "63","17","2","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "64","17","1","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "65","18","4","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "66","18","3","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "67","18","2","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "68","18","1","10.00","200.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "69","19","4","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "70","19","3","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "71","19","2","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "72","19","1","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "73","20","4","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "74","20","3","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "75","20","2","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "76","20","1","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "77","21","4","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "78","21","3","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "79","21","2","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "80","21","1","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "81","22","4","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "82","22","3","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "83","22","2","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "84","22","1","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "85","23","4","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "86","23","3","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "87","23","2","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "88","23","1","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "89","24","4","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "90","24","3","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "91","24","2","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "92","24","1","10.00","50.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "93","25","4","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "94","25","3","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "95","25","2","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "96","25","1","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "97","26","4","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "98","26","3","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "99","26","2","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "100","26","1","10.00","100.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "101","27","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "102","27","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "103","27","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "104","27","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "105","28","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "106","28","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "107","28","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "108","28","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "109","29","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "110","29","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "111","29","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "112","29","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "113","30","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "114","30","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "115","30","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "116","30","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "117","31","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "118","31","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "119","31","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "120","31","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "121","32","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "122","32","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "123","32","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "124","32","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "125","33","4","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "126","33","3","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "127","33","2","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "128","33","1","10.00","110.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "129","34","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "130","34","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "131","34","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "132","34","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "133","35","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "134","35","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "135","35","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "136","35","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "137","36","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "138","36","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "139","36","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "140","36","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "141","37","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "142","37","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "143","37","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "144","37","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "145","38","4","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "146","38","3","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "147","38","2","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "148","38","1","10.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "149","39","4","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "150","39","3","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "151","39","2","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "152","39","1","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "153","40","4","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "154","40","3","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "155","40","2","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "156","40","1","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "157","41","4","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "158","41","3","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "159","41","2","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "160","41","1","10.00","32.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "161","42","4","10.00","15000.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "245","66","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "246","66","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "247","66","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "248","66","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "249","67","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "250","67","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "251","67","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "252","67","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "253","68","3","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "254","68","4","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "255","68","2","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "256","68","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "257","69","4","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "258","69","3","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "259","69","2","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "260","69","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "261","70","4","0.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "262","70","3","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "263","70","2","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "264","70","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "265","71","4","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "266","71","3","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "267","71","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "268","71","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "269","72","4","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "270","72","3","0.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "271","72","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "272","72","1","0.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "273","73","4","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "274","73","3","-1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "275","73","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "276","73","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "277","74","4","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "278","74","3","0.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "279","74","2","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "280","74","1","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "281","75","4","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "282","75","3","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "283","75","2","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "284","75","1","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "285","76","4","0.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "286","76","3","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "287","76","2","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "288","76","1","1.00","5.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "289","77","4","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "290","77","3","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "291","77","2","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "292","77","1","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "293","78","4","8.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "294","78","3","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "295","78","2","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "296","78","1","0.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "297","79","4","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "298","79","3","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "299","79","2","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "300","79","1","1.00","6.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "301","80","4","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "302","80","3","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "303","80","2","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "304","80","1","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "309","82","4","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "310","82","3","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "311","82","2","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "312","82","1","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "313","83","4","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "314","83","3","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "315","83","2","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "316","83","1","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "317","84","4","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "318","84","3","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "319","84","2","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "320","84","1","0.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "321","85","4","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "322","85","3","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "323","85","2","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "324","85","1","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "325","86","4","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "326","86","3","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "327","86","2","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "328","86","1","1.00","10.50","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "329","87","4","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "330","87","3","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "331","87","2","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "332","87","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "333","88","4","0.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "334","88","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "335","88","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "336","88","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "337","89","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "338","89","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "339","89","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "340","89","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "341","90","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "342","90","3","0.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "343","90","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "344","90","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "345","91","4","1.00","8.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "346","91","1","1.00","8.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "347","92","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "348","92","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "349","93","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "350","93","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "351","94","4","0.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "352","94","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "353","94","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "354","94","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "355","95","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "356","95","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "357","95","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "358","95","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "359","96","4","35.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "360","96","3","-1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "361","96","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "362","96","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "363","97","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "364","97","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "365","97","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "366","97","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "367","98","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "368","98","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "369","98","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "370","98","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "371","99","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "372","99","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "373","99","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "374","99","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "375","100","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "376","100","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "377","100","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "378","100","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "379","101","4","0.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "380","101","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "381","101","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "382","101","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "383","102","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "384","102","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "385","102","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "386","102","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "387","103","4","0.00","2.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "388","103","3","-4.00","2.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "389","103","1","0.00","2.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "395","105","4","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "396","105","3","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "397","105","2","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "398","105","1","1.00","10.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "399","65","3","0.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "400","65","2","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "401","62","2","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "402","62","3","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "403","64","3","-1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "404","64","2","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "405","63","3","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "406","63","2","1.00","3.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "407","81","4","1.00","7.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "408","81","3","1.00","7.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "409","81","2","1.00","7.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "410","81","1","1.00","7.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "411","61","4","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "412","61","3","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "413","61","2","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "414","61","1","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "415","60","4","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "416","60","3","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "417","60","2","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "418","60","1","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "419","59","4","1.00","3.75","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "420","59","3","1.00","3.75","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "421","59","2","1.00","3.75","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "422","59","1","1.00","3.75","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "423","58","4","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "424","58","3","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "425","58","2","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "426","58","1","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "427","57","4","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "428","57","3","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "429","57","2","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "430","57","1","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "431","106","4","21.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "432","106","3","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "433","106","2","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "434","106","1","1.00","4.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "435","56","4","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "436","56","3","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "437","56","2","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "438","56","1","1.00","3.25","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "439","55","4","8.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "440","55","3","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "441","55","2","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "442","55","1","0.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "443","104","2","1.00","1.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "448","53","4","0.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "449","53","3","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "450","53","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "451","53","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "452","52","4","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "453","52","3","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "454","52","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "455","52","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "456","51","4","8.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "457","51","3","0.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "458","51","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "459","51","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "460","50","4","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "461","50","3","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "462","50","2","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "463","50","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "464","49","4","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "465","49","3","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "466","49","2","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "467","49","1","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "468","44","2","0.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "469","44","4","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "470","44","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "471","48","4","-1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "472","48","3","0.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "473","48","2","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "474","48","1","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "475","54","4","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "476","54","3","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "477","54","2","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "478","54","1","1.00","13.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "479","47","4","-1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "480","47","3","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "481","47","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "482","47","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "483","46","4","8.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "484","46","3","-1.00","0.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "485","46","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "486","46","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "487","45","4","-1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "488","45","3","0.00","0.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "489","45","2","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "490","45","1","1.00","12.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "495","43","3","0.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "496","43","3","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "497","43","2","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "498","43","1","1.00","11.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "499","107","3","70.00","750.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "500","65","1","-1.00","","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "501","108","3","75.00","275.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "503","109","1","30.00","120.00","","","","1");
INSERT INTO `rms_product_location`  VALUES ( "504","110","1","10.00","70.00","","","","1");


--
-- Tabel structure for table `rms_program_name`
--
DROP TABLE  IF EXISTS `rms_program_name`;
CREATE TABLE `rms_program_name` (
  `service_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ser_cate_id` int(11) DEFAULT NULL COMMENT 'from rms_program_type',
  `title` varchar(150) DEFAULT NULL,
  `description` text,
  `price` float DEFAULT '0' COMMENT '???????????????',
  `status` tinyint(4) DEFAULT NULL,
  `create_date` varchar(30) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT '1=program,2=service',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=ucs2 COMMENT='program/service name';

INSERT INTO `rms_program_name`  VALUES ( "1","","????????","","20","1","Jan 7, 2016 8:43:25 AM","1","1","");
INSERT INTO `rms_program_name`  VALUES ( "4","2","Tuition Fee","","0","1","Jun 12, 2016 6:24:31 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "5","2","Other Fee-??????????","","0","1","Jun 12, 2016 6:24:22 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "6","1","Admin Fee-????????????","","0","1","Jun 12, 2016 6:10:15 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "7","1","Admin Fee (Full-Time)-????????????","","0","1","Jun 12, 2016 6:09:51 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "8","1","?????????????","","0","1","Jun 12, 2016 6:12:15 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "9","1","Application Form","","0","1","Jun 12, 2016 6:11:38 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "10","5","Admin Fee (Part-Time)-????????????","","0","1","Apr 26, 2016 3:07:10 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "11","5","?????????? (????)","","0","1","Aug 1, 2016 3:59:17 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "12","5","?????????? (??-??)","","0","1","Aug 1, 2016 4:01:51 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "13","5","????????? (????)","","0","1","Aug 1, 2016 4:04:13 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "14","5","????????? (??-??)","","0","1","Aug 1, 2016 4:05:25 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "15","5","???????? (??-??)","","0","1","Aug 1, 2016 4:06:12 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "16","5","???????? (????)","","0","1","Aug 1, 2016 4:07:05 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "17","5","????????????????? (????)","","0","1","Aug 1, 2016 4:09:21 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "18","5","????????????????? (??-??)","","0","1","Aug 1, 2016 4:10:16 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "19","5","????????? (????)","","0","1","Aug 1, 2016 4:11:15 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "20","5","????????? (??-??)","","0","1","Aug 1, 2016 4:12:15 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "21","5","???????? (????)","","0","1","Aug 1, 2016 4:13:05 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "22","5","???????? (??-??)","","0","1","Aug 1, 2016 4:14:08 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "23","5","?????????? (????)","","0","1","Aug 1, 2016 4:14:47 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "24","5","??????????  (??-??)","","0","1","Aug 1, 2016 4:15:13 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "25","5","???????????????????? (????)","","0","1","Aug 1, 2016 4:15:48 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "26","5","???????????????????? (??-??)","","0","1","Aug 1, 2016 4:17:12 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "27","5","??????????????????????? (??-??)","","0","1","Aug 1, 2016 4:17:47 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "28","5","??????????????????????? (????)","","0","1","Aug 1, 2016 4:18:49 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "29","5","??????????????? (????)","","0","1","Aug 1, 2016 4:19:55 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "30","5","??????????????? (??-??)","","0","1","Aug 1, 2016 4:20:43 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "31","5","??????????? (????)","","0","1","Aug 1, 2016 4:21:13 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "32","5","??????????? (??-??)","","0","1","Aug 1, 2016 4:22:07 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "33","5","??????????? (????)","","0","1","Aug 1, 2016 4:23:16 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "34","5","??????????? (??-??)","","0","1","Aug 1, 2016 4:24:32 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "35","5","?????? (????)","","0","1","Aug 1, 2016 4:25:16 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "36","","?????","","12","1","Aug 2, 2016 2:52:39 PM","4","1","");
INSERT INTO `rms_program_name`  VALUES ( "37","","???????????","","23","1","Aug 2, 2016 2:52:39 PM","4","1","");
INSERT INTO `rms_program_name`  VALUES ( "38","","??????","","10","1","Aug 2, 2016 2:52:39 PM","4","1","");
INSERT INTO `rms_program_name`  VALUES ( "39","5","????????????? (????)","","0","1","Oct 4, 2016 7:24:41 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "40","5","????????????? (??-??)","","0","1","Oct 4, 2016 7:25:17 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "41","5","?????????????? (????)","","0","1","Oct 4, 2016 7:26:31 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "42","5","?????????????? (??-??)","","0","1","Oct 4, 2016 7:26:59 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "43","5","?????? (??-??)","","0","1","Oct 4, 2016 7:27:39 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "44","5","???????????? (????)","","0","1","Oct 4, 2016 7:28:36 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "45","5","???????????? (??-??)","","0","1","Oct 4, 2016 7:33:20 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "46","5","?????????? (????)","","0","1","Oct 4, 2016 7:54:09 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "47","5","?????????? (??-??)","","0","1","Oct 4, 2016 7:54:37 PM","1","2","");
INSERT INTO `rms_program_name`  VALUES ( "48","5","???????????????(??- ??)","","0","1","Oct 26, 2016 2:24:08 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "49","5","???????????????(??????)","","0","1","Oct 26, 2016 2:24:51 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "50","5","??????(??????)","","0","1","Oct 26, 2016 2:36:45 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "51","5","??????(??-??)","","0","1","Oct 26, 2016 2:37:21 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "52","5","??????????????(??????)","","0","1","Oct 26, 2016 2:38:34 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "53","5","??????????????(?? - ??)","","0","1","Oct 26, 2016 2:39:27 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "54","5","???????????(?? - ??)","","0","1","Oct 26, 2016 2:41:54 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "55","5","???????????(??????)","","0","1","Oct 26, 2016 2:42:40 PM","12","2","");
INSERT INTO `rms_program_name`  VALUES ( "56","43","Female Uniform (Size S)","","11","0","2016-10-26 14:52:29","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "57","44","Female Uniform (Size S)","","11","1","2016-10-26 14:53:50","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "58","45","Female Uniform (Size M)","","12","1","2016-10-26 14:57:43","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "59","46","Female Uniform (Size L)","","12","1","2016-10-26 14:58:51","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "60","47","Female Uniform (Size XL)","","12","1","2016-10-26 15:00:02","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "61","48","Female Uniform (Size XXL)","","13","1","2016-10-26 15:00:54","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "62","49","Female Uniform (Size XXXL)","","13","1","2016-10-26 15:03:08","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "63","50","Male Uniform (Size S)","","11","1","2016-10-26 15:04:28","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "64","51","Male Uniform (Size M)","","12","1","2016-10-26 15:05:16","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "65","52","Male Uniform (Size L)","","12","1","2016-10-26 15:05:52","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "66","53","Male Uniform (Size XL)","","12","1","2016-10-26 15:06:25","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "67","54","Male Uniform (Size XXL)","","13","1","2016-10-26 15:07:03","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "68","55","Male Uniform (Size XXXL)","","13","1","2016-10-26 15:07:39","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "69","56","T-shirt (Size S***)","","3.25","1","2016-10-26 15:11:54","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "70","57","T-shirt (Size M***)","","3.25","1","2016-10-26 15:13:02","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "71","58","T-shirt (size L***)","","3.25","1","2016-10-26 15:13:49","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "72","59","T-shirt (size Ss)","","3.75","1","2016-10-26 15:15:34","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "73","60","T-shirt (size S)","","4","1","2016-10-26 15:17:09","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "74","61","T-shirt Size L","","4","1","2016-10-26 15:18:21","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "75","62","Phonics 1","","3","1","2016-10-26 15:20:50","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "76","63","Phonics 2","","3","1","2016-10-26 15:21:57","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "77","64","Phonics 3","","3","1","2016-10-26 15:22:51","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "78","65","Phonics 4","","3","1","2016-10-26 15:24:01","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "79","66","English 1A","","10","1","2016-10-26 15:25:21","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "80","67","English 1B","","10","1","2016-10-26 15:26:50","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "81","68","Mega. Intro","","11","1","2016-10-26 15:28:04","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "82","69","Mega 1","","11","1","2016-10-26 15:30:06","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "83","70","Mega 2","","11","1","2016-10-26 15:30:58","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "84","71","Mega 3","","12","1","2016-10-26 15:31:52","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "85","72","Mega 4","","12","1","2016-10-26 15:32:57","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "86","73","Mega 5","","12","1","2016-10-26 15:33:55","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "87","74","???????????????????","","5","1","2016-10-26 15:35:51","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "88","75","???????????????????","","5","1","2016-10-26 15:36:46","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "89","76","???????????????????","","5","1","2016-10-26 15:37:28","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "90","77","???????????????????","","6","1","2016-10-26 15:38:46","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "91","78","???????????????????","","6","1","2016-10-26 15:39:50","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "92","79","???????????????????","","6","1","2016-10-26 15:40:51","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "93","80","First Friends ","","3","1","2016-10-26 15:47:46","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "94","81","First Friends (Color)","","7","1","2016-10-26 15:49:22","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "95","82","New World 1","","10.5","1","2016-10-26 15:52:39","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "96","83","New World 2","","10.5","1","2016-10-26 15:53:42","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "97","84","New World 3","","10.5","1","2016-10-26 15:54:23","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "98","85","New World 4","","10.5","1","2016-10-26 15:55:24","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "99","86","New World 5","","10.5","1","2016-10-26 15:56:13","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "100","87","New World 6","","11","1","2016-10-26 15:57:10","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "101","88","Family and Friends","","10","1","2016-10-26 15:58:20","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "102","89","Science 1A","","10","1","2016-10-26 16:00:45","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "103","90","Science 1B","","10","1","2016-10-26 16:02:47","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "104","91","Hello JoJo","","8","1","2016-10-26 16:04:49","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "105","92","You and Me 1","","10","1","2016-10-26 16:05:39","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "106","93","You and Me 2","","10","1","2016-10-26 16:06:21","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "107","94","Science 2A","","10","1","2016-10-26 16:08:10","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "108","95","Science 2B","","10","1","2016-10-26 16:09:14","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "109","96","Science 3A","","10","1","2016-10-26 16:10:29","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "110","97","Science 3B","","10","1","2016-10-26 16:11:15","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "111","98","Science 4A","","10","1","2016-10-26 16:12:06","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "112","99","Science 4B","","10","1","2016-10-26 16:12:50","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "113","100","Science 5A","","10","1","2016-10-26 16:13:48","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "114","101","Science 5B","","10","1","2016-10-26 16:14:26","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "115","102","Science 6A","","10","1","2016-10-26 16:15:16","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "116","103","Application Form ","","2","1","2016-10-26 16:17:00","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "117","104","Application Form (SR)","","1","1","2016-10-26 16:17:43","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "118","105","Science 6B","","10","1","2016-10-27 14:25:52","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "119","106","T-shirt (Size M)","","4","1","2016-10-27 15:30:56","12","1","");
INSERT INTO `rms_program_name`  VALUES ( "120","107","GoGo 1","new book","15","1","2016-11-25 09:03:29","1","1","");
INSERT INTO `rms_program_name`  VALUES ( "121","108","Uniform size s (female)","","11","1","2017-02-01 11:11:31","28","1","");
INSERT INTO `rms_program_name`  VALUES ( "122","109","Phonics 2","","4","1","2017-03-07 09:34:08","28","1","");
INSERT INTO `rms_program_name`  VALUES ( "123","110","TestProduct","","7","1","2017-03-27 10:34:29","28","1","");
INSERT INTO `rms_program_name`  VALUES ( "124","5","TestService","","0","1","Mar 27, 2017 10:38:59 AM","28","2","");


--
-- Tabel structure for table `rms_program_type`
--
DROP TABLE  IF EXISTS `rms_program_type`;
CREATE TABLE `rms_program_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `item_desc` text,
  `status` tinyint(4) DEFAULT NULL,
  `create_date` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` tinyint(3) unsigned NOT NULL COMMENT '1=service type,2=program type',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=ucs2;

INSERT INTO `rms_program_type`  VALUES ( "1","Other Service-??????????????","","1","Jun 12, 2016 4:40:22 PM","1","1");
INSERT INTO `rms_program_type`  VALUES ( "2","Food Service-??????????????????","All Food","1","Jun 12, 2016 6:25:24 PM","1","1");
INSERT INTO `rms_program_type`  VALUES ( "3","Uniform-????????","","1","Jun 12, 2016 6:27:47 PM","1","1");
INSERT INTO `rms_program_type`  VALUES ( "4","Sport Service-????","Sport","1","Jun 12, 2016 4:28:52 PM","1","1");
INSERT INTO `rms_program_type`  VALUES ( "5","Transport-?????????????","transport","1","Jun 12, 2016 4:27:40 PM","1","1");


--
-- Tabel structure for table `rms_province`
--
DROP TABLE  IF EXISTS `rms_province`;
CREATE TABLE `rms_province` (
  `province_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `province_en_name` varchar(50) DEFAULT NULL,
  `province_kh_name` varchar(60) DEFAULT NULL,
  `modify_date` varchar(50) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '1',
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `rms_province`  VALUES ( "1","Phnom Penh","???????","Jun 5, 2014 6:37:55 AM","1","1");
INSERT INTO `rms_province`  VALUES ( "2","Kampong Cham","????????","Sep 21, 2015 11:24:06 PM","1","1");
INSERT INTO `rms_province`  VALUES ( "3","Kandal","??????","Jun 5, 2014 6:38:14 AM","1","1");
INSERT INTO `rms_province`  VALUES ( "4","Takeo","?????","Jun 5, 2014 6:37:43 AM","1","1");
INSERT INTO `rms_province`  VALUES ( "5","Kampong Speu","?????????","","1","0");
INSERT INTO `rms_province`  VALUES ( "6","Banteay Meanchey","????????????","","1","0");
INSERT INTO `rms_province`  VALUES ( "7","Battambang","????????","","1","0");
INSERT INTO `rms_province`  VALUES ( "8","Kampong Chhnang","???????????","","1","0");
INSERT INTO `rms_province`  VALUES ( "9","Kampong Thom","???????","","1","0");
INSERT INTO `rms_province`  VALUES ( "10","Kampot","????","","1","0");
INSERT INTO `rms_province`  VALUES ( "11","Koh Kong","??????","","1","0");
INSERT INTO `rms_province`  VALUES ( "12","Kep","???","","1","0");
INSERT INTO `rms_province`  VALUES ( "13","Kratie","??????","","1","0");
INSERT INTO `rms_province`  VALUES ( "14","Mondulkiri","?????????","","1","0");
INSERT INTO `rms_province`  VALUES ( "15","Oddar Meanchey","???????????","","1","");
INSERT INTO `rms_province`  VALUES ( "16","Pailin","?????","","1","");
INSERT INTO `rms_province`  VALUES ( "17","Preah Sihanouk","?????????","","1","");
INSERT INTO `rms_province`  VALUES ( "18","Preah Vihear","?????????","","1","");
INSERT INTO `rms_province`  VALUES ( "19","Pursat","?????????","","1","");
INSERT INTO `rms_province`  VALUES ( "20","Prey Veng","???????","","1","");
INSERT INTO `rms_province`  VALUES ( "21","Ratanakiri","???????","","1","");
INSERT INTO `rms_province`  VALUES ( "22","Stung Treng","??????????","","1","");
INSERT INTO `rms_province`  VALUES ( "23","Svay Rieng","????????","","1","");
INSERT INTO `rms_province`  VALUES ( "24","Tbong Khmum","??????????","","1","");
INSERT INTO `rms_province`  VALUES ( "25","Siem Reap","??????","","1","");


--
-- Tabel structure for table `rms_rate`
--
DROP TABLE  IF EXISTS `rms_rate`;
CREATE TABLE `rms_rate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rate_type` tinyint(4) DEFAULT NULL,
  `rate` float unsigned DEFAULT NULL,
  `modify_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_rate`  VALUES ( "1","1","4100","","");


--
-- Tabel structure for table `rms_room`
--
DROP TABLE  IF EXISTS `rms_room`;
CREATE TABLE `rms_room` (
  `room_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_name` varchar(100) NOT NULL,
  `modify_date` varchar(100) NOT NULL,
  `is_active` tinyint(3) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `rms_room`  VALUES ( "1","Room 1","Oct 26, 2016 8:31:20 AM","1","12");
INSERT INTO `rms_room`  VALUES ( "2","Room 2","Sep 27, 2015 12:19:01 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "3","Room 3","Sep 27, 2015 12:19:01 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "4","Room 4","Sep 27, 2015 12:21:54 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "5","Room 5","Sep 27, 2015 12:24:11 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "6","Room 6","Sep 27, 2015 12:24:18 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "7","Room 7","Sep 27, 2015 1:32:13 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "8","Room 8","Mar 1, 2016 2:22:04 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "9","Room 9","Mar 24, 2016 3:58:13 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "10","Room 10","Mar 24, 2016 3:58:25 PM","1","1");
INSERT INTO `rms_room`  VALUES ( "11","Room 11","Apr 30, 2016 9:11:37 AM","1","1");
INSERT INTO `rms_room`  VALUES ( "12","Room 12","Nov 9, 2016 2:04:31 PM","1","12");
INSERT INTO `rms_room`  VALUES ( "13","Room 13","Nov 9, 2016 2:04:39 PM","1","12");
INSERT INTO `rms_room`  VALUES ( "14","Room 14","Nov 9, 2016 2:04:55 PM","1","12");
INSERT INTO `rms_room`  VALUES ( "15","Room 15","Nov 9, 2016 2:05:03 PM","1","12");
INSERT INTO `rms_room`  VALUES ( "16","Room 16","Nov 9, 2016 2:05:10 PM","1","12");
INSERT INTO `rms_room`  VALUES ( "17","Room 16","Nov 9, 2016 2:05:17 PM","1","12");
INSERT INTO `rms_room`  VALUES ( "18","Room 17","Nov 9, 2016 2:05:24 PM","1","12");


--
-- Tabel structure for table `rms_scholarship`
--
DROP TABLE  IF EXISTS `rms_scholarship`;
CREATE TABLE `rms_scholarship` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1' COMMENT '1 stateshcool, 2 exam in wu,3 other disc',
  `user_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='???????????disc ?????????? ??????????';



--
-- Tabel structure for table `rms_school_province`
--
DROP TABLE  IF EXISTS `rms_school_province`;
CREATE TABLE `rms_school_province` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `province_id` int(11) NOT NULL,
  `school_name` varchar(150) NOT NULL,
  `create_date` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `user_id` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

INSERT INTO `rms_school_province`  VALUES ( "1","1","?? ?????? ??????????","Sep 27, 2015 8:39:49 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "2","1","?? ??????????????","Sep 27, 2015 8:41:15 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "3","1","?? ?????????????????????","Sep 27, 2015 8:40:46 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "4","1","?? ?????????","Sep 27, 2015 8:40:21 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "5","1","?? ????????","Sep 27, 2015 8:39:33 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "6","1","?? ?????????","Sep 27, 2015 8:41:37 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "7","1","?? ??????????","Sep 27, 2015 8:42:26 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "8","1","?? ?????? ???????","Sep 27, 2015 8:45:44 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "9","1","??? ??????","Sep 27, 2015 8:46:48 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "10","1","?? ????????","Sep 27, 2015 8:47:01 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "11","1","?? ???????? ????????","Sep 27, 2015 8:47:26 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "12","1","?? ?????????????","Sep 27, 2015 8:50:09 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "13","1","?? ????????????","Sep 27, 2015 8:50:39 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "14","1","?? ????????","Sep 27, 2015 8:51:03 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "15","1","?? ?????????","Sep 27, 2015 8:51:55 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "16","1","?? ????????","Sep 27, 2015 8:52:34 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "17","1","?? ???????????????","Sep 27, 2015 8:52:49 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "18","1","??? ?????????","Sep 27, 2015 8:53:12 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "19","1","?? ??????????","Sep 27, 2015 8:54:48 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "20","1","?? ??? ???","Sep 27, 2015 8:55:16 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "21","5","?? ???????????????","Sep 27, 2015 10:06:07 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "22","5","?? ?????????","Sep 27, 2015 10:06:31 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "23","5","?? ??????","Sep 27, 2015 10:06:56 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "24","5","?? ?????????","Sep 27, 2015 10:07:22 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "25","5","?? ??????","Sep 27, 2015 10:07:41 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "26","5","?? ?????????","Sep 27, 2015 10:08:11 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "27","5","?? ????????","Sep 27, 2015 10:12:52 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "28","5","?? ?????????","Sep 27, 2015 10:13:14 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "29","5","?? ???????????","Sep 27, 2015 10:14:06 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "30","5","?? ??????","Sep 27, 2015 10:14:30 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "31","5","?? ???????????","Sep 27, 2015 10:15:09 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "32","5","?? ??????","Sep 27, 2015 10:15:39 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "33","5","?? ???????","Sep 27, 2015 10:16:00 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "34","5","?? ??????","Sep 27, 2015 10:16:50 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "35","5","?? ?????","Sep 27, 2015 10:17:40 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "36","5","?? ???????","Sep 27, 2015 10:17:51 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "37","5","?? ?????","Sep 27, 2015 10:18:16 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "38","5","?? ?????????","Sep 27, 2015 10:18:46 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "39","4","?? ??????????","Sep 27, 2015 10:21:33 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "40","4","?? ????","Sep 27, 2015 10:21:57 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "41","4","?? ??????????","Sep 27, 2015 10:22:23 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "42","4","?? ???????","Sep 27, 2015 10:22:44 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "43","4","?? ????????","Sep 27, 2015 10:22:59 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "44","4","?? ???????","Sep 27, 2015 10:23:17 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "45","4","?? ?????","Sep 27, 2015 10:23:26 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "46","4","?? ?????????","Sep 27, 2015 10:23:54 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "47","4","?? ????????","Sep 27, 2015 10:24:08 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "48","4","?? ????????","Sep 27, 2015 10:24:39 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "49","4","?? ???????","Sep 27, 2015 10:25:15 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "50","4","?? ???????????","Sep 27, 2015 10:26:21 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "51","4","?? ?????????","Sep 27, 2015 10:26:39 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "52","4","?? ??????","Sep 27, 2015 10:27:04 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "53","4","?? ?????","Sep 27, 2015 10:27:21 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "54","4","?? ???????","Sep 27, 2015 10:27:52 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "55","4","?? ?????","Sep 27, 2015 10:28:07 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "56","4","?? ????","Sep 27, 2015 10:28:26 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "57","4","?? ??????????","Sep 27, 2015 10:29:33 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "58","4","?? ??????????","Sep 27, 2015 10:29:55 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "59","2","?? ??????????","Sep 29, 2015 6:47:51 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "60","2","?? ???????","Sep 29, 2015 6:47:05 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "61","2","?? ?????","Sep 29, 2015 6:48:19 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "62","2","?? ?????","Sep 29, 2015 6:48:58 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "63","2","?? ????","Sep 29, 2015 6:49:23 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "64","2","?? ?????????","Sep 29, 2015 6:49:56 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "65","2","?? ????","Sep 29, 2015 6:50:16 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "66","2","?? ????????","Sep 29, 2015 6:50:53 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "67","2","?? ?????????","Sep 29, 2015 6:51:19 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "68","2","?? ????????","Sep 29, 2015 6:51:38 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "69","2","?? ????????????","Sep 29, 2015 6:51:55 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "70","2","?? ????????","Sep 29, 2015 6:52:26 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "71","2","?? ???????","Sep 29, 2015 6:52:49 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "72","2","?? ??????????","Sep 29, 2015 6:53:35 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "73","2","?? ???????","Sep 29, 2015 6:54:43 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "74","2","?? ????","Sep 29, 2015 6:54:58 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "75","2","?? ??????","Sep 29, 2015 6:55:29 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "76","2","?? ???????","Sep 29, 2015 6:56:36 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "77","2","?? ??????","Sep 29, 2015 6:56:50 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "78","2","?? ?????????????????","Sep 29, 2015 6:58:21 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "79","2","?? ??????????","Sep 29, 2015 6:58:41 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "80","2","?? ????","Sep 29, 2015 7:02:23 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "81","2","?? ????????","Sep 29, 2015 7:04:20 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "82","2","?? ??????????","Sep 29, 2015 7:04:38 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "83","2","?? ??????","Sep 29, 2015 7:07:31 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "84","3","?? ?????????","Sep 29, 2015 7:10:13 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "85","3","?? ?????","Sep 29, 2015 7:10:30 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "86","3","?? ?????","Sep 29, 2015 7:10:44 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "87","3","?? ?????????","Sep 29, 2015 7:11:08 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "88","3","?? ???????????","Sep 29, 2015 7:11:45 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "89","3","?? ????????????","Sep 29, 2015 7:12:03 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "90","3","?? ???????","Sep 29, 2015 7:12:14 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "91","3","?? ?????????????????","Sep 29, 2015 7:13:02 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "92","3","?? ????????","Sep 29, 2015 7:13:11 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "93","3","?? ?????????","Sep 29, 2015 7:13:22 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "94","3","?? ??????","Sep 29, 2015 7:13:50 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "95","3","?? ????????????","Sep 29, 2015 7:14:16 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "96","3","?? ??????????","Sep 29, 2015 7:15:17 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "97","3","?? ????????????","Sep 29, 2015 7:16:39 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "98","3","?? ??????","Sep 29, 2015 7:17:01 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "99","3","?? ??????","Sep 29, 2015 7:18:39 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "100","3","?? ???????","Sep 29, 2015 7:20:08 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "101","3","?? ?????????","Sep 29, 2015 7:21:23 PM","1","1");
INSERT INTO `rms_school_province`  VALUES ( "102","3","?? ??????????","Sep 29, 2015 7:24:04 PM","1","1");


--
-- Tabel structure for table `rms_score`
--
DROP TABLE  IF EXISTS `rms_score`;
CREATE TABLE `rms_score` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_score` varchar(100) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `reportdate` date DEFAULT NULL COMMENT 'for report date',
  `date_input` date DEFAULT NULL,
  `type_score` tinyint(2) DEFAULT NULL COMMENT '1=khmer subject score, 2=english subject score',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `rms_score`  VALUES ( "1","test1111","1","28","1","2017-05-17","2017-05-17","1");
INSERT INTO `rms_score`  VALUES ( "2","","1","28","1","2017-05-18","2017-05-18","");


--
-- Tabel structure for table `rms_score_detail`
--
DROP TABLE  IF EXISTS `rms_score_detail`;
CREATE TABLE `rms_score_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `score_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_no` varchar(100) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `score` float(10,2) DEFAULT NULL,
  `term` tinyint(4) DEFAULT NULL,
  `total_score` float DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `is_parent` tinyint(4) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1081 DEFAULT CHARSET=utf8;

INSERT INTO `rms_score_detail`  VALUES ( "757","1","1","12","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "758","1","1","12","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "759","1","1","12","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "760","1","1","12","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "761","1","1","12","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "762","1","1","12","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "763","1","1","12","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "764","1","1","12","","9","300.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "765","1","1","12","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "766","1","1","12","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "767","1","1","12","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "768","1","1","12","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "769","1","1","11","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "770","1","1","11","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "771","1","1","11","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "772","1","1","11","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "773","1","1","11","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "774","1","1","11","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "775","1","1","11","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "776","1","1","11","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "777","1","1","11","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "778","1","1","11","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "779","1","1","11","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "780","1","1","11","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "781","1","1","10","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "782","1","1","10","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "783","1","1","10","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "784","1","1","10","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "785","1","1","10","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "786","1","1","10","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "787","1","1","10","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "788","1","1","10","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "789","1","1","10","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "790","1","1","10","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "791","1","1","10","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "792","1","1","10","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "793","1","1","9","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "794","1","1","9","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "795","1","1","9","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "796","1","1","9","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "797","1","1","9","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "798","1","1","9","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "799","1","1","9","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "800","1","1","9","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "801","1","1","9","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "802","1","1","9","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "803","1","1","9","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "804","1","1","9","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "805","1","1","8","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "806","1","1","8","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "807","1","1","8","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "808","1","1","8","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "809","1","1","8","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "810","1","1","8","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "811","1","1","8","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "812","1","1","8","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "813","1","1","8","","8","50.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "814","1","1","8","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "815","1","1","8","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "816","1","1","8","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "817","1","1","7","","1","80.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "818","1","1","7","","2","20.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "819","1","1","7","","3","20.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "820","1","1","7","","4","10.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "821","1","1","7","","5","10.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "822","1","1","7","","6","10.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "823","1","1","7","","7","10.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "824","1","1","7","","9","42.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "825","1","1","7","","8","65.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "826","1","1","7","","10","65.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "827","1","1","7","","11","40.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "828","1","1","7","","13","25.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "829","1","1","6","","1","7.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "830","1","1","6","","2","2.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "831","1","1","6","","3","1.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "832","1","1","6","","4","1.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "833","1","1","6","","5","1.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "834","1","1","6","","6","1.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "835","1","1","6","","7","1.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "836","1","1","6","","9","8.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "837","1","1","6","","8","7.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "838","1","1","6","","10","5.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "839","1","1","6","","11","5.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "840","1","1","6","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "841","1","1","5","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "842","1","1","5","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "843","1","1","5","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "844","1","1","5","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "845","1","1","5","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "846","1","1","5","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "847","1","1","5","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "848","1","1","5","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "849","1","1","5","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "850","1","1","5","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "851","1","1","5","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "852","1","1","5","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "853","1","1","1","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "854","1","1","1","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "855","1","1","1","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "856","1","1","1","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "857","1","1","1","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "858","1","1","1","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "859","1","1","1","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "860","1","1","1","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "861","1","1","1","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "862","1","1","1","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "863","1","1","1","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "864","1","1","1","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "973","2","1","12","","1","90.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "974","2","1","12","","2","20.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "975","2","1","12","","3","15.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "976","2","1","12","","4","10.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "977","2","1","12","","5","15.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "978","2","1","12","","6","15.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "979","2","1","12","","7","15.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "980","2","1","12","","9","85.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "981","2","1","12","","8","85.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "982","2","1","12","","10","70.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "983","2","1","12","","11","40.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "984","2","1","12","","13","30.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "985","2","1","11","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "986","2","1","11","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "987","2","1","11","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "988","2","1","11","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "989","2","1","11","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "990","2","1","11","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "991","2","1","11","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "992","2","1","11","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "993","2","1","11","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "994","2","1","11","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "995","2","1","11","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "996","2","1","11","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "997","2","1","10","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "998","2","1","10","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "999","2","1","10","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1000","2","1","10","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1001","2","1","10","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1002","2","1","10","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1003","2","1","10","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1004","2","1","10","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1005","2","1","10","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1006","2","1","10","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1007","2","1","10","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1008","2","1","10","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1009","2","1","9","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1010","2","1","9","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1011","2","1","9","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1012","2","1","9","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1013","2","1","9","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1014","2","1","9","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1015","2","1","9","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1016","2","1","9","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1017","2","1","9","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1018","2","1","9","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1019","2","1","9","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1020","2","1","9","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1021","2","1","8","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1022","2","1","8","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1023","2","1","8","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1024","2","1","8","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1025","2","1","8","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1026","2","1","8","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1027","2","1","8","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1028","2","1","8","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1029","2","1","8","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1030","2","1","8","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1031","2","1","8","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1032","2","1","8","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1033","2","1","7","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1034","2","1","7","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1035","2","1","7","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1036","2","1","7","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1037","2","1","7","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1038","2","1","7","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1039","2","1","7","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1040","2","1","7","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1041","2","1","7","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1042","2","1","7","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1043","2","1","7","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1044","2","1","7","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1045","2","1","6","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1046","2","1","6","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1047","2","1","6","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1048","2","1","6","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1049","2","1","6","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1050","2","1","6","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1051","2","1","6","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1052","2","1","6","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1053","2","1","6","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1054","2","1","6","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1055","2","1","6","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1056","2","1","6","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1057","2","1","5","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1058","2","1","5","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1059","2","1","5","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1060","2","1","5","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1061","2","1","5","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1062","2","1","5","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1063","2","1","5","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1064","2","1","5","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1065","2","1","5","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1066","2","1","5","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1067","2","1","5","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1068","2","1","5","","13","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1069","2","1","1","","1","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1070","2","1","1","","2","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1071","2","1","1","","3","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1072","2","1","1","","4","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1073","2","1","1","","5","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1074","2","1","1","","6","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1075","2","1","1","","7","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1076","2","1","1","","9","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1077","2","1","1","","8","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1078","2","1","1","","10","0.00","","","","1","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1079","2","1","1","","11","0.00","","","","0","","1","","28");
INSERT INTO `rms_score_detail`  VALUES ( "1080","2","1","1","","13","0.00","","","","0","","1","","28");


--
-- Tabel structure for table `rms_servicefee`
--
DROP TABLE  IF EXISTS `rms_servicefee`;
CREATE TABLE `rms_servicefee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `academic_year` tinyint(4) DEFAULT NULL COMMENT 'academic_year from tuition fee',
  `note` varchar(100) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_servicefee`  VALUES ( "1","1","","2016-10-04","1","28");


--
-- Tabel structure for table `rms_servicefee_detail`
--
DROP TABLE  IF EXISTS `rms_servicefee_detail`;
CREATE TABLE `rms_servicefee_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_feeid` varchar(50) NOT NULL COMMENT 'end charector 1 for paytype',
  `service_id` int(11) NOT NULL,
  `payment_term` tinyint(4) NOT NULL COMMENT '1=reil,2=price dollar,3=price 3',
  `price_fee` float NOT NULL,
  `remark` text,
  PRIMARY KEY (`id`,`service_feeid`)
) ENGINE=InnoDB AUTO_INCREMENT=1013 DEFAULT CHARSET=utf8;

INSERT INTO `rms_servicefee_detail`  VALUES ( "865","1","11","1","23","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "866","1","11","2","66","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "867","1","11","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "868","1","11","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "869","1","12","1","42","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "870","1","12","2","123","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "871","1","12","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "872","1","12","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "873","1","13","1","18","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "874","1","13","2","51","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "875","1","13","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "876","1","13","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "877","1","14","1","32","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "878","1","14","2","93","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "879","1","14","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "880","1","14","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "881","1","15","1","12","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "882","1","15","2","33","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "883","1","15","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "884","1","15","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "885","1","16","1","8","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "886","1","16","2","24","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "887","1","16","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "888","1","16","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "889","1","17","1","15","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "890","1","17","2","42","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "891","1","17","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "892","1","17","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "893","1","18","1","26","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "894","1","18","2","75","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "895","1","18","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "896","1","18","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "897","1","19","1","13","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "898","1","19","2","36","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "899","1","19","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "900","1","19","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "901","1","20","1","22","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "902","1","20","2","63","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "903","1","20","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "904","1","20","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "905","1","21","1","12","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "906","1","21","2","33","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "907","1","21","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "908","1","21","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "909","1","22","1","20","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "910","1","22","2","57","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "911","1","22","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "912","1","22","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "913","1","23","1","11","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "914","1","23","2","30","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "915","1","23","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "916","1","23","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "917","1","24","1","18","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "918","1","24","2","51","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "919","1","24","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "920","1","24","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "921","1","25","1","11","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "922","1","25","2","30","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "923","1","25","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "924","1","25","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "925","1","26","1","18","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "926","1","26","2","51","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "927","1","26","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "928","1","26","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "929","1","27","1","20","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "930","1","27","2","57","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "931","1","27","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "932","1","27","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "933","1","28","1","12","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "934","1","28","2","33","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "935","1","28","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "936","1","28","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "937","1","29","1","10","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "938","1","29","2","27","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "939","1","29","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "940","1","29","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "941","1","30","1","16","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "942","1","30","2","45","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "943","1","30","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "944","1","30","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "945","1","31","1","9","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "946","1","31","2","24","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "947","1","31","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "948","1","31","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "949","1","32","1","14","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "950","1","32","2","39","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "951","1","32","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "952","1","32","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "953","1","33","1","8","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "954","1","33","2","21","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "955","1","33","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "956","1","33","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "957","1","34","1","12","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "958","1","34","2","33","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "959","1","34","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "960","1","34","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "961","1","35","1","10","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "962","1","35","2","27","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "963","1","35","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "964","1","35","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "965","1","39","1","12","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "966","1","39","2","33","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "967","1","39","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "968","1","39","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "969","1","40","1","20","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "970","1","40","2","57","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "971","1","40","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "972","1","40","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "973","1","41","1","10","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "974","1","41","2","27","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "975","1","41","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "976","1","41","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "977","1","42","1","16","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "978","1","42","2","45","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "979","1","42","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "980","1","42","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "981","1","43","1","16","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "982","1","43","2","45","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "983","1","43","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "984","1","43","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "985","1","44","1","11","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "986","1","44","2","30","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "987","1","44","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "988","1","44","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "989","1","45","1","18","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "990","1","45","2","51","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "991","1","45","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "992","1","45","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "993","1","46","1","9","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "994","1","46","2","24","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "995","1","46","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "996","1","46","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "997","1","47","1","14","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "998","1","47","2","39","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "999","1","47","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1000","1","47","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1001","1","48","1","20","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1002","1","48","2","57","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1003","1","48","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1004","1","48","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1005","1","49","1","17","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1006","1","49","2","48","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1007","1","49","3","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1008","1","49","4","0","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1009","1","124","1","7","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1010","1","124","2","7","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1011","1","124","3","7","");
INSERT INTO `rms_servicefee_detail`  VALUES ( "1012","1","124","4","7","");


--
-- Tabel structure for table `rms_set_group_exam`
--
DROP TABLE  IF EXISTS `rms_set_group_exam`;
CREATE TABLE `rms_set_group_exam` (
  `gexam_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subexam_id` int(11) DEFAULT NULL,
  `intake` int(11) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `date_exame` date DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `session_exam` tinyint(4) DEFAULT NULL,
  `major_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  PRIMARY KEY (`gexam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_setting`
--
DROP TABLE  IF EXISTS `rms_setting`;
CREATE TABLE `rms_setting` (
  `code` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyName` varchar(450) DEFAULT NULL,
  `keyValue` varchar(4500) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `access_type` int(11) NOT NULL DEFAULT '1' COMMENT '1=access all,2=foundation access,3=accounting access,4=no access',
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO `rms_setting`  VALUES ( "1","sms-warnning-kh","???????????????????????????????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "2","system_name","Student Management System","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "3","branch","???? ?????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "4","power_by","??? ???? ?????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "5","label_animation","","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "6","branch-tel","TEL :(855-23) 998 233, (855-12) 200 988","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "7","branch_email","E-mail : info@asean-heritage.com","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "8","branch_add","??????? 316z ????? 369 ???????????????? ????????????? ????????????\r\n","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "10","logo-path-name","images/logo.png","1","4","1");
INSERT INTO `rms_setting`  VALUES ( "11","rate","4100","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "12","branch-add","??????? ??????? 316z ????? 369 ???????????????? ????????????? ????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "13","tel","(855) 23 864 477 / (855) 23 864 400","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "14","mainbranch-subtitle","???????????????, ???????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "15","marquee-word","???? ????????? ???????????? ??????????????-?????????-???????????-?????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "16","services","???????????????, ???????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "18","branch_en","???? ?????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "19","request_student","????????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "20","request_student_en","STUDENT REQUEST FORM","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "21","footer_branch","??????? 316z ????? 369 ???????????????? ????????????? ????????????\r\n","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "22","foot_phone","Phone:(855) 095 222 778 /Phone:(855) 070 531 717","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "23","f_email_website","Fax:(855)23 864 888 /E-mail :Null","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "24","reciept_en","OFFICAL RECEIPT","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "25","reciept_kh","???????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "26","This is My Test","ssss","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "27","set_service_label","0","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "28","co_prefix","2","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "29","website","www.cam-app.com","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "30","camappadress","?????????:??????? ??? ???????? ??? ??????? ????????? ?????? ???????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "31","camapptel","Tel : 012 404 192 ,070 756 457","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "32","camappservice","???????????????????????????????? ??? ???????????????????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "33","camappservices","1. Web Development,2. Web Based Application,3. Web Hosting,4. Domain Registration,5. Update& Maintenance Website,6. Web Administrator,7. Mobile App(iOS&Android),8. Computer Networking","0","1","1");


--
-- Tabel structure for table `rms_situation`
--
DROP TABLE  IF EXISTS `rms_situation`;
CREATE TABLE `rms_situation` (
  `situ_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `situ_name` varchar(100) DEFAULT NULL,
  `create_date` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `user_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`situ_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `rms_situation`  VALUES ( "1","??????","Sep 28, 2015 1:10:31 PM","1","1");
INSERT INTO `rms_situation`  VALUES ( "2","?????????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "3","???????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "4","??????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "5","????????????????????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "6","?????????????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "7","?????????????????????????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "8","?????","","1","");
INSERT INTO `rms_situation`  VALUES ( "9","????????????????","","1","");
INSERT INTO `rms_situation`  VALUES ( "10","?????? ? ???????","","1","");
INSERT INTO `rms_situation`  VALUES ( "12","???????????","Sep 28, 2015 11:00:33 PM","1","1");


--
-- Tabel structure for table `rms_staff_position`
--
DROP TABLE  IF EXISTS `rms_staff_position`;
CREATE TABLE `rms_staff_position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  `create_date` date DEFAULT NULL,
  `user_id` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_staff_position`  VALUES ( "1","?????????????????? ?-?? ????????","1","2017-02-01","28");
INSERT INTO `rms_staff_position`  VALUES ( "2","admin","1","2017-02-02","28");
INSERT INTO `rms_staff_position`  VALUES ( "3","Asistant","1","2017-02-02","28");


--
-- Tabel structure for table `rms_stu_request`
--
DROP TABLE  IF EXISTS `rms_stu_request`;
CREATE TABLE `rms_stu_request` (
  `request_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `request_title` varchar(255) NOT NULL,
  `modify_date` varchar(30) NOT NULL,
  `is_active` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 active ,0 deactive',
  `user_id` int(11) NOT NULL COMMENT 'user modify and create',
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `rms_stu_request`  VALUES ( "1","?????????????????????","1/11/14","1","1");
INSERT INTO `rms_stu_request`  VALUES ( "2","???????????????","1/11/14","1","1");
INSERT INTO `rms_stu_request`  VALUES ( "3","??????????????????","1/11/14","1","1");
INSERT INTO `rms_stu_request`  VALUES ( "4","????????????????????????????","1/11/14","1","1");
INSERT INTO `rms_stu_request`  VALUES ( "5","??????????","1/11/14","1","1");
INSERT INTO `rms_stu_request`  VALUES ( "6","??????","1/11/14","1","1");


--
-- Tabel structure for table `rms_student`
--
DROP TABLE  IF EXISTS `rms_student`;
CREATE TABLE `rms_student` (
  `stu_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `stu_type` tinyint(3) DEFAULT '1' COMMENT '1=?????????(kid-6),2=??????(7-12),3=English and other subject',
  `user_id` int(11) DEFAULT NULL,
  `stu_enname` varchar(50) DEFAULT NULL,
  `stu_khname` varchar(100) DEFAULT NULL,
  `stu_code` varchar(40) DEFAULT NULL,
  `academic_year` int(11) DEFAULT NULL,
  `degree` int(4) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `session` tinyint(4) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL COMMENT '1=m,2=f',
  `nationality` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `tel` varchar(40) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `address` text,
  `home_num` varchar(20) DEFAULT NULL,
  `street_num` varchar(20) DEFAULT NULL,
  `village_name` varchar(100) DEFAULT NULL,
  `commune_name` varchar(100) DEFAULT NULL,
  `district_name` varchar(100) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `lang_level` int(11) DEFAULT NULL,
  `room` tinyint(4) DEFAULT NULL,
  `father_enname` varchar(50) DEFAULT NULL,
  `father_khname` varchar(50) DEFAULT NULL,
  `father_dob` date DEFAULT NULL,
  `father_nation` varchar(50) DEFAULT NULL,
  `father_job` varchar(100) DEFAULT NULL,
  `father_phone` varchar(30) DEFAULT NULL,
  `mother_khname` varchar(120) DEFAULT NULL,
  `mother_enname` varchar(120) DEFAULT NULL,
  `mother_dob` date DEFAULT NULL,
  `mother_nation` varchar(50) DEFAULT NULL,
  `mother_job` varchar(50) DEFAULT NULL,
  `mother_phone` varchar(30) DEFAULT NULL,
  `guardian_enname` varchar(120) DEFAULT NULL,
  `guardian_khname` varchar(120) DEFAULT NULL,
  `guardian_dob` date DEFAULT NULL,
  `guardian_nation` varchar(100) DEFAULT NULL,
  `guardian_document` varchar(100) DEFAULT NULL,
  `guardian_job` int(11) DEFAULT NULL,
  `guardian_tel` varchar(40) DEFAULT NULL,
  `guardian_email` varchar(30) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL COMMENT 'place of birth',
  `vill_id` int(10) DEFAULT NULL COMMENT 'place of birth',
  `comm_id` int(5) DEFAULT NULL COMMENT 'place of birth',
  `dis_id` int(4) DEFAULT NULL COMMENT 'place of birth',
  `pro_id` int(4) DEFAULT NULL COMMENT 'place of birth',
  `status` tinyint(4) DEFAULT '1',
  `remark` text,
  `is_stu_new` tinyint(4) DEFAULT '1' COMMENT '(1=>stu_new,0=>stu_old)',
  `is_subspend` tinyint(4) DEFAULT '0' COMMENT '0=normal,1=subspend,2=stop',
  `create_date` date DEFAULT NULL COMMENT 'create fro rec',
  `is_setgroup` tinyint(4) DEFAULT '0',
  `teacher_id` int(11) DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL,
  `group` int(11) DEFAULT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student`  VALUES ( "1","1","1","28","Sok Chanreaksmey","Sok Chanreaksmey","00001","1","1","2","1","1","","2017-03-03","0","Sok Chanreaksmey","","","","","","","","","","1","","","","","","","","","","","","","","","","","","","","","","7116","827","94","11","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "2","1","2","28","San Dara","San Dara","00001","1","2","10","1","1","San Dara","2000-03-03","0","San Dara","","","San Dara","San Dara","San Dara","San Dara","San Dara","1","","1","San Dara","","0000-00-00","San Dara","0","San Dara","","San Dara","0000-00-00","San Dara","0","San Dara","San Dara","","0000-00-00","San Dara","","0","San Dara","","San Dara","0","0","0","-1","1","","0","0","2017-03-03","0","","","");
INSERT INTO `rms_student`  VALUES ( "3","1","1","28","Chea Socheata","Chea Socheata","00002","1","1","3","1","1","","2017-03-03","0","Chea Socheata","","","","","","","","","","2","","","","","","","","","","","","","","","","","","","","","Chea Socheata","0","0","0","-1","1","","1","0","2017-03-03","0","","","");
INSERT INTO `rms_student`  VALUES ( "4","1","1","28","Hann Nita","Hann Nita","00003","1","1","7","1","1","","2017-03-03","0","Hann Nita","","","","","","","","","","6","","","","","","","","","","","","","","","","","","","","","Hann Nita","0","0","0","-1","1","","1","0","2017-03-03","0","","","");
INSERT INTO `rms_student`  VALUES ( "5","1","1","28","Lana","Lana","00004","1","1","2","1","1","Lana","2000-03-03","","Lana","","","Lana","Lana","Lana","Lana","Lana","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Lana","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "6","1","1","28","Walcott","Walcott","00005","1","1","2","1","1","","2000-03-03","","Walcott","","","Walcott","Walcott","Walcott","Walcott","Walcott","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Walcott","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "7","1","1","28","Sanchez","Sanchez","00006","1","1","2","1","1","Sanchez","2000-03-03","0","Sanchez","","","Sanchez","Sanchez","Sanchez","Sanchez","Sanchez","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Sanchez","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "8","1","1","28","Ozil","Ozil","00007","1","1","2","1","1","","2000-03-03","","Ozil","","","Ozil","Ozil","Ozil","Ozil","Ozil","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Ozil","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "9","1","1","28","Ox","Ox","00008","1","1","2","1","1","","2000-03-03","","Ox","","","Ox","Ox","Ox","Ox","Ox","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Ox","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "10","1","1","28","Santi","Santi","00009","1","1","2","1","1","","2000-03-03","","Santi","","","Santi","Santi","Santi","Santi","Santi","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Santi","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "11","1","1","28","Kos","Kos","00010","1","1","2","1","1","Kos","2000-03-03","","Kos","","","Kos","Kos","Kos","Kos","Kos","1","","1","","","0000-00-00","","0","","","","0000-00-00","","0","","","","0000-00-00","","","0","","","Kos","0","0","0","-1","1","","0","0","2017-03-03","1","","","");
INSERT INTO `rms_student`  VALUES ( "12","1","1","27","Sok Dararatanak","??? ?????????","00011","1","1","2","1","1","","1999-03-07","17","","","","","","","","","","","1","","","","","","","","","","","","","","","","","","","","","","10295","1205","145","17","1","","1","0","2017-03-07","1","","","");
INSERT INTO `rms_student`  VALUES ( "13","1","2","28","drhdyrydr","rhdrhdrf","00002","1","2","9","1","1","","2017-03-31","0","","","","","","","","","","","8","","","","","","","","","","","","","","","","","","","","","","0","0","0","-1","1","","1","0","2017-03-31","1","","","");
INSERT INTO `rms_student`  VALUES ( "14","1","1","28","Test12","Test12","00012","1","1","2","2","1","","2017-04-05","0","","","","","","","","","","","1","","","","","","","","","","","","","","","","","","","","","","0","0","0","-1","1","??????????????","0","0","2017-04-05","1","","","");
INSERT INTO `rms_student`  VALUES ( "15","1","1","28","","","00013","1","1","3","2","1","","2017-05-17","","","","","","","","","","","","2","","","","","","","","","","","","","","","","","","","","","","","","","","1","","1","0","2017-05-17","0","","","");
INSERT INTO `rms_student`  VALUES ( "16","1","3","28","Dan Theo","Dan Theo","00001/CAS/ENG","1","3","14","1","1","","2017-05-17","","Dan Theo","","","","","","","","","","7","","","","","","","","","","","","","","","","","","","","","","","","","","1","Dan Theo","1","0","2017-05-17","1","","","");
INSERT INTO `rms_student`  VALUES ( "17","1","2","28","sdgsd","fhf","00003","1","2","8","1","1","","2017-05-18","","","","","","","","","","","","7","","","","","","","","","","","","","","","","","","","","","","","","","","1","","1","0","2017-05-18","1","","","");
INSERT INTO `rms_student`  VALUES ( "18","1","1","28","Sok Thida","??? ????a","00014","1","1","3","1","2","","2004-04-13","","015 236 147a","","","","","","","","","","2","","","","","","","","","","","","","","","","","","","","","","","","","","1","","1","0","2017-05-24","1","","","");
INSERT INTO `rms_student`  VALUES ( "19","1","1","28","Sok Thida","??? ????a","00015","1","1","7","1","2","","2004-04-13","","015 236 147a","","","","","","","","","","6","","","","","","","","","","","","","","","","","","","","","","","","","","1","","1","0","2017-05-24","1","","","");


--
-- Tabel structure for table `rms_student_attendence`
--
DROP TABLE  IF EXISTS `rms_student_attendence`;
CREATE TABLE `rms_student_attendence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `date_attendence` date DEFAULT NULL,
  `date_create` date DEFAULT NULL,
  `modify_date` date DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL COMMENT 'for high school attendence by subject',
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_attendence`  VALUES ( "1","3","1","2017-02-07","2017-02-07","2017-02-07","0","1","1");
INSERT INTO `rms_student_attendence`  VALUES ( "2","3","2","2017-02-07","2017-02-07","2017-02-07","0","1","1");
INSERT INTO `rms_student_attendence`  VALUES ( "3","3","3","2017-02-07","2017-02-07","2017-02-07","0","1","1");
INSERT INTO `rms_student_attendence`  VALUES ( "4","3","5","2017-02-07","2017-02-07","2017-02-07","14","1","1");
INSERT INTO `rms_student_attendence`  VALUES ( "5","3","5","2017-02-07","2017-02-07","2017-02-07","15","1","1");
INSERT INTO `rms_student_attendence`  VALUES ( "6","1","3","2017-03-02","2017-03-02","2017-03-02","0","1","28");
INSERT INTO `rms_student_attendence`  VALUES ( "7","1","1","2017-05-17","2017-05-17","2017-05-17","0","1","28");
INSERT INTO `rms_student_attendence`  VALUES ( "8","1","1","2017-05-17","2017-05-17","2017-05-17","0","1","28");
INSERT INTO `rms_student_attendence`  VALUES ( "9","1","1","2017-05-17","2017-05-17","2017-05-17","0","1","28");
INSERT INTO `rms_student_attendence`  VALUES ( "10","1","1","2017-05-17","2017-05-17","2017-05-17","0","1","28");


--
-- Tabel structure for table `rms_student_attendence_detail`
--
DROP TABLE  IF EXISTS `rms_student_attendence_detail`;
CREATE TABLE `rms_student_attendence_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attendence_id` int(11) DEFAULT NULL,
  `stu_id` int(11) DEFAULT NULL,
  `attendence_status` tinyint(4) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_attendence_detail`  VALUES ( "1","1","3","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "2","2","1","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "3","3","5","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "4","4","10","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "5","5","10","3","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "7","7","6","3","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "8","7","1","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "9","9","12","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "10","9","11","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "11","9","10","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "12","9","9","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "13","9","8","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "14","9","7","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "15","9","6","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "16","9","5","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "17","9","1","2","");
INSERT INTO `rms_student_attendence_detail`  VALUES ( "18","10","12","3","");


--
-- Tabel structure for table `rms_student_change_group`
--
DROP TABLE  IF EXISTS `rms_student_change_group`;
CREATE TABLE `rms_student_change_group` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) DEFAULT NULL,
  `from_group` int(11) DEFAULT NULL,
  `to_group` int(11) DEFAULT NULL,
  `moving_date` date DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_change_group`  VALUES ( "1","1","1","2","2017-02-07","","1","1");
INSERT INTO `rms_student_change_group`  VALUES ( "2","1","1","2","2017-02-07","","1","1");
INSERT INTO `rms_student_change_group`  VALUES ( "3","1","1","2","2017-02-07","","1","1");


--
-- Tabel structure for table `rms_student_drop`
--
DROP TABLE  IF EXISTS `rms_student_drop`;
CREATE TABLE `rms_student_drop` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '1' COMMENT 'acc, foundation, other year',
  `stu_id` int(11) DEFAULT NULL COMMENT 'id from student group',
  `status` tinyint(4) DEFAULT NULL,
  `date_stop` date DEFAULT NULL,
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  `reason` text,
  `create_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_drop`  VALUES ( "1","2","4","1","2016-12-08","","1","test","2016-12-08");
INSERT INTO `rms_student_drop`  VALUES ( "2","2","22","0","2017-01-23","","28","00","2017-01-20");


--
-- Tabel structure for table `rms_student_foundation_certificate`
--
DROP TABLE  IF EXISTS `rms_student_foundation_certificate`;
CREATE TABLE `rms_student_foundation_certificate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_stuid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8_hungarian_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



--
-- Tabel structure for table `rms_student_group_history`
--
DROP TABLE  IF EXISTS `rms_student_group_history`;
CREATE TABLE `rms_student_group_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `stu_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_student_namecard`
--
DROP TABLE  IF EXISTS `rms_student_namecard`;
CREATE TABLE `rms_student_namecard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_student_org`
--
DROP TABLE  IF EXISTS `rms_student_org`;
CREATE TABLE `rms_student_org` (
  `stu_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stu_type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 = bac,2=gep',
  `stu_code` varchar(30) NOT NULL COMMENT 'student code',
  `user_id` int(11) DEFAULT NULL,
  `fm_user` tinyint(4) DEFAULT NULL COMMENT '1=foundation modified ',
  `stu_card` varchar(15) DEFAULT NULL,
  `stu_enname` varchar(50) DEFAULT NULL,
  `stu_khname` varchar(100) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL COMMENT '1=m,2=f',
  `dob` date DEFAULT NULL,
  `pob` varchar(250) DEFAULT NULL,
  `degree` tinyint(4) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `major_id` tinyint(4) DEFAULT NULL,
  `batch` tinyint(4) DEFAULT NULL,
  `session` tinyint(4) DEFAULT NULL,
  `year` tinyint(4) DEFAULT NULL,
  `nation` tinyint(4) DEFAULT NULL,
  `address` text,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `father_name` varchar(50) DEFAULT NULL,
  `father_nation` varchar(50) DEFAULT NULL,
  `father_job` varchar(100) DEFAULT NULL,
  `father_phone` varchar(30) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `mother_nation` tinyint(4) DEFAULT NULL,
  `mother_job` varchar(50) NOT NULL,
  `mother_phone` varchar(30) DEFAULT NULL,
  `situation` int(10) unsigned DEFAULT NULL,
  `composition` varchar(50) DEFAULT NULL,
  `from_school` tinyint(4) DEFAULT NULL,
  `finish_bacc` int(10) unsigned DEFAULT NULL,
  `certificate_code` varchar(50) DEFAULT NULL,
  `bacc_score` float unsigned DEFAULT NULL COMMENT 'bacc score ',
  `mention` varchar(2) DEFAULT NULL COMMENT 'rank for bacc',
  `student_add` int(11) DEFAULT NULL COMMENT 'student address',
  `compositions` int(11) DEFAULT NULL COMMENT '??????????????',
  `remark` text,
  `status` tinyint(4) DEFAULT '1',
  `acc_stu_new` tinyint(4) DEFAULT NULL COMMENT '(1=new student,0=old )',
  `is_stu_new` tinyint(4) DEFAULT '1' COMMENT '(1=>stu_new,0=>stu_old)',
  `is_hold` tinyint(4) DEFAULT NULL COMMENT '(1=hold,0=un hold,2  void)',
  `is_subspend` tinyint(4) DEFAULT NULL COMMENT '0=normal,2=subspend,3=stop',
  `is_exam` tinyint(4) DEFAULT '0' COMMENT '(0=not yet exam,1=exist in exam list)',
  `create_date` varchar(50) DEFAULT NULL COMMENT 'create fro rec',
  `modify_date` varchar(50) DEFAULT NULL COMMENT 'last foundation modify date',
  PRIMARY KEY (`stu_id`,`stu_code`,`mother_job`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_student_payment`
--
DROP TABLE  IF EXISTS `rms_student_payment`;
CREATE TABLE `rms_student_payment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_type` tinyint(4) DEFAULT NULL COMMENT '1=both(tuitionfee and service or product),2=tuitionfee ,3=service & product',
  `student_id` int(11) DEFAULT NULL,
  `payfor_type` tinyint(4) DEFAULT NULL COMMENT '1=bacII (kid-12),2=English and other,3=service and product',
  `receipt_number` varchar(30) DEFAULT NULL,
  `subtotal` float(10,2) DEFAULT NULL,
  `year` tinyint(4) DEFAULT NULL COMMENT 'Acardemic year',
  `degree` int(11) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `session` int(11) DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL COMMENT '?????????????????????',
  `payment_term` tinyint(4) DEFAULT NULL,
  `start_hour` int(11) DEFAULT NULL,
  `end_hour` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `scholarship` int(11) DEFAULT NULL,
  `ex_rate` float(10,2) DEFAULT NULL,
  `tuition_fee` float(10,2) DEFAULT NULL COMMENT '???????????',
  `discount_percent` int(11) DEFAULT NULL COMMENT '?????????????',
  `total_payment` float(10,2) DEFAULT NULL COMMENT 'money after discount',
  `other_fee` float(10,2) DEFAULT NULL,
  `admin_fee` float(10,2) DEFAULT NULL,
  `total` float(10,2) DEFAULT NULL COMMENT '?????????????? include admin and other fee',
  `receive_amount` float(10,2) DEFAULT NULL,
  `paid_amount` float DEFAULT NULL COMMENT '????????????',
  `return_amount` float(10,2) DEFAULT NULL,
  `balance_due` float DEFAULT NULL COMMENT '????????????????????????',
  `discount_fix` int(11) DEFAULT NULL COMMENT '?????????????',
  `amount_in_khmer` varchar(50) DEFAULT NULL COMMENT '????????????????????',
  `forward_from_prev` float DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `references` text,
  `user_id` int(11) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `is_new` tinyint(4) DEFAULT '0' COMMENT '1=new student register',
  `is_subspend` tinyint(4) DEFAULT '0' COMMENT '0=studying,1=subspend,2=stop',
  `student_type` tinyint(4) DEFAULT NULL COMMENT '1=''new stuent'',2=''subspend'',3=''old student''',
  `grand_total` float(10,2) DEFAULT NULL,
  `grand_paid_amount` float DEFAULT NULL,
  `grand_balance` float DEFAULT NULL,
  `grand_return` float DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `is_void` tinyint(4) DEFAULT '0' COMMENT '0=no void , 1= void',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_payment`  VALUES ( "1","1","1","1","000001","","1","1","2","1","7:30 - 10:30","4","","","","","4100.00","320.00","10","288.00","","3.20","288.00","288.00","288","","0","","","","1","","","28","2017-03-03","0","0","1","303.20","303.2","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "2","2","3","1","000002","","1","1","3","1","7:30 - 10:30","3","","","","","","165.00","0","165.00","","","165.00","165.00","165","","0","","","","2","","","28","2017-03-03","0","0","1","166.65","166.65","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "3","2","4","1","000003","","1","1","7","1","7:30 - 10:30","3","","","","","","175.00","0","175.00","","","175.00","175.00","175","","0","","","","6","","","28","2017-03-03","0","0","1","176.75","176.75","0","","1","1");
INSERT INTO `rms_student_payment`  VALUES ( "4","1","12","1","000004","","1","1","2","1","7:30 - 10:30","3","","","","","4100.00","165.00","20","132.00","","1.65","132.00","132.00","132","","0","","","","1","","","27","2017-03-07","0","0","1","201.65","201.65","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "5","2","2","1","000005","","1","2","10","1","7:30 - 11:30","3","","","","","","250.00","0","250.00","","","250.00","250.00","250","","0","","","","1","","","28","2017-03-10","0","0","3","252.50","252.5","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "6","1","1","1","000006","","1","1","2","1","7:30 - 10:30","1","","","","","4100.00","35.00","0","35.00","","0.35","35.00","35.00","35","","0","","","","1","","","28","2017-03-10","0","0","3","87.35","87.35","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "7","1","7","1","000007","","1","1","2","1","7:30 - 10:30","3","","","","","4100.00","165.00","0","165.00","","1.65","165.00","165.00","165","","0","","","","1","","","28","2017-03-10","0","0","3","218.65","218.65","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "8","1","13","1","000008","","1","2","9","1","7:30 - 11:30","1","","","","","4100.00","45.00","0","45.00","","0.45","45.00","45.00","45","","0","","","","8","","","28","2017-03-31","0","0","1","87.45","87.45","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "9","1","14","1","000009","","1","1","2","2","13:30 - 16:30","1","","","","","4100.00","35.00","0","35.00","","0.35","35.00","30.00","30","","5","","","","1","","","28","2017-04-05","0","0","1","67.35","62.35","5","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "10","2","14","1","000010","","1","1","2","2","13:30 - 16:30","1","","","","","","5.00","0","5.00","","","5.00","5.00","5","","0","","","","1","??????????????","","28","2017-04-05","0","0","3","5.00","5","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "11","1","15","1","000011","","1","1","3","2","13:30 - 16:30","1","","","","","4100.00","35.00","0","35.00","","0.35","35.00","35.00","35","","0","","","","2","","","28","2017-05-17","0","0","1","43.35","43.35","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "12","2","16","2","000012","","1","3","14","1","7:30 - 10:30","3","","","","","","170.00","0","170.00","","","170.00","170.00","170","","0","","","","7","Dan Theo","","28","2017-05-17","0","0","1","171.70","171.7","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "13","1","17","1","000013","","1","2","8","1","7:30 - 11:30","1","","","","","4100.00","45.00","0","45.00","","0.45","45.00","45.00","45","","0","","","","7","","","28","2017-05-18","0","0","1","71.45","71.45","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "14","1","18","1","000014","","1","1","3","1","7:30 - 10:30","3","","","","","4100.00","165.00","0","165.00","","1.65","165.00","165.00","165","","0","","","","2","","","28","2017-05-24","0","0","1","198.65","198.65","0","","1","0");
INSERT INTO `rms_student_payment`  VALUES ( "15","1","19","1","000015","","1","1","7","1","7:30 - 10:30","1","","","","","4100.00","40.00","0","40.00","","0.40","40.00","40.00","40","","0","","","","6","","","28","2017-05-24","0","0","1","66.40","66.4","0","","1","0");


--
-- Tabel structure for table `rms_student_paymentdetail`
--
DROP TABLE  IF EXISTS `rms_student_paymentdetail`;
CREATE TABLE `rms_student_paymentdetail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT '1=registra, 2=gep, 3=Service , 4=product',
  `service_id` int(11) DEFAULT NULL COMMENT 'yr of payment',
  `payment_term` tinyint(4) DEFAULT NULL,
  `fee` float(10,2) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `discount_percent` int(11) DEFAULT NULL COMMENT '?????????????',
  `admin_fee` float DEFAULT NULL,
  `subtotal` float(10,2) DEFAULT NULL,
  `paidamount` float(10,2) DEFAULT NULL COMMENT '??????????????????????',
  `balance` float(10,2) DEFAULT NULL COMMENT '??????????????????????',
  `start_date` varchar(30) DEFAULT NULL,
  `validate` date DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `references` text,
  `user_id` int(11) DEFAULT NULL,
  `is_complete` tinyint(4) DEFAULT '1' COMMENT 'complete=1,uncomplete=0',
  `comment` varchar(100) DEFAULT NULL COMMENT '??????,??????????',
  `discount_fix` int(11) DEFAULT NULL COMMENT '?????????????',
  `is_start` varchar(10) DEFAULT '1' COMMENT 'service ???????????',
  `is_parent` varchar(10) DEFAULT NULL COMMENT 'id payment detail updated',
  `is_suspend` int(4) DEFAULT '0' COMMENT '0=using,1=suspend,2=stop',
  `suspendservice_id` int(4) DEFAULT NULL COMMENT 'store suspend id ????????? update ???????????',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_paymentdetail`  VALUES ( "1","1","1","4","4","320.00","1","10","3.2","291.20","291.20","0.00","2017-03-03","2018-03-03","","frome registration","28","1","??????","0","0","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "2","1","4","58","0","12.00","1","0","","12.00","12.00","0.00","","","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "3","2","1","4","3","165.00","1","0","1.65","166.65","166.65","0.00","2017-03-03","2017-09-03","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "4","3","1","4","3","175.00","1","0","1.75","176.75","176.75","0.00","2017-03-03","2017-09-03","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "5","4","1","4","3","165.00","1","20","1.65","133.65","133.65","0.00","2017-03-07","2017-09-07","","frome registration","27","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "6","4","3","12","1","42.00","1","0","","42.00","42.00","0.00","2017-03-07","2017-04-07","","","","1","??????","","0","0","2","1");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "7","4","3","18","1","26.00","1","0","","26.00","26.00","0.00","2017-03-07","2017-04-07","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "8","5","1","4","3","250.00","1","0","2.5","252.50","252.50","0.00","2017-03-10","2017-09-10","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "9","6","1","4","1","35.00","1","0","0.35","35.35","35.35","0.00","2017-03-10","2017-04-10","","frome registration","28","1","??????","0","1","1","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "10","6","3","12","1","42.00","1","0","","42.00","42.00","0.00","2017-03-10","2017-04-10","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "11","6","4","109","0","10.00","1","0","","10.00","10.00","0.00","","","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "12","7","1","4","3","165.00","1","0","1.65","166.65","166.65","0.00","2017-03-10","2017-09-10","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "13","7","3","18","1","26.00","2","0","","52.00","52.00","0.00","2017-03-10","2017-05-10","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "14","8","1","4","1","45.00","1","0","0.45","45.45","45.45","0.00","2017-03-31","2017-05-01","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "15","8","3","12","1","42.00","1","0","","42.00","42.00","0.00","2017-03-31","2017-05-01","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "16","9","1","4","1","35.00","1","0","0.35","35.35","30.35","5.00","2017-04-05","2017-05-05","","frome registration","28","1","??????","0","0","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "17","9","3","14","1","32.00","1","0","","32.00","32.00","0.00","2017-04-05","2017-05-05","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "18","10","1","4","1","5.00","1","0","0","5.00","5.00","0.00","2017-04-05","2017-05-05","??????????????","frome registration","28","1","??????","0","1","16","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "19","11","1","4","1","35.00","1","0","0.35","35.35","35.35","0.00","2017-05-17","2017-06-17","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "20","11","3","16","1","8.00","1","0","","8.00","8.00","0.00","2017-05-17","2017-06-17","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "21","12","2","4","3","170.00","1","0","1.7","171.70","171.70","0.00","2017-05-17","2017-11-17","Dan Theo","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "22","13","1","4","1","45.00","1","0","0.45","45.45","45.45","0.00","2017-05-18","2017-06-18","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "23","13","3","18","1","26.00","1","0","","26.00","26.00","0.00","2017-05-18","2017-06-18","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "24","14","1","4","3","165.00","1","0","1.65","166.65","166.65","0.00","2017-05-24","2017-11-24","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "25","14","3","14","1","32.00","1","0","","32.00","32.00","0.00","2017-05-24","2017-06-24","","","","1","??????","","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "26","15","1","4","1","40.00","1","0","0.4","40.40","40.40","0.00","2017-05-24","2017-06-24","","frome registration","28","1","??????","0","1","0","0","");
INSERT INTO `rms_student_paymentdetail`  VALUES ( "27","15","3","18","1","26.00","1","0","","26.00","26.00","0.00","2017-05-24","2017-06-24","","","","1","??????","","1","0","0","");


--
-- Tabel structure for table `rms_student_test`
--
DROP TABLE  IF EXISTS `rms_student_test`;
CREATE TABLE `rms_student_test` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(4) DEFAULT NULL,
  `kh_name` varchar(200) DEFAULT NULL,
  `en_name` varchar(150) DEFAULT NULL,
  `sex` int(2) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `old_school` varchar(100) DEFAULT NULL COMMENT '?????????????????',
  `old_grade` varchar(100) DEFAULT NULL COMMENT '?????????????????????????',
  `register` tinyint(2) DEFAULT '0' COMMENT '0=not yet register , 1=registerd',
  `create_date` date DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `rms_student_test`  VALUES ( "1","1","??? ????a","Sok Thida","2","2004-04-13","015 236 147a","newtona","12 k1","1","2017-05-23","1");


--
-- Tabel structure for table `rms_student_transfer`
--
DROP TABLE  IF EXISTS `rms_student_transfer`;
CREATE TABLE `rms_student_transfer` (
  `id` int(11) DEFAULT NULL,
  `from_group` int(11) DEFAULT NULL,
  `to_group` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `note` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_studentscore`
--
DROP TABLE  IF EXISTS `rms_studentscore`;
CREATE TABLE `rms_studentscore` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) DEFAULT NULL,
  `sub_id` int(11) DEFAULT NULL,
  `score` float(10,2) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL COMMENT 'y,batch,session,room',
  `user_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_study_history`
--
DROP TABLE  IF EXISTS `rms_study_history`;
CREATE TABLE `rms_study_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `stu_id` int(10) DEFAULT NULL,
  `stu_type` tinyint(3) DEFAULT '1',
  `stu_code` varchar(40) CHARACTER SET latin1 DEFAULT NULL,
  `academic_year` tinyint(4) DEFAULT NULL,
  `degree` int(4) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `lang_level` int(11) DEFAULT NULL,
  `session` tinyint(4) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `parent_phone` varchar(50) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL COMMENT 'place of birth',
  `vill_id` int(10) DEFAULT NULL COMMENT 'place of birth',
  `comm_id` int(6) DEFAULT NULL COMMENT 'place of birth',
  `dis_id` int(6) DEFAULT NULL COMMENT 'place of birth',
  `pro_id` int(3) DEFAULT NULL COMMENT 'place of birth',
  `status` tinyint(4) DEFAULT NULL,
  `remark` text CHARACTER SET latin1,
  `user_id` int(11) DEFAULT NULL,
  `level` tinyint(4) DEFAULT NULL,
  `from_time` tinyint(4) DEFAULT NULL,
  `to_time` tinyint(4) DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `type_time` tinyint(4) DEFAULT NULL COMMENT '1=Full Time, 2 = Part Time',
  `is_finished` tinyint(4) DEFAULT '0' COMMENT '1=finised class, 0= not finished class',
  `finished_date` date DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `room` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `is_parent` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `rms_study_history`  VALUES ( "1","1","1","1","","1","1","2","","1","0","Sok Chanreaksmey","","7116","827","94","11","","","28","","","","2017-03-03","","1","2017-03-10","","","1","0");
INSERT INTO `rms_study_history`  VALUES ( "2","1","2","1","","","2","9","","1","","","","","","","","1","San Dara","28","","","","","","1","2017-03-10","","8","","");
INSERT INTO `rms_study_history`  VALUES ( "3","1","3","1","","1","1","3","","1","0","Chea Socheata","Chea Socheata","0","0","0","-1","","","28","","","","2017-03-03","","0","","","2","2","0");
INSERT INTO `rms_study_history`  VALUES ( "4","1","4","1","","1","1","7","","1","0","Hann Nita","Hann Nita","0","0","0","-1","","","28","","","","2017-03-03","","0","","","6","3","0");
INSERT INTO `rms_study_history`  VALUES ( "5","1","5","1","","","1","2","","1","","","","","","","","1","","28","","","","","","0","","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "6","1","6","1","","","1","2","","1","","","","","","","","1","","28","","","","","","0","","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "7","1","7","1","","","1","2","","1","","","","","","","","1","","28","","","","","","1","2017-03-10","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "8","1","8","1","","","1","2","","1","","","","","","","","1","","28","","","","","","0","","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "9","1","9","1","","","1","2","","1","","","","","","","","1","","28","","","","","","0","","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "10","1","10","1","","","1","2","","1","","","","","","","","1","","28","","","","","","0","","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "11","1","11","1","","","1","2","","1","","","","","","","","1","","28","","","","","","0","","","1","","");
INSERT INTO `rms_study_history`  VALUES ( "12","1","12","1","","1","1","2","","1","17","","","10295","1205","145","17","","","27","","","","2017-03-07","","0","","","","4","0");
INSERT INTO `rms_study_history`  VALUES ( "13","1","2","2","","1","2","10","","1","0","San Dara","San Dara","7116","827","-1","-1","","","28","","","","2017-03-10","","0","","","1","5","2");
INSERT INTO `rms_study_history`  VALUES ( "14","1","1","1","","1","1","2","","1","0","Sok Chanreaksmey","","7116","827","94","11","","","28","","","","2017-03-10","","0","","","","6","1");
INSERT INTO `rms_study_history`  VALUES ( "15","1","7","1","","1","1","2","","1","0","Sanchez","Sanchez","0","0","0","-1","","","28","","","","2017-03-10","","0","","","","7","7");
INSERT INTO `rms_study_history`  VALUES ( "16","1","13","2","","1","2","9","","1","0","","","0","0","0","-1","","","28","","","","2017-03-31","","0","","","","8","0");
INSERT INTO `rms_study_history`  VALUES ( "17","1","14","1","","1","1","2","","2","0","","","0","0","0","-1","","","28","","","","2017-04-05","","1","2017-04-05","","","9","0");
INSERT INTO `rms_study_history`  VALUES ( "18","1","14","1","","1","1","2","","2","0","","","0","0","0","-1","","??????????????","28","","","","2017-04-05","","0","","","1","10","17");
INSERT INTO `rms_study_history`  VALUES ( "19","1","15","1","","1","1","3","","2","","","","","","","","","","28","","","","2017-05-17","","0","","","","11","0");
INSERT INTO `rms_study_history`  VALUES ( "20","1","16","3","","1","3","14","","1","","Dan Theo","","","","","","","Dan Theo","28","","","","2017-05-17","","0","","","7","12","0");
INSERT INTO `rms_study_history`  VALUES ( "21","1","17","2","","1","2","8","","1","","","","","","","","","","28","","","","2017-05-18","","0","","","","13","0");
INSERT INTO `rms_study_history`  VALUES ( "22","1","18","1","","1","1","3","","1","","015 236 147a","","","","","","","","28","","","","2017-05-24","","0","","","","14","0");
INSERT INTO `rms_study_history`  VALUES ( "23","1","19","1","","1","1","7","","1","","015 236 147a","","","","","","","","28","","","","2017-05-24","","0","","","","15","");


--
-- Tabel structure for table `rms_subject`
--
DROP TABLE  IF EXISTS `rms_subject`;
CREATE TABLE `rms_subject` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '1=khmer(2=listening,3=speaking )',
  `parent` varchar(50) DEFAULT NULL,
  `subject_titleen` varchar(100) DEFAULT NULL,
  `subject_titlekh` varchar(100) DEFAULT NULL,
  `score_percent` int(10) DEFAULT NULL,
  `access_type` varchar(50) DEFAULT NULL,
  `is_parent` varchar(20) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO `rms_subject`  VALUES ( "1","0","Khmer","?????????(Khmer)","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "2","1","Listening","?????????","10","3","","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "3","1","Speaking","???????","10","3","","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "4","1","Reading","??????","10","3","","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "5","1","Dictation","???????????","10","3","","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "6","1","Composition","??????????","10","3","","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "7","1","Calligraphy","??????????","10","3","","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "8","0","Mathematics","??????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "9","0","Sciences","????????????????????","100","3","1","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "10","0","Social Studies","???????????","100","3","1","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "11","10","Moral Civics","??????-????????????","10","4","0","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "12","0","Geography","??????????","10","4","0","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "13","10","History","??????????????","10","4","0","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "14","0","English","????????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "15","0","Computer","??????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "16","0","PE Health","????????-??????","100","1","1","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "17","0","Music","????????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "18","0","Dance","??????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "19","0","Art & Craft","????? ??? ????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "20","0","Home Economic","????????-???????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "21","0","Sport","????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "22","0","Absence with Permission","?????????????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "23","0","Absence without Permission","????????????????? ","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "24","0","Total Absences(s)","????????????","10","1","1","1","1","2016-05-17");
INSERT INTO `rms_subject`  VALUES ( "25","0","Total Score","??????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "26","0","Physics","?????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "27","0","Chemistry","??????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "28","0","Biology","?????????","100","4","1","1","1","2016-05-30");
INSERT INTO `rms_subject`  VALUES ( "29","0","Earth Sciences","???????????","100","4","1","1","1","2016-06-07");
INSERT INTO `rms_subject`  VALUES ( "30","0","Listening","Listening","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "31","0","Speaking","Speaking","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "32","0","Reading","Reading","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "33","0","Writing","Writing","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "34","0","Writing","Writing","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "35","0","Homework","Homework","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "36","0","Quiz","Quiz","100","1","1","28","1","2017-05-17");
INSERT INTO `rms_subject`  VALUES ( "37","0","Quiz","Quiz","100","1","1","28","1","2017-05-17");


--
-- Tabel structure for table `rms_subject_exam`
--
DROP TABLE  IF EXISTS `rms_subject_exam`;
CREATE TABLE `rms_subject_exam` (
  `subexam_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subj_exam_name` varchar(200) NOT NULL,
  `modify_date` varchar(50) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`subexam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_supplier`
--
DROP TABLE  IF EXISTS `rms_supplier`;
CREATE TABLE `rms_supplier` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sup_name` varchar(100) DEFAULT NULL,
  `purchase_no` varchar(60) DEFAULT NULL,
  `sup_old_new` int(11) DEFAULT NULL COMMENT '1=suplier old , 0=suplier new ',
  `sex` tinyint(4) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `amount_due` float(15,2) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `rms_supplier`  VALUES ( "1","Ke Kimseurnss ","PU-0005","","1","098323332","seurn@gmail.com","phnom penh","100.00","2016-09-23","1","1");
INSERT INTO `rms_supplier`  VALUES ( "2","Sy Heng","PU-0004","","1","09828282","syheng@gmail.com","phnom penh","1337.00","2016-09-23","8","1");
INSERT INTO `rms_supplier`  VALUES ( "3","asdf","PU-0006","","1","3333","","","169.00","2016-10-05","1","1");
INSERT INTO `rms_supplier`  VALUES ( "4","From Main Branch","PU-0003","","1","7890","","","600.00","2017-02-04","28","1");
INSERT INTO `rms_supplier`  VALUES ( "5","sdfgh","PU-0008","","1","","","","0.00","2016-10-06","1","1");
INSERT INTO `rms_supplier`  VALUES ( "6","from main branch ","PU-0002","","1","","","","900.00","2017-02-01","28","1");


--
-- Tabel structure for table `rms_supplier_product`
--
DROP TABLE  IF EXISTS `rms_supplier_product`;
CREATE TABLE `rms_supplier_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sup_id` int(11) DEFAULT NULL,
  `supplier_no` varchar(100) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `amount_due` float(15,2) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_supplier_product`  VALUES ( "1","4","PU-0001","3","300.00","","2016-11-25","1","1");
INSERT INTO `rms_supplier_product`  VALUES ( "2","6","PU-0002","3","900.00","","2017-02-01","28","1");
INSERT INTO `rms_supplier_product`  VALUES ( "3","4","PU-0003","1","600.00","","2017-02-04","28","1");


--
-- Tabel structure for table `rms_supproduct_detail`
--
DROP TABLE  IF EXISTS `rms_supproduct_detail`;
CREATE TABLE `rms_supproduct_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `supproduct_id` int(11) DEFAULT NULL,
  `pro_id` int(11) DEFAULT NULL,
  `qty` float(15,2) DEFAULT NULL,
  `cost` float(15,2) DEFAULT NULL,
  `amount` float(15,2) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `rms_supproduct_detail`  VALUES ( "1","1","107","20.00","15.00","300.00","","2016-11-25","","1");
INSERT INTO `rms_supproduct_detail`  VALUES ( "2","2","106","20.00","10.00","200.00","","2017-02-01","","1");
INSERT INTO `rms_supproduct_detail`  VALUES ( "3","2","96","35.00","20.00","700.00","","2017-02-01","","1");
INSERT INTO `rms_supproduct_detail`  VALUES ( "4","3","108","50.00","12.00","600.00","","2017-02-04","","1");


--
-- Tabel structure for table `rms_suspendservice`
--
DROP TABLE  IF EXISTS `rms_suspendservice`;
CREATE TABLE `rms_suspendservice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `suspend_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `year` tinyint(4) DEFAULT NULL,
  `define_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_suspendservice`  VALUES ( "1","12","000001","1","2017-03-07","27");


--
-- Tabel structure for table `rms_suspendservicedetail`
--
DROP TABLE  IF EXISTS `rms_suspendservicedetail`;
CREATE TABLE `rms_suspendservicedetail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `suspendservice_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `date_back` date DEFAULT NULL COMMENT '???????????????????????????',
  `type_suspend` tinyint(4) DEFAULT NULL COMMENT '1= suspend, 2= stop',
  `reason` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `note` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `rms_suspendservicedetail`  VALUES ( "13","1","12","2017-06-15","2","abcczzzzc","adcadvszzzz","2017-03-07","27","1");


--
-- Tabel structure for table `rms_teacher`
--
DROP TABLE  IF EXISTS `rms_teacher`;
CREATE TABLE `rms_teacher` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_code` varchar(10) DEFAULT NULL,
  `teacher_name_en` varchar(150) DEFAULT NULL,
  `teacher_name_kh` varchar(200) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `nationality` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `position` int(4) DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `note` varchar(150) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `photo` varchar(100) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `create_date` date DEFAULT NULL COMMENT 'create date',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

INSERT INTO `rms_teacher`  VALUES ( "1","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "2","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "3","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "5","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "6","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "7","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "8","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "9","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "10","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "11","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "12","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "13","00003/CAS","Test3","Test3","1","2010-02-17","Test3","Test3","Test3","1","3","2017-08-30","Test3","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "14","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "15","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "16","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "17","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "18","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "19","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "20","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "21","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "22","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "23","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "24","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "25","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "26","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "27","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "28","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "29","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "30","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "31","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "32","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "33","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "34","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "35","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "36","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "37","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "38","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "39","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");
INSERT INTO `rms_teacher`  VALUES ( "40","00002/CAS","Test2","Test2","2","2017-02-02","Test2","Test2","Test2","1","1","2017-09-30","Test2","1","","28","0000-00-00");


--
-- Tabel structure for table `rms_teacher_subject`
--
DROP TABLE  IF EXISTS `rms_teacher_subject`;
CREATE TABLE `rms_teacher_subject` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `session` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_tuitionfee`
--
DROP TABLE  IF EXISTS `rms_tuitionfee`;
CREATE TABLE `rms_tuitionfee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_academic` varchar(10) DEFAULT NULL,
  `to_academic` varchar(10) DEFAULT NULL,
  `generation` varchar(30) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `branch_id` int(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '1=active ,0=deactive',
  `note` text,
  `create_date` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `rms_tuitionfee`  VALUES ( "1","2017","2018","1","2","2017-01-01","2017-09-30","1","1","","2016-12-15","27");
INSERT INTO `rms_tuitionfee`  VALUES ( "5","2018","2019","1","2","2017-01-01","2017-09-30","1","1","","2017-03-10","28");


--
-- Tabel structure for table `rms_tuitionfee_detail`
--
DROP TABLE  IF EXISTS `rms_tuitionfee_detail`;
CREATE TABLE `rms_tuitionfee_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fee_id` int(11) DEFAULT NULL,
  `class_id` int(4) DEFAULT NULL,
  `payment_term` tinyint(4) DEFAULT NULL,
  `tuition_fee` float DEFAULT '0',
  `remark` text CHARACTER SET ucs2,
  `status` tinyint(4) DEFAULT '1',
  `session` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2369 DEFAULT CHARSET=utf8;

INSERT INTO `rms_tuitionfee_detail`  VALUES ( "225","2","56","1","1","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "226","2","56","2","1","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "227","2","56","3","1","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "228","2","56","4","1","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "229","3","1","1","15","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "230","3","1","2","24","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "231","3","1","3","56","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "232","3","1","4","560","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "233","3","2","1","25","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "234","3","2","2","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "235","3","2","3","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "236","3","2","4","55","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "237","3","3","1","25","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "238","3","3","2","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "239","3","3","3","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "240","3","3","4","55","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "241","3","4","1","25","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "242","3","4","2","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "243","3","4","3","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "244","3","4","4","55","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "245","4","1","1","15","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "246","4","1","2","24","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "247","4","1","3","56","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "248","4","1","4","560","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "249","4","2","1","25","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "250","4","2","2","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "251","4","2","3","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "252","4","2","4","55","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "253","4","3","1","25","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "254","4","3","2","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "255","4","3","3","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "256","4","3","4","55","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "257","4","4","1","25","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "258","4","4","2","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "259","4","4","3","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "260","4","4","4","55","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1109","1","1","1","30","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1110","1","1","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1111","1","1","3","155","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1112","1","1","4","300","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1113","1","2","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1114","1","2","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1115","1","2","3","165","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1116","1","2","4","320","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1117","1","3","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1118","1","3","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1119","1","3","3","165","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1120","1","3","4","320","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1121","1","4","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1122","1","4","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1123","1","4","3","165","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1124","1","4","4","320","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1125","1","5","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1126","1","5","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1127","1","5","3","175","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1128","1","5","4","340","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1129","1","6","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1130","1","6","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1131","1","6","3","175","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1132","1","6","4","340","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1133","1","7","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1134","1","7","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1135","1","7","3","175","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1136","1","7","4","340","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1137","1","8","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1138","1","8","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1139","1","8","3","250","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1140","1","8","4","490","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1141","1","9","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1142","1","9","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1143","1","9","3","250","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1144","1","9","4","490","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1145","1","10","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1146","1","10","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1147","1","10","3","250","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1148","1","10","4","490","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1149","1","11","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1150","1","11","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1151","1","11","3","275","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1152","1","11","4","545","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1153","1","12","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1154","1","12","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1155","1","12","3","275","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1156","1","12","4","545","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1157","1","13","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1158","1","13","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1159","1","13","3","275","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1160","1","13","4","545","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1161","1","14","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1162","1","14","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1163","1","14","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1164","1","14","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1165","1","15","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1166","1","15","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1167","1","15","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1168","1","15","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1169","1","16","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1170","1","16","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1171","1","16","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1172","1","16","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1173","1","17","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1174","1","17","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1175","1","17","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1176","1","17","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1177","1","18","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1178","1","18","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1179","1","18","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1180","1","18","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1181","1","19","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1182","1","19","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1183","1","19","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1184","1","19","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1185","1","20","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1186","1","20","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1187","1","20","3","180","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1188","1","20","4","350","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1189","1","21","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1190","1","21","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1191","1","21","3","180","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1192","1","21","4","350","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1193","1","22","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1194","1","22","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1195","1","22","3","190","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1196","1","22","4","360","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1197","1","37","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1198","1","37","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1199","1","37","3","190","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1200","1","37","4","360","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1201","1","24","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1202","1","24","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1203","1","24","3","190","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1204","1","24","4","360","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1205","1","25","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1206","1","25","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1207","1","25","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1208","1","25","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1209","1","26","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1210","1","26","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1211","1","26","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1212","1","26","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1213","1","27","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1214","1","27","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1215","1","27","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1216","1","27","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1217","1","42","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1218","1","42","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1219","1","42","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1220","1","42","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1221","1","29","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1222","1","29","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1223","1","29","3","226","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1224","1","29","4","420","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1225","1","30","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1226","1","30","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1227","1","30","3","226","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1228","1","30","4","420","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1229","1","31","1","33","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1230","1","31","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1231","1","31","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1232","1","31","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1233","1","32","1","33","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1234","1","32","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1235","1","32","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1236","1","32","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1237","1","33","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1238","1","33","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1239","1","33","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1240","1","33","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1241","1","34","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1242","1","34","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1243","1","34","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1244","1","34","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1245","1","35","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1246","1","35","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1247","1","35","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1248","1","35","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1249","1","36","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1250","1","36","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1251","1","36","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1252","1","36","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1253","1","37","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1254","1","37","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1255","1","37","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1256","1","37","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1257","1","38","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1258","1","38","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1259","1","38","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1260","1","38","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1261","1","39","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1262","1","39","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1263","1","39","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1264","1","39","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1265","1","40","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1266","1","40","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1267","1","40","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1268","1","40","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1269","1","41","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1270","1","41","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1271","1","41","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1272","1","41","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1273","1","42","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1274","1","42","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1275","1","42","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1276","1","42","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1277","1","43","1","60","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1278","1","43","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1279","1","43","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1280","1","43","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1281","1","44","1","60","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1282","1","44","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1283","1","44","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1284","1","44","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1285","1","48","1","90","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1286","1","48","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1287","1","48","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1288","1","48","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1289","1","49","1","90","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1290","1","49","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1291","1","49","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1292","1","49","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1293","1","50","1","90","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1294","1","50","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1295","1","50","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1296","1","50","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1297","1","51","1","120","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1298","1","51","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1299","1","51","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1300","1","51","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1301","1","52","1","120","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1302","1","52","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1303","1","52","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1304","1","52","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1305","1","53","1","120","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1306","1","53","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1307","1","53","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1308","1","53","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1309","1","54","1","150","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1310","1","54","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1311","1","54","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1312","1","54","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1313","1","55","1","150","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1314","1","55","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1315","1","55","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1316","1","55","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1317","1","56","1","150","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1318","1","56","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1319","1","56","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "1320","1","56","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2161","5","1","1","30","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2162","5","1","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2163","5","1","3","155","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2164","5","1","4","300","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2165","5","2","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2166","5","2","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2167","5","2","3","165","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2168","5","2","4","320","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2169","5","3","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2170","5","3","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2171","5","3","3","165","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2172","5","3","4","320","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2173","5","4","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2174","5","4","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2175","5","4","3","165","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2176","5","4","4","320","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2177","5","5","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2178","5","5","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2179","5","5","3","175","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2180","5","5","4","340","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2181","5","6","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2182","5","6","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2183","5","6","3","175","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2184","5","6","4","340","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2185","5","7","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2186","5","7","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2187","5","7","3","175","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2188","5","7","4","340","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2189","5","8","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2190","5","8","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2191","5","8","3","250","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2192","5","8","4","490","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2193","5","9","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2194","5","9","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2195","5","9","3","250","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2196","5","9","4","490","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2197","5","10","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2198","5","10","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2199","5","10","3","250","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2200","5","10","4","490","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2201","5","11","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2202","5","11","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2203","5","11","3","275","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2204","5","11","4","545","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2205","5","12","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2206","5","12","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2207","5","12","3","275","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2208","5","12","4","545","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2209","5","13","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2210","5","13","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2211","5","13","3","275","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2212","5","13","4","545","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2213","5","14","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2214","5","14","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2215","5","14","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2216","5","14","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2217","5","15","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2218","5","15","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2219","5","15","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2220","5","15","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2221","5","16","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2222","5","16","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2223","5","16","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2224","5","16","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2225","5","17","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2226","5","17","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2227","5","17","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2228","5","17","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2229","5","19","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2230","5","19","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2231","5","19","3","170","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2232","5","19","4","330","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2233","5","20","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2234","5","20","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2235","5","20","3","180","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2236","5","20","4","350","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2237","5","21","1","35","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2238","5","21","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2239","5","21","3","180","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2240","5","21","4","350","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2241","5","22","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2242","5","22","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2243","5","22","3","190","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2244","5","22","4","360","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2245","5","37","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2246","5","37","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2247","5","37","3","190","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2248","5","37","4","360","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2249","5","24","1","40","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2250","5","24","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2251","5","24","3","190","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2252","5","24","4","360","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2253","5","25","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2254","5","25","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2255","5","25","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2256","5","25","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2257","5","26","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2258","5","26","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2259","5","26","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2260","5","26","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2261","5","27","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2262","5","27","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2263","5","27","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2264","5","27","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2265","5","42","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2266","5","42","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2267","5","42","3","210","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2268","5","42","4","399","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2269","5","29","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2270","5","29","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2271","5","29","3","226","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2272","5","29","4","420","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2273","5","30","1","50","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2274","5","30","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2275","5","30","3","226","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2276","5","30","4","420","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2277","5","31","1","33","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2278","5","31","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2279","5","31","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2280","5","31","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2281","5","32","1","33","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2282","5","32","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2283","5","32","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2284","5","32","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2285","5","33","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2286","5","33","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2287","5","33","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2288","5","33","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2289","5","34","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2290","5","34","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2291","5","34","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2292","5","34","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2293","5","35","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2294","5","35","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2295","5","35","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2296","5","35","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2297","5","36","1","39","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2298","5","36","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2299","5","36","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2300","5","36","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2301","5","37","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2302","5","37","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2303","5","37","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2304","5","37","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2305","5","38","1","45","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2306","5","38","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2307","5","38","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2308","5","38","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2309","5","39","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2310","5","39","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2311","5","39","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2312","5","39","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2313","5","40","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2314","5","40","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2315","5","40","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2316","5","40","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2317","5","41","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2318","5","41","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2319","5","41","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2320","5","41","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2321","5","42","1","54","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2322","5","42","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2323","5","42","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2324","5","42","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2325","5","43","1","60","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2326","5","43","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2327","5","43","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2328","5","43","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2329","5","44","1","60","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2330","5","44","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2331","5","44","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2332","5","44","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2333","5","48","1","90","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2334","5","48","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2335","5","48","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2336","5","48","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2337","5","49","1","90","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2338","5","49","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2339","5","49","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2340","5","49","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2341","5","50","1","90","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2342","5","50","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2343","5","50","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2344","5","50","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2345","5","51","1","120","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2346","5","51","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2347","5","51","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2348","5","51","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2349","5","52","1","120","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2350","5","52","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2351","5","52","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2352","5","52","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2353","5","53","1","120","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2354","5","53","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2355","5","53","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2356","5","53","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2357","5","54","1","150","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2358","5","54","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2359","5","54","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2360","5","54","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2361","5","55","1","150","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2362","5","55","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2363","5","55","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2364","5","55","4","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2365","5","56","1","150","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2366","5","56","2","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2367","5","56","3","0","","1","");
INSERT INTO `rms_tuitionfee_detail`  VALUES ( "2368","5","56","4","0","","1","");


--
-- Tabel structure for table `rms_user_log`
--
DROP TABLE  IF EXISTS `rms_user_log`;
CREATE TABLE `rms_user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `log_date` datetime NOT NULL,
  `log_type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=479 DEFAULT CHARSET=utf8;

INSERT INTO `rms_user_log`  VALUES ( "1","1","2016-09-20 09:50:01","in");
INSERT INTO `rms_user_log`  VALUES ( "2","1","2016-09-20 11:44:47","out");
INSERT INTO `rms_user_log`  VALUES ( "3","1","2016-09-20 11:45:31","in");
INSERT INTO `rms_user_log`  VALUES ( "4","1","2016-09-20 12:32:47","in");
INSERT INTO `rms_user_log`  VALUES ( "5","1","2016-09-20 12:36:09","in");
INSERT INTO `rms_user_log`  VALUES ( "6","1","2016-09-20 13:59:09","out");
INSERT INTO `rms_user_log`  VALUES ( "7","1","2016-09-20 13:59:18","in");
INSERT INTO `rms_user_log`  VALUES ( "8","1","2016-09-20 14:00:13","out");
INSERT INTO `rms_user_log`  VALUES ( "9","1","2016-09-20 14:00:20","in");
INSERT INTO `rms_user_log`  VALUES ( "10","1","2016-09-20 14:01:51","out");
INSERT INTO `rms_user_log`  VALUES ( "11","1","2016-09-20 14:01:59","in");
INSERT INTO `rms_user_log`  VALUES ( "12","1","2016-09-20 14:25:46","out");
INSERT INTO `rms_user_log`  VALUES ( "13","1","2016-09-20 14:32:05","in");
INSERT INTO `rms_user_log`  VALUES ( "14","1","2016-09-20 14:32:32","out");
INSERT INTO `rms_user_log`  VALUES ( "15","1","2016-09-20 14:32:43","in");
INSERT INTO `rms_user_log`  VALUES ( "16","1","2016-09-20 14:32:59","out");
INSERT INTO `rms_user_log`  VALUES ( "17","1","2016-09-20 14:33:09","in");
INSERT INTO `rms_user_log`  VALUES ( "18","1","2016-09-20 14:34:10","in");
INSERT INTO `rms_user_log`  VALUES ( "19","1","2016-09-20 14:34:52","in");
INSERT INTO `rms_user_log`  VALUES ( "20","1","2016-09-20 19:47:32","out");
INSERT INTO `rms_user_log`  VALUES ( "21","1","2016-09-20 20:02:48","in");
INSERT INTO `rms_user_log`  VALUES ( "22","1","2016-09-21 08:57:53","in");
INSERT INTO `rms_user_log`  VALUES ( "23","1","2016-09-21 16:06:25","out");
INSERT INTO `rms_user_log`  VALUES ( "24","1","2016-09-23 13:00:46","in");
INSERT INTO `rms_user_log`  VALUES ( "25","1","2016-09-23 13:46:28","in");
INSERT INTO `rms_user_log`  VALUES ( "26","1","2016-09-23 17:10:34","in");
INSERT INTO `rms_user_log`  VALUES ( "27","1","2016-09-26 08:19:16","in");
INSERT INTO `rms_user_log`  VALUES ( "28","1","2016-09-26 16:24:22","in");
INSERT INTO `rms_user_log`  VALUES ( "29","1","2016-09-28 20:18:05","in");
INSERT INTO `rms_user_log`  VALUES ( "30","1","2016-09-28 20:37:42","in");
INSERT INTO `rms_user_log`  VALUES ( "31","1","2016-09-28 21:39:33","out");
INSERT INTO `rms_user_log`  VALUES ( "32","1","2016-09-28 21:39:43","in");
INSERT INTO `rms_user_log`  VALUES ( "33","1","2016-09-28 21:45:08","out");
INSERT INTO `rms_user_log`  VALUES ( "34","1","2016-09-28 21:45:20","in");
INSERT INTO `rms_user_log`  VALUES ( "35","1","2016-09-30 19:32:28","in");
INSERT INTO `rms_user_log`  VALUES ( "36","1","2016-10-03 20:32:12","in");
INSERT INTO `rms_user_log`  VALUES ( "37","1","2016-10-03 20:35:00","in");
INSERT INTO `rms_user_log`  VALUES ( "38","1","2016-10-03 20:54:38","in");
INSERT INTO `rms_user_log`  VALUES ( "39","1","2016-10-04 08:34:33","in");
INSERT INTO `rms_user_log`  VALUES ( "40","1","2016-10-04 21:48:01","out");
INSERT INTO `rms_user_log`  VALUES ( "41","1","2016-10-04 21:48:41","in");
INSERT INTO `rms_user_log`  VALUES ( "42","1","2016-10-05 09:41:44","in");
INSERT INTO `rms_user_log`  VALUES ( "43","1","2016-10-05 09:58:24","out");
INSERT INTO `rms_user_log`  VALUES ( "44","1","2016-10-05 09:58:38","in");
INSERT INTO `rms_user_log`  VALUES ( "45","1","2016-10-05 09:58:45","in");
INSERT INTO `rms_user_log`  VALUES ( "46","1","2016-10-05 15:20:48","in");
INSERT INTO `rms_user_log`  VALUES ( "47","1","2016-10-05 15:48:20","in");
INSERT INTO `rms_user_log`  VALUES ( "48","1","2016-10-06 13:24:47","in");
INSERT INTO `rms_user_log`  VALUES ( "49","1","2016-10-06 13:32:23","out");
INSERT INTO `rms_user_log`  VALUES ( "50","1","2016-10-06 13:32:30","in");
INSERT INTO `rms_user_log`  VALUES ( "51","1","2016-10-06 14:30:57","out");
INSERT INTO `rms_user_log`  VALUES ( "52","1","2016-10-06 14:31:08","in");
INSERT INTO `rms_user_log`  VALUES ( "53","1","2016-10-06 14:32:28","out");
INSERT INTO `rms_user_log`  VALUES ( "54","1","2016-10-06 14:32:36","in");
INSERT INTO `rms_user_log`  VALUES ( "55","1","2016-10-06 14:36:20","out");
INSERT INTO `rms_user_log`  VALUES ( "56","1","2016-10-06 14:36:38","in");
INSERT INTO `rms_user_log`  VALUES ( "57","1","2016-10-06 14:37:33","out");
INSERT INTO `rms_user_log`  VALUES ( "58","9","2016-10-06 14:38:02","in");
INSERT INTO `rms_user_log`  VALUES ( "59","9","2016-10-06 14:38:02","in");
INSERT INTO `rms_user_log`  VALUES ( "60","9","2016-10-06 14:41:00","out");
INSERT INTO `rms_user_log`  VALUES ( "61","9","2016-10-06 14:41:20","in");
INSERT INTO `rms_user_log`  VALUES ( "62","9","2016-10-06 14:42:14","out");
INSERT INTO `rms_user_log`  VALUES ( "63","9","2016-10-06 14:42:48","in");
INSERT INTO `rms_user_log`  VALUES ( "64","9","2016-10-06 14:43:21","out");
INSERT INTO `rms_user_log`  VALUES ( "65","1","2016-10-06 14:43:29","in");
INSERT INTO `rms_user_log`  VALUES ( "66","1","2016-10-07 15:12:53","in");
INSERT INTO `rms_user_log`  VALUES ( "67","1","2016-10-07 15:53:42","out");
INSERT INTO `rms_user_log`  VALUES ( "68","10","2016-10-07 15:53:49","in");
INSERT INTO `rms_user_log`  VALUES ( "69","1","2016-10-10 09:17:38","in");
INSERT INTO `rms_user_log`  VALUES ( "70","1","2016-10-10 14:52:13","in");
INSERT INTO `rms_user_log`  VALUES ( "71","1","2016-10-11 08:10:31","in");
INSERT INTO `rms_user_log`  VALUES ( "72","1","2016-10-11 08:32:33","in");
INSERT INTO `rms_user_log`  VALUES ( "73","1","2016-10-11 08:34:26","in");
INSERT INTO `rms_user_log`  VALUES ( "74","1","2016-10-11 09:27:55","in");
INSERT INTO `rms_user_log`  VALUES ( "75","1","2016-10-11 15:37:35","in");
INSERT INTO `rms_user_log`  VALUES ( "76","1","2016-10-13 11:09:54","in");
INSERT INTO `rms_user_log`  VALUES ( "77","1","2016-10-13 11:27:16","in");
INSERT INTO `rms_user_log`  VALUES ( "78","1","2016-10-14 09:54:14","in");
INSERT INTO `rms_user_log`  VALUES ( "79","1","2016-10-14 10:01:51","in");
INSERT INTO `rms_user_log`  VALUES ( "80","1","2016-10-14 10:02:58","in");
INSERT INTO `rms_user_log`  VALUES ( "81","1","2016-10-14 10:14:01","out");
INSERT INTO `rms_user_log`  VALUES ( "82","1","2016-10-14 10:15:38","in");
INSERT INTO `rms_user_log`  VALUES ( "83","1","2016-10-17 09:12:20","in");
INSERT INTO `rms_user_log`  VALUES ( "84","1","2016-10-17 09:13:03","out");
INSERT INTO `rms_user_log`  VALUES ( "85","11","2016-10-17 09:13:10","in");
INSERT INTO `rms_user_log`  VALUES ( "86","11","2016-10-17 09:13:12","out");
INSERT INTO `rms_user_log`  VALUES ( "87","11","2016-10-17 09:14:05","in");
INSERT INTO `rms_user_log`  VALUES ( "88","11","2016-10-17 09:25:36","in");
INSERT INTO `rms_user_log`  VALUES ( "89","11","2016-10-17 11:28:33","out");
INSERT INTO `rms_user_log`  VALUES ( "90","1","2016-10-17 11:28:46","in");
INSERT INTO `rms_user_log`  VALUES ( "91","1","2016-10-17 11:33:47","out");
INSERT INTO `rms_user_log`  VALUES ( "92","12","2016-10-17 11:34:12","in");
INSERT INTO `rms_user_log`  VALUES ( "93","12","2016-10-17 11:34:34","out");
INSERT INTO `rms_user_log`  VALUES ( "94","1","2016-10-19 16:14:47","in");
INSERT INTO `rms_user_log`  VALUES ( "95","1","2016-10-19 16:19:01","in");
INSERT INTO `rms_user_log`  VALUES ( "96","1","2016-10-19 16:20:03","out");
INSERT INTO `rms_user_log`  VALUES ( "97","12","2016-10-21 18:15:27","in");
INSERT INTO `rms_user_log`  VALUES ( "98","12","2016-10-22 13:25:39","in");
INSERT INTO `rms_user_log`  VALUES ( "99","12","2016-10-22 13:25:56","out");
INSERT INTO `rms_user_log`  VALUES ( "100","12","2016-10-22 13:26:11","in");
INSERT INTO `rms_user_log`  VALUES ( "101","12","2016-10-22 14:10:11","out");
INSERT INTO `rms_user_log`  VALUES ( "102","12","2016-10-22 14:10:25","in");
INSERT INTO `rms_user_log`  VALUES ( "103","12","2016-10-22 14:14:15","out");
INSERT INTO `rms_user_log`  VALUES ( "104","14","2016-10-22 14:14:54","in");
INSERT INTO `rms_user_log`  VALUES ( "105","14","2016-10-22 14:20:34","out");
INSERT INTO `rms_user_log`  VALUES ( "106","15","2016-10-22 14:20:56","in");
INSERT INTO `rms_user_log`  VALUES ( "107","15","2016-10-22 14:29:43","out");
INSERT INTO `rms_user_log`  VALUES ( "108","13","2016-10-22 14:30:13","in");
INSERT INTO `rms_user_log`  VALUES ( "109","13","2016-10-22 14:32:35","out");
INSERT INTO `rms_user_log`  VALUES ( "110","15","2016-10-22 14:33:11","in");
INSERT INTO `rms_user_log`  VALUES ( "111","15","2016-10-22 14:36:13","out");
INSERT INTO `rms_user_log`  VALUES ( "112","15","2016-10-22 14:38:32","in");
INSERT INTO `rms_user_log`  VALUES ( "113","15","2016-10-22 14:45:58","out");
INSERT INTO `rms_user_log`  VALUES ( "114","1","2016-10-22 14:57:59","in");
INSERT INTO `rms_user_log`  VALUES ( "115","1","2016-10-22 14:58:28","out");
INSERT INTO `rms_user_log`  VALUES ( "116","11","2016-10-22 14:58:48","in");
INSERT INTO `rms_user_log`  VALUES ( "117","11","2016-10-22 15:00:27","out");
INSERT INTO `rms_user_log`  VALUES ( "118","15","2016-10-22 15:01:12","in");
INSERT INTO `rms_user_log`  VALUES ( "119","15","2016-10-22 15:04:07","out");
INSERT INTO `rms_user_log`  VALUES ( "120","12","2016-10-22 15:04:19","in");
INSERT INTO `rms_user_log`  VALUES ( "121","12","2016-10-22 15:10:11","out");
INSERT INTO `rms_user_log`  VALUES ( "122","12","2016-10-23 14:04:56","in");
INSERT INTO `rms_user_log`  VALUES ( "123","17","2016-10-23 14:09:55","in");
INSERT INTO `rms_user_log`  VALUES ( "124","12","2016-10-23 14:42:52","in");
INSERT INTO `rms_user_log`  VALUES ( "125","17","2016-10-23 14:50:02","in");
INSERT INTO `rms_user_log`  VALUES ( "126","17","2016-10-23 15:00:42","out");
INSERT INTO `rms_user_log`  VALUES ( "127","12","2016-10-23 15:03:20","in");
INSERT INTO `rms_user_log`  VALUES ( "128","12","2016-10-23 15:05:06","out");
INSERT INTO `rms_user_log`  VALUES ( "129","12","2016-10-23 15:06:33","in");
INSERT INTO `rms_user_log`  VALUES ( "130","12","2016-10-23 15:08:01","out");
INSERT INTO `rms_user_log`  VALUES ( "131","24","2016-10-23 15:08:18","in");
INSERT INTO `rms_user_log`  VALUES ( "132","24","2016-10-23 15:16:33","out");
INSERT INTO `rms_user_log`  VALUES ( "133","12","2016-10-23 15:16:46","in");
INSERT INTO `rms_user_log`  VALUES ( "134","12","2016-10-23 15:33:27","out");
INSERT INTO `rms_user_log`  VALUES ( "135","17","2016-10-23 15:33:41","in");
INSERT INTO `rms_user_log`  VALUES ( "136","17","2016-10-23 15:44:08","out");
INSERT INTO `rms_user_log`  VALUES ( "137","12","2016-10-23 15:44:25","in");
INSERT INTO `rms_user_log`  VALUES ( "138","12","2016-10-23 15:47:21","out");
INSERT INTO `rms_user_log`  VALUES ( "139","17","2016-10-23 15:47:37","in");
INSERT INTO `rms_user_log`  VALUES ( "140","17","2016-10-23 15:55:37","out");
INSERT INTO `rms_user_log`  VALUES ( "141","12","2016-10-23 15:55:56","in");
INSERT INTO `rms_user_log`  VALUES ( "142","13","2016-10-24 08:19:11","in");
INSERT INTO `rms_user_log`  VALUES ( "143","13","2016-10-24 08:19:24","out");
INSERT INTO `rms_user_log`  VALUES ( "144","16","2016-10-24 08:19:53","in");
INSERT INTO `rms_user_log`  VALUES ( "145","16","2016-10-24 08:20:00","out");
INSERT INTO `rms_user_log`  VALUES ( "146","16","2016-10-24 08:21:12","in");
INSERT INTO `rms_user_log`  VALUES ( "147","16","2016-10-24 08:21:18","out");
INSERT INTO `rms_user_log`  VALUES ( "148","22","2016-10-24 08:22:57","in");
INSERT INTO `rms_user_log`  VALUES ( "149","22","2016-10-24 08:23:11","out");
INSERT INTO `rms_user_log`  VALUES ( "150","15","2016-10-24 08:23:44","in");
INSERT INTO `rms_user_log`  VALUES ( "151","15","2016-10-24 08:23:49","out");
INSERT INTO `rms_user_log`  VALUES ( "152","13","2016-10-24 08:24:30","in");
INSERT INTO `rms_user_log`  VALUES ( "153","13","2016-10-24 08:24:33","out");
INSERT INTO `rms_user_log`  VALUES ( "154","12","2016-10-24 08:25:16","in");
INSERT INTO `rms_user_log`  VALUES ( "155","12","2016-10-24 08:27:00","out");
INSERT INTO `rms_user_log`  VALUES ( "156","15","2016-10-24 08:27:16","in");
INSERT INTO `rms_user_log`  VALUES ( "157","15","2016-10-24 09:09:55","in");
INSERT INTO `rms_user_log`  VALUES ( "158","1","2016-10-24 09:54:37","in");
INSERT INTO `rms_user_log`  VALUES ( "159","1","2016-10-24 11:04:27","out");
INSERT INTO `rms_user_log`  VALUES ( "160","1","2016-10-24 11:04:34","in");
INSERT INTO `rms_user_log`  VALUES ( "161","17","2016-10-25 08:53:00","in");
INSERT INTO `rms_user_log`  VALUES ( "162","17","2016-10-25 09:13:40","in");
INSERT INTO `rms_user_log`  VALUES ( "163","15","2016-10-26 07:41:39","in");
INSERT INTO `rms_user_log`  VALUES ( "164","12","2016-10-26 08:11:17","in");
INSERT INTO `rms_user_log`  VALUES ( "165","12","2016-10-26 13:25:58","in");
INSERT INTO `rms_user_log`  VALUES ( "166","12","2016-10-26 13:56:10","out");
INSERT INTO `rms_user_log`  VALUES ( "167","15","2016-10-26 13:56:42","in");
INSERT INTO `rms_user_log`  VALUES ( "168","15","2016-10-26 14:00:39","out");
INSERT INTO `rms_user_log`  VALUES ( "169","12","2016-10-26 14:01:04","in");
INSERT INTO `rms_user_log`  VALUES ( "170","12","2016-10-26 14:02:42","out");
INSERT INTO `rms_user_log`  VALUES ( "171","15","2016-10-26 14:03:00","in");
INSERT INTO `rms_user_log`  VALUES ( "172","15","2016-10-26 14:06:00","out");
INSERT INTO `rms_user_log`  VALUES ( "173","12","2016-10-26 14:06:21","in");
INSERT INTO `rms_user_log`  VALUES ( "174","12","2016-10-26 14:54:02","out");
INSERT INTO `rms_user_log`  VALUES ( "175","15","2016-10-26 14:54:18","in");
INSERT INTO `rms_user_log`  VALUES ( "176","15","2016-10-26 14:55:05","out");
INSERT INTO `rms_user_log`  VALUES ( "177","12","2016-10-26 14:55:21","in");
INSERT INTO `rms_user_log`  VALUES ( "178","12","2016-10-26 16:17:52","out");
INSERT INTO `rms_user_log`  VALUES ( "179","17","2016-10-26 16:18:22","in");
INSERT INTO `rms_user_log`  VALUES ( "180","1","2016-10-26 17:13:50","in");
INSERT INTO `rms_user_log`  VALUES ( "181","12","2016-10-26 17:51:00","in");
INSERT INTO `rms_user_log`  VALUES ( "182","12","2016-10-26 17:56:17","out");
INSERT INTO `rms_user_log`  VALUES ( "183","24","2016-10-26 17:57:39","in");
INSERT INTO `rms_user_log`  VALUES ( "184","24","2016-10-26 18:12:58","out");
INSERT INTO `rms_user_log`  VALUES ( "185","17","2016-10-27 13:59:59","in");
INSERT INTO `rms_user_log`  VALUES ( "186","12","2016-10-27 14:08:25","in");
INSERT INTO `rms_user_log`  VALUES ( "187","12","2016-10-27 14:12:40","out");
INSERT INTO `rms_user_log`  VALUES ( "188","17","2016-10-27 14:12:57","in");
INSERT INTO `rms_user_log`  VALUES ( "189","17","2016-10-27 14:14:16","out");
INSERT INTO `rms_user_log`  VALUES ( "190","12","2016-10-27 14:14:27","in");
INSERT INTO `rms_user_log`  VALUES ( "191","12","2016-10-27 14:22:54","in");
INSERT INTO `rms_user_log`  VALUES ( "192","17","2016-10-27 14:25:21","in");
INSERT INTO `rms_user_log`  VALUES ( "193","17","2016-10-27 14:25:51","in");
INSERT INTO `rms_user_log`  VALUES ( "194","17","2016-10-27 14:26:24","in");
INSERT INTO `rms_user_log`  VALUES ( "195","17","2016-10-27 16:18:36","in");
INSERT INTO `rms_user_log`  VALUES ( "196","12","2016-10-27 16:28:57","out");
INSERT INTO `rms_user_log`  VALUES ( "197","24","2016-10-27 17:49:34","in");
INSERT INTO `rms_user_log`  VALUES ( "198","24","2016-10-27 18:01:25","out");
INSERT INTO `rms_user_log`  VALUES ( "199","12","2016-10-28 07:30:46","in");
INSERT INTO `rms_user_log`  VALUES ( "200","12","2016-10-28 07:32:15","out");
INSERT INTO `rms_user_log`  VALUES ( "201","22","2016-10-28 07:32:34","in");
INSERT INTO `rms_user_log`  VALUES ( "202","12","2016-10-28 07:35:39","in");
INSERT INTO `rms_user_log`  VALUES ( "203","12","2016-10-28 10:17:37","out");
INSERT INTO `rms_user_log`  VALUES ( "204","15","2016-10-28 10:17:54","in");
INSERT INTO `rms_user_log`  VALUES ( "205","15","2016-10-28 10:18:52","out");
INSERT INTO `rms_user_log`  VALUES ( "206","12","2016-10-28 10:19:01","in");
INSERT INTO `rms_user_log`  VALUES ( "207","12","2016-10-28 13:02:10","in");
INSERT INTO `rms_user_log`  VALUES ( "208","12","2016-10-28 14:04:48","out");
INSERT INTO `rms_user_log`  VALUES ( "209","15","2016-10-28 14:06:45","in");
INSERT INTO `rms_user_log`  VALUES ( "210","22","2016-10-28 14:52:04","in");
INSERT INTO `rms_user_log`  VALUES ( "211","22","2016-10-28 15:12:39","out");
INSERT INTO `rms_user_log`  VALUES ( "212","15","2016-10-28 15:29:34","out");
INSERT INTO `rms_user_log`  VALUES ( "213","1","2016-10-28 16:46:38","in");
INSERT INTO `rms_user_log`  VALUES ( "214","1","2016-10-28 16:47:04","out");
INSERT INTO `rms_user_log`  VALUES ( "215","12","2016-10-28 17:18:15","in");
INSERT INTO `rms_user_log`  VALUES ( "216","17","2016-10-31 10:13:23","in");
INSERT INTO `rms_user_log`  VALUES ( "217","1","2016-10-31 10:14:25","in");
INSERT INTO `rms_user_log`  VALUES ( "218","1","2016-11-01 17:20:59","in");
INSERT INTO `rms_user_log`  VALUES ( "219","1","2016-11-01 17:51:45","in");
INSERT INTO `rms_user_log`  VALUES ( "220","1","2016-11-01 17:52:33","out");
INSERT INTO `rms_user_log`  VALUES ( "221","12","2016-11-07 09:24:45","in");
INSERT INTO `rms_user_log`  VALUES ( "222","12","2016-11-08 07:16:37","in");
INSERT INTO `rms_user_log`  VALUES ( "223","12","2016-11-09 13:43:15","in");
INSERT INTO `rms_user_log`  VALUES ( "224","15","2016-11-09 14:06:02","in");
INSERT INTO `rms_user_log`  VALUES ( "225","15","2016-11-09 14:55:26","out");
INSERT INTO `rms_user_log`  VALUES ( "226","12","2016-11-09 14:55:37","in");
INSERT INTO `rms_user_log`  VALUES ( "227","12","2016-11-09 15:02:54","out");
INSERT INTO `rms_user_log`  VALUES ( "228","15","2016-11-09 15:04:06","in");
INSERT INTO `rms_user_log`  VALUES ( "229","15","2016-11-09 15:52:26","out");
INSERT INTO `rms_user_log`  VALUES ( "230","12","2016-11-09 15:52:35","in");
INSERT INTO `rms_user_log`  VALUES ( "231","12","2016-11-10 11:41:35","in");
INSERT INTO `rms_user_log`  VALUES ( "232","12","2016-11-13 08:08:03","in");
INSERT INTO `rms_user_log`  VALUES ( "233","12","2016-11-13 09:35:21","out");
INSERT INTO `rms_user_log`  VALUES ( "234","12","2016-11-13 13:14:54","in");
INSERT INTO `rms_user_log`  VALUES ( "235","12","2016-11-13 13:30:53","out");
INSERT INTO `rms_user_log`  VALUES ( "236","15","2016-11-13 13:31:26","in");
INSERT INTO `rms_user_log`  VALUES ( "237","15","2016-11-13 13:33:42","out");
INSERT INTO `rms_user_log`  VALUES ( "238","22","2016-11-13 13:34:00","in");
INSERT INTO `rms_user_log`  VALUES ( "239","22","2016-11-13 13:35:45","out");
INSERT INTO `rms_user_log`  VALUES ( "240","16","2016-11-13 13:37:13","in");
INSERT INTO `rms_user_log`  VALUES ( "241","16","2016-11-13 13:38:46","out");
INSERT INTO `rms_user_log`  VALUES ( "242","13","2016-11-13 13:39:22","in");
INSERT INTO `rms_user_log`  VALUES ( "243","13","2016-11-13 13:41:28","out");
INSERT INTO `rms_user_log`  VALUES ( "244","12","2016-11-13 13:41:41","in");
INSERT INTO `rms_user_log`  VALUES ( "245","12","2016-11-13 13:47:25","out");
INSERT INTO `rms_user_log`  VALUES ( "246","15","2016-11-13 13:47:38","in");
INSERT INTO `rms_user_log`  VALUES ( "247","15","2016-11-13 13:48:26","out");
INSERT INTO `rms_user_log`  VALUES ( "248","12","2016-11-13 13:48:36","in");
INSERT INTO `rms_user_log`  VALUES ( "249","12","2016-11-13 13:54:33","out");
INSERT INTO `rms_user_log`  VALUES ( "250","15","2016-11-13 13:55:00","in");
INSERT INTO `rms_user_log`  VALUES ( "251","15","2016-11-13 14:09:13","out");
INSERT INTO `rms_user_log`  VALUES ( "252","22","2016-11-13 14:09:37","in");
INSERT INTO `rms_user_log`  VALUES ( "253","22","2016-11-13 14:24:36","out");
INSERT INTO `rms_user_log`  VALUES ( "254","15","2016-11-13 14:25:10","in");
INSERT INTO `rms_user_log`  VALUES ( "255","15","2016-11-13 14:40:48","out");
INSERT INTO `rms_user_log`  VALUES ( "256","22","2016-11-13 14:42:03","in");
INSERT INTO `rms_user_log`  VALUES ( "257","22","2016-11-13 15:03:07","out");
INSERT INTO `rms_user_log`  VALUES ( "258","15","2016-11-13 15:03:24","in");
INSERT INTO `rms_user_log`  VALUES ( "259","15","2016-11-13 15:07:45","out");
INSERT INTO `rms_user_log`  VALUES ( "260","12","2016-11-13 15:22:37","in");
INSERT INTO `rms_user_log`  VALUES ( "261","12","2016-11-13 15:50:13","out");
INSERT INTO `rms_user_log`  VALUES ( "262","16","2016-11-13 15:50:27","in");
INSERT INTO `rms_user_log`  VALUES ( "263","16","2016-11-13 16:01:08","out");
INSERT INTO `rms_user_log`  VALUES ( "264","12","2016-11-17 07:03:14","in");
INSERT INTO `rms_user_log`  VALUES ( "265","17","2016-11-17 15:10:50","in");
INSERT INTO `rms_user_log`  VALUES ( "266","24","2016-11-17 17:14:39","in");
INSERT INTO `rms_user_log`  VALUES ( "267","15","2016-11-18 07:28:43","in");
INSERT INTO `rms_user_log`  VALUES ( "268","15","2016-11-18 07:34:47","out");
INSERT INTO `rms_user_log`  VALUES ( "269","17","2016-11-18 07:35:22","in");
INSERT INTO `rms_user_log`  VALUES ( "270","17","2016-11-18 07:48:28","in");
INSERT INTO `rms_user_log`  VALUES ( "271","15","2016-11-18 07:52:59","in");
INSERT INTO `rms_user_log`  VALUES ( "272","15","2016-11-18 08:00:19","out");
INSERT INTO `rms_user_log`  VALUES ( "273","1","2016-11-18 08:06:24","in");
INSERT INTO `rms_user_log`  VALUES ( "274","17","2016-11-18 08:41:41","in");
INSERT INTO `rms_user_log`  VALUES ( "275","16","2016-11-18 09:01:01","in");
INSERT INTO `rms_user_log`  VALUES ( "276","17","2016-11-18 10:09:12","in");
INSERT INTO `rms_user_log`  VALUES ( "277","17","2016-11-18 13:43:53","in");
INSERT INTO `rms_user_log`  VALUES ( "278","17","2016-11-18 14:46:31","in");
INSERT INTO `rms_user_log`  VALUES ( "279","24","2016-11-18 16:32:55","in");
INSERT INTO `rms_user_log`  VALUES ( "280","17","2016-11-18 16:48:49","in");
INSERT INTO `rms_user_log`  VALUES ( "281","24","2016-11-18 16:58:09","in");
INSERT INTO `rms_user_log`  VALUES ( "282","24","2016-11-18 16:58:41","in");
INSERT INTO `rms_user_log`  VALUES ( "283","1","2016-11-19 08:16:28","in");
INSERT INTO `rms_user_log`  VALUES ( "284","1","2016-11-19 08:22:10","out");
INSERT INTO `rms_user_log`  VALUES ( "285","25","2016-11-19 08:22:13","in");
INSERT INTO `rms_user_log`  VALUES ( "286","25","2016-11-19 10:38:45","out");
INSERT INTO `rms_user_log`  VALUES ( "287","25","2016-11-19 10:39:11","in");
INSERT INTO `rms_user_log`  VALUES ( "288","25","2016-11-19 10:50:51","out");
INSERT INTO `rms_user_log`  VALUES ( "289","25","2016-11-19 10:50:53","in");
INSERT INTO `rms_user_log`  VALUES ( "290","25","2016-11-19 10:53:27","out");
INSERT INTO `rms_user_log`  VALUES ( "291","25","2016-11-19 10:53:40","in");
INSERT INTO `rms_user_log`  VALUES ( "292","25","2016-11-19 10:54:57","out");
INSERT INTO `rms_user_log`  VALUES ( "293","25","2016-11-19 10:55:06","in");
INSERT INTO `rms_user_log`  VALUES ( "294","25","2016-11-19 10:55:55","in");
INSERT INTO `rms_user_log`  VALUES ( "295","25","2016-11-22 14:59:04","in");
INSERT INTO `rms_user_log`  VALUES ( "296","25","2016-11-24 13:29:05","in");
INSERT INTO `rms_user_log`  VALUES ( "297","25","2016-11-25 08:38:08","in");
INSERT INTO `rms_user_log`  VALUES ( "298","25","2016-11-25 09:01:26","out");
INSERT INTO `rms_user_log`  VALUES ( "299","1","2016-11-25 09:01:30","in");
INSERT INTO `rms_user_log`  VALUES ( "300","1","2016-11-25 09:33:54","out");
INSERT INTO `rms_user_log`  VALUES ( "301","25","2016-11-25 09:33:57","in");
INSERT INTO `rms_user_log`  VALUES ( "302","25","2016-11-25 14:57:42","in");
INSERT INTO `rms_user_log`  VALUES ( "303","25","2016-11-25 15:11:03","in");
INSERT INTO `rms_user_log`  VALUES ( "304","25","2016-11-25 15:35:43","out");
INSERT INTO `rms_user_log`  VALUES ( "305","25","2016-11-25 15:35:48","in");
INSERT INTO `rms_user_log`  VALUES ( "306","25","2016-11-25 15:36:53","out");
INSERT INTO `rms_user_log`  VALUES ( "307","25","2016-11-25 15:36:58","in");
INSERT INTO `rms_user_log`  VALUES ( "308","25","2016-11-28 19:46:08","in");
INSERT INTO `rms_user_log`  VALUES ( "309","25","2016-11-29 08:12:09","in");
INSERT INTO `rms_user_log`  VALUES ( "310","25","2016-11-29 13:19:56","in");
INSERT INTO `rms_user_log`  VALUES ( "311","25","2016-11-29 13:33:51","out");
INSERT INTO `rms_user_log`  VALUES ( "312","26","2016-11-29 13:35:38","in");
INSERT INTO `rms_user_log`  VALUES ( "313","8","2016-11-29 13:57:37","out");
INSERT INTO `rms_user_log`  VALUES ( "314","26","2016-11-29 13:57:41","in");
INSERT INTO `rms_user_log`  VALUES ( "315","26","2016-11-29 13:59:39","out");
INSERT INTO `rms_user_log`  VALUES ( "316","25","2016-11-29 13:59:42","in");
INSERT INTO `rms_user_log`  VALUES ( "317","1","2016-11-29 14:03:41","out");
INSERT INTO `rms_user_log`  VALUES ( "318","26","2016-11-29 14:03:47","in");
INSERT INTO `rms_user_log`  VALUES ( "319","25","2016-11-29 14:16:22","out");
INSERT INTO `rms_user_log`  VALUES ( "320","26","2016-11-29 14:18:16","in");
INSERT INTO `rms_user_log`  VALUES ( "321","26","2016-11-29 14:26:20","out");
INSERT INTO `rms_user_log`  VALUES ( "322","25","2016-11-29 14:26:24","in");
INSERT INTO `rms_user_log`  VALUES ( "323","26","2016-11-29 14:29:46","out");
INSERT INTO `rms_user_log`  VALUES ( "324","25","2016-11-29 14:29:48","in");
INSERT INTO `rms_user_log`  VALUES ( "325","25","2016-11-29 14:33:48","in");
INSERT INTO `rms_user_log`  VALUES ( "326","25","2016-12-06 11:10:26","in");
INSERT INTO `rms_user_log`  VALUES ( "327","25","2016-12-07 08:13:09","in");
INSERT INTO `rms_user_log`  VALUES ( "328","25","2016-12-07 18:00:51","in");
INSERT INTO `rms_user_log`  VALUES ( "329","25","2016-12-08 08:15:23","in");
INSERT INTO `rms_user_log`  VALUES ( "330","25","2016-12-08 09:58:11","in");
INSERT INTO `rms_user_log`  VALUES ( "331","25","2016-12-08 11:02:30","out");
INSERT INTO `rms_user_log`  VALUES ( "332","1","2016-12-08 11:02:37","in");
INSERT INTO `rms_user_log`  VALUES ( "333","1","2016-12-08 12:05:32","out");
INSERT INTO `rms_user_log`  VALUES ( "334","25","2016-12-08 12:05:40","in");
INSERT INTO `rms_user_log`  VALUES ( "335","1","2016-12-08 18:18:09","in");
INSERT INTO `rms_user_log`  VALUES ( "336","1","2016-12-08 18:56:14","out");
INSERT INTO `rms_user_log`  VALUES ( "337","26","2016-12-08 18:56:31","in");
INSERT INTO `rms_user_log`  VALUES ( "338","26","2016-12-08 18:59:38","out");
INSERT INTO `rms_user_log`  VALUES ( "339","1","2016-12-08 18:59:41","in");
INSERT INTO `rms_user_log`  VALUES ( "340","1","2016-12-08 19:01:29","out");
INSERT INTO `rms_user_log`  VALUES ( "341","1","2016-12-08 19:04:16","in");
INSERT INTO `rms_user_log`  VALUES ( "342","1","2016-12-08 19:07:56","out");
INSERT INTO `rms_user_log`  VALUES ( "343","27","2016-12-08 19:08:04","in");
INSERT INTO `rms_user_log`  VALUES ( "344","25","2016-12-09 08:44:49","in");
INSERT INTO `rms_user_log`  VALUES ( "345","25","2016-12-09 08:58:07","in");
INSERT INTO `rms_user_log`  VALUES ( "346","25","2016-12-09 09:05:13","out");
INSERT INTO `rms_user_log`  VALUES ( "347","25","2016-12-09 09:17:00","in");
INSERT INTO `rms_user_log`  VALUES ( "348","8","2016-12-09 16:40:24","out");
INSERT INTO `rms_user_log`  VALUES ( "349","25","2016-12-09 16:40:27","in");
INSERT INTO `rms_user_log`  VALUES ( "350","25","2016-12-11 15:50:08","in");
INSERT INTO `rms_user_log`  VALUES ( "351","25","2016-12-12 08:46:06","in");
INSERT INTO `rms_user_log`  VALUES ( "352","25","2016-12-12 09:03:13","in");
INSERT INTO `rms_user_log`  VALUES ( "353","25","2016-12-12 15:15:52","out");
INSERT INTO `rms_user_log`  VALUES ( "354","25","2016-12-12 15:15:56","in");
INSERT INTO `rms_user_log`  VALUES ( "355","25","2016-12-12 15:17:35","in");
INSERT INTO `rms_user_log`  VALUES ( "356","25","2016-12-13 08:24:10","in");
INSERT INTO `rms_user_log`  VALUES ( "357","25","2016-12-13 09:40:01","in");
INSERT INTO `rms_user_log`  VALUES ( "358","25","2016-12-13 13:32:35","in");
INSERT INTO `rms_user_log`  VALUES ( "359","25","2016-12-14 08:40:01","in");
INSERT INTO `rms_user_log`  VALUES ( "360","25","2016-12-14 16:23:12","in");
INSERT INTO `rms_user_log`  VALUES ( "361","1","2016-12-15 08:33:58","in");
INSERT INTO `rms_user_log`  VALUES ( "362","1","2016-12-15 08:34:02","out");
INSERT INTO `rms_user_log`  VALUES ( "363","25","2016-12-15 08:34:09","in");
INSERT INTO `rms_user_log`  VALUES ( "364","25","2016-12-15 17:16:28","out");
INSERT INTO `rms_user_log`  VALUES ( "365","1","2016-12-15 17:16:35","in");
INSERT INTO `rms_user_log`  VALUES ( "366","25","2016-12-16 08:21:54","in");
INSERT INTO `rms_user_log`  VALUES ( "367","8","2016-12-16 13:07:52","out");
INSERT INTO `rms_user_log`  VALUES ( "368","25","2016-12-16 13:13:15","in");
INSERT INTO `rms_user_log`  VALUES ( "369","25","2016-12-17 08:23:56","in");
INSERT INTO `rms_user_log`  VALUES ( "370","25","2016-12-17 10:55:32","out");
INSERT INTO `rms_user_log`  VALUES ( "371","25","2016-12-17 10:55:40","in");
INSERT INTO `rms_user_log`  VALUES ( "372","25","2016-12-19 08:20:49","in");
INSERT INTO `rms_user_log`  VALUES ( "373","25","2016-12-20 08:19:21","in");
INSERT INTO `rms_user_log`  VALUES ( "374","25","2016-12-21 13:35:29","in");
INSERT INTO `rms_user_log`  VALUES ( "375","25","2017-01-11 09:36:20","in");
INSERT INTO `rms_user_log`  VALUES ( "376","25","2017-01-11 09:37:29","out");
INSERT INTO `rms_user_log`  VALUES ( "377","1","2017-01-11 09:37:41","in");
INSERT INTO `rms_user_log`  VALUES ( "378","25","2017-01-13 10:32:52","in");
INSERT INTO `rms_user_log`  VALUES ( "379","25","2017-01-13 10:33:07","out");
INSERT INTO `rms_user_log`  VALUES ( "380","28","2017-01-13 10:33:10","in");
INSERT INTO `rms_user_log`  VALUES ( "381","25","2017-01-16 11:05:22","in");
INSERT INTO `rms_user_log`  VALUES ( "382","25","2017-01-18 10:20:45","in");
INSERT INTO `rms_user_log`  VALUES ( "383","25","2017-01-18 10:20:56","out");
INSERT INTO `rms_user_log`  VALUES ( "384","28","2017-01-18 10:20:59","in");
INSERT INTO `rms_user_log`  VALUES ( "385","28","2017-01-18 11:17:14","in");
INSERT INTO `rms_user_log`  VALUES ( "386","28","2017-01-20 08:25:59","in");
INSERT INTO `rms_user_log`  VALUES ( "387","28","2017-01-20 09:00:07","in");
INSERT INTO `rms_user_log`  VALUES ( "388","28","2017-01-21 08:42:32","in");
INSERT INTO `rms_user_log`  VALUES ( "389","28","2017-01-21 16:17:01","in");
INSERT INTO `rms_user_log`  VALUES ( "390","28","2017-01-23 08:36:55","in");
INSERT INTO `rms_user_log`  VALUES ( "391","28","2017-01-24 09:40:34","in");
INSERT INTO `rms_user_log`  VALUES ( "392","28","2017-01-24 10:16:19","in");
INSERT INTO `rms_user_log`  VALUES ( "393","28","2017-01-25 08:36:01","in");
INSERT INTO `rms_user_log`  VALUES ( "394","28","2017-02-01 09:48:17","in");
INSERT INTO `rms_user_log`  VALUES ( "395","28","2017-02-01 12:19:53","in");
INSERT INTO `rms_user_log`  VALUES ( "396","28","2017-02-01 13:52:33","out");
INSERT INTO `rms_user_log`  VALUES ( "397","25","2017-02-01 13:52:36","in");
INSERT INTO `rms_user_log`  VALUES ( "398","25","2017-02-01 13:54:59","out");
INSERT INTO `rms_user_log`  VALUES ( "399","28","2017-02-01 13:55:08","in");
INSERT INTO `rms_user_log`  VALUES ( "400","28","2017-02-01 14:04:37","out");
INSERT INTO `rms_user_log`  VALUES ( "401","25","2017-02-01 14:04:41","in");
INSERT INTO `rms_user_log`  VALUES ( "402","25","2017-02-01 14:07:13","out");
INSERT INTO `rms_user_log`  VALUES ( "403","28","2017-02-01 14:07:17","in");
INSERT INTO `rms_user_log`  VALUES ( "404","28","2017-02-01 14:26:14","out");
INSERT INTO `rms_user_log`  VALUES ( "405","25","2017-02-01 14:26:17","in");
INSERT INTO `rms_user_log`  VALUES ( "406","25","2017-02-01 14:28:16","out");
INSERT INTO `rms_user_log`  VALUES ( "407","28","2017-02-01 14:28:20","in");
INSERT INTO `rms_user_log`  VALUES ( "408","28","2017-02-01 14:29:32","out");
INSERT INTO `rms_user_log`  VALUES ( "409","25","2017-02-01 14:29:42","in");
INSERT INTO `rms_user_log`  VALUES ( "410","25","2017-02-01 14:37:20","out");
INSERT INTO `rms_user_log`  VALUES ( "411","28","2017-02-01 14:37:24","in");
INSERT INTO `rms_user_log`  VALUES ( "412","28","2017-02-01 14:44:34","out");
INSERT INTO `rms_user_log`  VALUES ( "413","25","2017-02-01 14:44:38","in");
INSERT INTO `rms_user_log`  VALUES ( "414","25","2017-02-01 15:56:24","out");
INSERT INTO `rms_user_log`  VALUES ( "415","28","2017-02-01 15:56:28","in");
INSERT INTO `rms_user_log`  VALUES ( "416","28","2017-02-02 08:19:19","in");
INSERT INTO `rms_user_log`  VALUES ( "417","28","2017-02-02 08:54:03","in");
INSERT INTO `rms_user_log`  VALUES ( "418","28","2017-02-02 15:40:47","in");
INSERT INTO `rms_user_log`  VALUES ( "419","28","2017-02-04 09:05:14","in");
INSERT INTO `rms_user_log`  VALUES ( "420","28","2017-02-04 10:58:06","in");
INSERT INTO `rms_user_log`  VALUES ( "421","28","2017-02-09 14:10:18","in");
INSERT INTO `rms_user_log`  VALUES ( "422","28","2017-02-10 08:32:03","in");
INSERT INTO `rms_user_log`  VALUES ( "423","28","2017-02-10 08:45:55","out");
INSERT INTO `rms_user_log`  VALUES ( "424","28","2017-02-10 08:45:58","in");
INSERT INTO `rms_user_log`  VALUES ( "425","28","2017-02-10 09:07:50","in");
INSERT INTO `rms_user_log`  VALUES ( "426","28","2017-02-10 14:03:04","in");
INSERT INTO `rms_user_log`  VALUES ( "427","28","2017-02-14 12:02:51","in");
INSERT INTO `rms_user_log`  VALUES ( "428","28","2017-02-15 08:29:50","in");
INSERT INTO `rms_user_log`  VALUES ( "429","28","2017-02-15 10:47:11","out");
INSERT INTO `rms_user_log`  VALUES ( "430","28","2017-02-20 16:21:15","in");
INSERT INTO `rms_user_log`  VALUES ( "431","28","2017-02-21 08:31:36","in");
INSERT INTO `rms_user_log`  VALUES ( "432","28","2017-02-21 10:47:46","in");
INSERT INTO `rms_user_log`  VALUES ( "433","25","2017-02-21 15:10:27","in");
INSERT INTO `rms_user_log`  VALUES ( "434","25","2017-02-21 15:10:34","out");
INSERT INTO `rms_user_log`  VALUES ( "435","28","2017-02-21 15:10:37","in");
INSERT INTO `rms_user_log`  VALUES ( "436","28","2017-02-21 15:24:12","in");
INSERT INTO `rms_user_log`  VALUES ( "437","28","2017-02-21 16:14:30","in");
INSERT INTO `rms_user_log`  VALUES ( "438","28","2017-02-21 16:39:10","in");
INSERT INTO `rms_user_log`  VALUES ( "439","28","2017-02-21 16:43:14","in");
INSERT INTO `rms_user_log`  VALUES ( "440","28","2017-02-21 17:05:27","in");
INSERT INTO `rms_user_log`  VALUES ( "441","28","2017-02-21 17:21:08","in");
INSERT INTO `rms_user_log`  VALUES ( "442","28","2017-02-22 08:34:12","in");
INSERT INTO `rms_user_log`  VALUES ( "443","28","2017-02-22 13:47:29","in");
INSERT INTO `rms_user_log`  VALUES ( "444","28","2017-03-01 08:14:07","in");
INSERT INTO `rms_user_log`  VALUES ( "445","28","2017-03-02 08:46:10","in");
INSERT INTO `rms_user_log`  VALUES ( "446","28","2017-03-02 10:07:02","in");
INSERT INTO `rms_user_log`  VALUES ( "447","28","2017-03-02 10:39:05","in");
INSERT INTO `rms_user_log`  VALUES ( "448","28","2017-03-02 15:31:35","in");
INSERT INTO `rms_user_log`  VALUES ( "449","28","2017-03-02 15:42:23","in");
INSERT INTO `rms_user_log`  VALUES ( "450","28","2017-03-03 08:36:55","in");
INSERT INTO `rms_user_log`  VALUES ( "451","28","2017-03-04 08:14:11","in");
INSERT INTO `rms_user_log`  VALUES ( "452","28","2017-03-07 08:30:14","in");
INSERT INTO `rms_user_log`  VALUES ( "453","28","2017-03-10 08:18:56","in");
INSERT INTO `rms_user_log`  VALUES ( "454","28","2017-03-10 08:56:39","in");
INSERT INTO `rms_user_log`  VALUES ( "455","28","2017-03-27 10:33:06","in");
INSERT INTO `rms_user_log`  VALUES ( "456","28","2017-03-31 14:26:02","in");
INSERT INTO `rms_user_log`  VALUES ( "457","28","2017-03-31 14:26:02","in");
INSERT INTO `rms_user_log`  VALUES ( "458","28","2017-04-05 08:25:05","in");
INSERT INTO `rms_user_log`  VALUES ( "459","1","2017-04-05 08:58:00","out");
INSERT INTO `rms_user_log`  VALUES ( "460","28","2017-04-05 08:58:04","in");
INSERT INTO `rms_user_log`  VALUES ( "461","28","2017-05-17 11:10:11","in");
INSERT INTO `rms_user_log`  VALUES ( "462","28","2017-05-17 11:31:24","out");
INSERT INTO `rms_user_log`  VALUES ( "463","28","2017-05-17 11:31:33","in");
INSERT INTO `rms_user_log`  VALUES ( "464","28","2017-05-17 12:09:57","out");
INSERT INTO `rms_user_log`  VALUES ( "465","28","2017-05-17 12:10:01","in");
INSERT INTO `rms_user_log`  VALUES ( "466","28","2017-05-17 12:12:57","out");
INSERT INTO `rms_user_log`  VALUES ( "467","28","2017-05-17 12:13:02","in");
INSERT INTO `rms_user_log`  VALUES ( "468","28","2017-05-17 14:17:35","out");
INSERT INTO `rms_user_log`  VALUES ( "469","28","2017-05-17 14:17:38","in");
INSERT INTO `rms_user_log`  VALUES ( "470","28","2017-05-17 14:24:13","out");
INSERT INTO `rms_user_log`  VALUES ( "471","28","2017-05-17 14:24:17","in");
INSERT INTO `rms_user_log`  VALUES ( "472","28","2017-05-18 08:29:29","in");
INSERT INTO `rms_user_log`  VALUES ( "473","28","2017-05-18 08:30:55","out");
INSERT INTO `rms_user_log`  VALUES ( "474","28","2017-05-18 08:37:31","in");
INSERT INTO `rms_user_log`  VALUES ( "475","28","2017-05-23 15:35:37","in");
INSERT INTO `rms_user_log`  VALUES ( "476","28","2017-05-24 08:30:31","in");
INSERT INTO `rms_user_log`  VALUES ( "477","28","2017-05-24 14:48:30","in");
INSERT INTO `rms_user_log`  VALUES ( "478","28","2017-05-25 08:12:10","in");


--
-- Tabel structure for table `rms_users`
--
DROP TABLE  IF EXISTS `rms_users`;
CREATE TABLE `rms_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `user_name` varchar(128) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_type` tinyint(1) DEFAULT '0' COMMENT '0: transfer; 1:admin',
  `active` tinyint(1) DEFAULT '1',
  `branch_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `rms_users`  VALUES ( "1","?????","????","channy","5f4dcc3b5aa765d61d8327deb882cf99","1","1","1");
INSERT INTO `rms_users`  VALUES ( "25","Seyha","Soy","seyha","5f4dcc3b5aa765d61d8327deb882cf99","4","1","1");
INSERT INTO `rms_users`  VALUES ( "26","pisey","thy","pisey","5f4dcc3b5aa765d61d8327deb882cf99","4","1","1");
INSERT INTO `rms_users`  VALUES ( "28","admin","admin","admin","5f4dcc3b5aa765d61d8327deb882cf99","1","1","1");


--
-- Tabel structure for table `rms_view`
--
DROP TABLE  IF EXISTS `rms_view`;
CREATE TABLE `rms_view` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(50) DEFAULT NULL,
  `name_kh` varchar(50) DEFAULT NULL,
  `key_code` varchar(20) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT '1' COMMENT '1khmer',
  `type` int(11) DEFAULT NULL COMMENT '1=term',
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `rms_view`  VALUES ( "1","active","??????????","1","1","1","1");
INSERT INTO `rms_view`  VALUES ( "2","deactive","?????????","0","1","1","1");
INSERT INTO `rms_view`  VALUES ( "3","M","?????","1","1","2","1");
INSERT INTO `rms_view`  VALUES ( "4","F","????","2","1","2","1");
INSERT INTO `rms_view`  VALUES ( "5","Associat","?????????????","1","1","3","1");
INSERT INTO `rms_view`  VALUES ( "6","Bachelor","???????????","2","1","3","1");
INSERT INTO `rms_view`  VALUES ( "7","Master","?????????","3","1","3","1");
INSERT INTO `rms_view`  VALUES ( "8","Docter","??????","4","1","3","1");
INSERT INTO `rms_view`  VALUES ( "9","Morning","?????","1","1","4","1");
INSERT INTO `rms_view`  VALUES ( "10","Afternoon","????","2","1","4","1");
INSERT INTO `rms_view`  VALUES ( "11","Everning","?????","3","1","4","1");
INSERT INTO `rms_view`  VALUES ( "13","Part-Time","????????","1","1","7","1");
INSERT INTO `rms_view`  VALUES ( "14","Full-Time","???????","2","1","7","1");
INSERT INTO `rms_view`  VALUES ( "15","FullDay","??????????","4","1","4","1");
INSERT INTO `rms_view`  VALUES ( "16","Suspend","??????????????","1","1","5","1");
INSERT INTO `rms_view`  VALUES ( "17","Stop","?????????","2","1","5","1");
INSERT INTO `rms_view`  VALUES ( "18","NOT Yet USE","?????????????????","0","1","9","1");
INSERT INTO `rms_view`  VALUES ( "19","Finished","???????????????","1","1","9","1");
INSERT INTO `rms_view`  VALUES ( "20","Studying","???????????","2","1","9","1");
INSERT INTO `rms_view`  VALUES ( "21","1 Month","??","1","1","6","1");
INSERT INTO `rms_view`  VALUES ( "22","3 Months","???????","2","1","6","1");
INSERT INTO `rms_view`  VALUES ( "23","6 Months","????","3","1","6","1");
INSERT INTO `rms_view`  VALUES ( "24","1 Year","?????","4","1","6","1");
INSERT INTO `rms_view`  VALUES ( "25","Dollar","???????","1","1","8","1");
INSERT INTO `rms_view`  VALUES ( "26","Riel","???","2","1","8","1");
INSERT INTO `rms_view`  VALUES ( "27","Void","?????????","1","1","10","1");
INSERT INTO `rms_view`  VALUES ( "28","Using","??????????","0","1","10","1");


--
-- Tabel structure for table `v_getallstudentbygroup`
--
DROP TABLE  IF EXISTS `v_getallstudentbygroup`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getallstudentbygroup` AS (select `rms_group_detail_student`.`group_id` AS `group_id`,`rms_group_detail_student`.`stu_id` AS `stu_id`,(select `rms_group`.`group_code` from `rms_group` where (`rms_group`.`id` = `rms_group_detail_student`.`group_id`)) AS `group_code`,(select `rms_student`.`stu_code` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `stu_code`,(select `rms_student`.`stu_khname` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `kh_name`,(select `rms_student`.`stu_enname` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `en_name`,(select `rms_student`.`nationality` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `nation`,(select `rms_student`.`address` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `pob`,(select `rms_student`.`tel` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `tel`,(select (select `rms_view`.`name_kh` from `rms_view` where ((`rms_view`.`type` = 2) and (`rms_view`.`key_code` = `rms_student`.`sex`))) from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `sex`,(select `rms_student`.`dob` from `rms_student` where (`rms_student`.`stu_id` = `rms_group_detail_student`.`stu_id`)) AS `dob`,(select (select `rms_room`.`room_name` from `rms_room` where (`rms_room`.`room_id` = `rms_group`.`room_id`)) from `rms_group` where (`rms_group`.`id` = `rms_group_detail_student`.`group_id`)) AS `room`,(select (select `rms_view`.`name_en` from `rms_view` where ((`rms_view`.`type` = 4) and (`rms_view`.`key_code` = `rms_group`.`session`))) from `rms_group` where (`rms_group`.`id` = `rms_group_detail_student`.`group_id`)) AS `session`,(select concat(`rms_group`.`from_academic`,'-',`rms_group`.`to_academic`) from `rms_group` where (`rms_group`.`id` = `rms_group_detail_student`.`group_id`)) AS `academic`,`rms_group_detail_student`.`status` AS `status` from `rms_group_detail_student` where (`rms_group_detail_student`.`status` = 1));

INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","1","???????? ? A","00001","Sok Chanreaksmey","Sok Chanreaksmey","","","Sok Chanreaksmey","?????","2017-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","5","???????? ? A","00004","Lana","Lana","Lana","","Lana","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","6","???????? ? A","00005","Walcott","Walcott","","","Walcott","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","7","???????? ? A","00006","Sanchez","Sanchez","Sanchez","","Sanchez","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","8","???????? ? A","00007","Ozil","Ozil","","","Ozil","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","9","???????? ? A","00008","Ox","Ox","","","Ox","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","10","???????? ? A","00009","Santi","Santi","","","Santi","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","11","???????? ? A","00010","Kos","Kos","Kos","","Kos","?????","2000-03-03","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "1","12","???????? ? A","00011","??? ?????????","Sok Dararatanak","","","","?????","1999-03-07","Room 1","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "6","13","????????? A1","00002","rhdrhdrf","drhdyrydr","","","","?????","2017-03-31","Room 8","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "2","14","???????? ? B","00012","Test12","Test12","","","","?????","2017-04-05","Room 1","Afternoon","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "10","16","Eng Kind(Pre k)Morning ","00001/CAS/ENG","Dan Theo","Dan Theo","","","Dan Theo","?????","2017-05-17","Room 7","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "5","17","????????? A1","00003","fhf","sdgsd","","","","?????","2017-05-18","Room 7","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "3","18","????????? A","00014","??? ????a","Sok Thida","","","015 236 147a","????","2004-04-13","Room 2","Morning","","1");
INSERT INTO `v_getallstudentbygroup`  VALUES ( "7","19","????????? A1","00015","??? ????a","Sok Thida","","","015 236 147a","????","2004-04-13","Room 6","Morning","","1");


--
-- Tabel structure for table `v_getstudentpayment`
--
DROP TABLE  IF EXISTS `v_getstudentpayment`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getstudentpayment` AS (select `rms_student_payment`.`id` AS `id`,`rms_student_payment`.`student_id` AS `student_id`,(select `rms_student`.`stu_code` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `stu_code`,(select `rms_student`.`stu_khname` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `kh_name`,(select `rms_student`.`stu_enname` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `en_name`,(select (select `rms_view`.`name_en` from `rms_view` where ((`rms_view`.`type` = 2) and (`rms_view`.`key_code` = `rms_student`.`sex`))) from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `sex`,(select `rms_student`.`nationality` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `nationality`,(select `rms_student`.`tel` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `tel`,(select `rms_student`.`dob` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) AS `dob`,`rms_student_payment`.`receipt_number` AS `receipt_number`,`rms_student_payment`.`total` AS `total`,`rms_student_payment`.`total_payment` AS `total_payment`,`rms_student_payment`.`discount_fix` AS `discount_fix`,`rms_student_payment`.`paid_amount` AS `paid_amount`,`rms_student_payment`.`receive_amount` AS `receive_amount`,`rms_student_payment`.`return_amount` AS `return_amount`,`rms_student_payment`.`tuition_fee` AS `tuition_fee`,`rms_student_payment`.`balance_due` AS `balance_due`,`rms_student_payment`.`grand_total` AS `grand_total`,`spd`.`fee` AS `fee`,`spd`.`qty` AS `qty`,`spd`.`payment_term` AS `payment_term`,`spd`.`discount_percent` AS `discount_percent`,`spd`.`subtotal` AS `subtotal`,`spd`.`paidamount` AS `paidamount`,`spd`.`balance` AS `balance`,(select concat(`rms_users`.`last_name`,' ',`rms_users`.`first_name`) from `rms_users` where (`rms_users`.`id` = `rms_student_payment`.`user_id`)) AS `USER`,`rms_student_payment`.`amount_in_khmer` AS `amount_in_khmer`,`rms_student_payment`.`note` AS `note`,`rms_student_payment`.`create_date` AS `create_date` from (`rms_student_payment` join `rms_student_paymentdetail` `spd`) where (`rms_student_payment`.`id` = `spd`.`payment_id`));

INSERT INTO `v_getstudentpayment`  VALUES ( "1","1","00001","Sok Chanreaksmey","Sok Chanreaksmey","M","","Sok Chanreaksmey","2017-03-03","000001","288.00","288.00","","288","288.00","","320.00","0","303.20","320.00","1","4","10","291.20","291.20","0.00","admin admin","","","2017-03-03");
INSERT INTO `v_getstudentpayment`  VALUES ( "1","1","00001","Sok Chanreaksmey","Sok Chanreaksmey","M","","Sok Chanreaksmey","2017-03-03","000001","288.00","288.00","","288","288.00","","320.00","0","303.20","12.00","1","0","0","12.00","12.00","0.00","admin admin","","","2017-03-03");
INSERT INTO `v_getstudentpayment`  VALUES ( "2","3","00002","Chea Socheata","Chea Socheata","M","","Chea Socheata","2017-03-03","000002","165.00","165.00","","165","165.00","","165.00","0","166.65","165.00","1","3","0","166.65","166.65","0.00","admin admin","","","2017-03-03");
INSERT INTO `v_getstudentpayment`  VALUES ( "3","4","00003","Hann Nita","Hann Nita","M","","Hann Nita","2017-03-03","000003","175.00","175.00","","175","175.00","","175.00","0","176.75","175.00","1","3","0","176.75","176.75","0.00","admin admin","","","2017-03-03");
INSERT INTO `v_getstudentpayment`  VALUES ( "4","12","00011","??? ?????????","Sok Dararatanak","M","","","1999-03-07","000004","132.00","132.00","","132","132.00","","165.00","0","201.65","165.00","1","3","20","133.65","133.65","0.00","","","","2017-03-07");
INSERT INTO `v_getstudentpayment`  VALUES ( "4","12","00011","??? ?????????","Sok Dararatanak","M","","","1999-03-07","000004","132.00","132.00","","132","132.00","","165.00","0","201.65","42.00","1","1","0","42.00","42.00","0.00","","","","2017-03-07");
INSERT INTO `v_getstudentpayment`  VALUES ( "4","12","00011","??? ?????????","Sok Dararatanak","M","","","1999-03-07","000004","132.00","132.00","","132","132.00","","165.00","0","201.65","26.00","1","1","0","26.00","26.00","0.00","","","","2017-03-07");
INSERT INTO `v_getstudentpayment`  VALUES ( "5","2","00001","San Dara","San Dara","M","San Dara","San Dara","2000-03-03","000005","250.00","250.00","","250","250.00","","250.00","0","252.50","250.00","1","3","0","252.50","252.50","0.00","admin admin","","","2017-03-10");
INSERT INTO `v_getstudentpayment`  VALUES ( "6","1","00001","Sok Chanreaksmey","Sok Chanreaksmey","M","","Sok Chanreaksmey","2017-03-03","000006","35.00","35.00","","35","35.00","","35.00","0","87.35","35.00","1","1","0","35.35","35.35","0.00","admin admin","","","2017-03-10");
INSERT INTO `v_getstudentpayment`  VALUES ( "6","1","00001","Sok Chanreaksmey","Sok Chanreaksmey","M","","Sok Chanreaksmey","2017-03-03","000006","35.00","35.00","","35","35.00","","35.00","0","87.35","42.00","1","1","0","42.00","42.00","0.00","admin admin","","","2017-03-10");
INSERT INTO `v_getstudentpayment`  VALUES ( "6","1","00001","Sok Chanreaksmey","Sok Chanreaksmey","M","","Sok Chanreaksmey","2017-03-03","000006","35.00","35.00","","35","35.00","","35.00","0","87.35","10.00","1","0","0","10.00","10.00","0.00","admin admin","","","2017-03-10");
INSERT INTO `v_getstudentpayment`  VALUES ( "7","7","00006","Sanchez","Sanchez","M","Sanchez","Sanchez","2000-03-03","000007","165.00","165.00","","165","165.00","","165.00","0","218.65","165.00","1","3","0","166.65","166.65","0.00","admin admin","","","2017-03-10");
INSERT INTO `v_getstudentpayment`  VALUES ( "7","7","00006","Sanchez","Sanchez","M","Sanchez","Sanchez","2000-03-03","000007","165.00","165.00","","165","165.00","","165.00","0","218.65","26.00","2","1","0","52.00","52.00","0.00","admin admin","","","2017-03-10");
INSERT INTO `v_getstudentpayment`  VALUES ( "8","13","00002","rhdrhdrf","drhdyrydr","M","","","2017-03-31","000008","45.00","45.00","","45","45.00","","45.00","0","87.45","45.00","1","1","0","45.45","45.45","0.00","admin admin","","","2017-03-31");
INSERT INTO `v_getstudentpayment`  VALUES ( "8","13","00002","rhdrhdrf","drhdyrydr","M","","","2017-03-31","000008","45.00","45.00","","45","45.00","","45.00","0","87.45","42.00","1","1","0","42.00","42.00","0.00","admin admin","","","2017-03-31");
INSERT INTO `v_getstudentpayment`  VALUES ( "9","14","00012","Test12","Test12","M","","","2017-04-05","000009","35.00","35.00","","30","30.00","","35.00","5","67.35","35.00","1","1","0","35.35","30.35","5.00","admin admin","","","2017-04-05");
INSERT INTO `v_getstudentpayment`  VALUES ( "9","14","00012","Test12","Test12","M","","","2017-04-05","000009","35.00","35.00","","30","30.00","","35.00","5","67.35","32.00","1","1","0","32.00","32.00","0.00","admin admin","","","2017-04-05");
INSERT INTO `v_getstudentpayment`  VALUES ( "10","14","00012","Test12","Test12","M","","","2017-04-05","000010","5.00","5.00","","5","5.00","","5.00","0","5.00","5.00","1","1","0","5.00","5.00","0.00","admin admin","","??????????????","2017-04-05");
INSERT INTO `v_getstudentpayment`  VALUES ( "11","15","00013","","","M","","","2017-05-17","000011","35.00","35.00","","35","35.00","","35.00","0","43.35","35.00","1","1","0","35.35","35.35","0.00","admin admin","","","2017-05-17");
INSERT INTO `v_getstudentpayment`  VALUES ( "11","15","00013","","","M","","","2017-05-17","000011","35.00","35.00","","35","35.00","","35.00","0","43.35","8.00","1","1","0","8.00","8.00","0.00","admin admin","","","2017-05-17");
INSERT INTO `v_getstudentpayment`  VALUES ( "12","16","00001/CAS/ENG","Dan Theo","Dan Theo","M","","Dan Theo","2017-05-17","000012","170.00","170.00","","170","170.00","","170.00","0","171.70","170.00","1","3","0","171.70","171.70","0.00","admin admin","","Dan Theo","2017-05-17");
INSERT INTO `v_getstudentpayment`  VALUES ( "13","17","00003","fhf","sdgsd","M","","","2017-05-18","000013","45.00","45.00","","45","45.00","","45.00","0","71.45","45.00","1","1","0","45.45","45.45","0.00","admin admin","","","2017-05-18");
INSERT INTO `v_getstudentpayment`  VALUES ( "13","17","00003","fhf","sdgsd","M","","","2017-05-18","000013","45.00","45.00","","45","45.00","","45.00","0","71.45","26.00","1","1","0","26.00","26.00","0.00","admin admin","","","2017-05-18");
INSERT INTO `v_getstudentpayment`  VALUES ( "14","18","00014","??? ????a","Sok Thida","F","","015 236 147a","2004-04-13","000014","165.00","165.00","","165","165.00","","165.00","0","198.65","165.00","1","3","0","166.65","166.65","0.00","admin admin","","","2017-05-24");
INSERT INTO `v_getstudentpayment`  VALUES ( "14","18","00014","??? ????a","Sok Thida","F","","015 236 147a","2004-04-13","000014","165.00","165.00","","165","165.00","","165.00","0","198.65","32.00","1","1","0","32.00","32.00","0.00","admin admin","","","2017-05-24");
INSERT INTO `v_getstudentpayment`  VALUES ( "15","19","00015","??? ????a","Sok Thida","F","","015 236 147a","2004-04-13","000015","40.00","40.00","","40","40.00","","40.00","0","66.40","40.00","1","1","0","40.40","40.40","0.00","admin admin","","","2017-05-24");
INSERT INTO `v_getstudentpayment`  VALUES ( "15","19","00015","??? ????a","Sok Thida","F","","015 236 147a","2004-04-13","000015","40.00","40.00","","40","40.00","","40.00","0","66.40","26.00","1","1","0","26.00","26.00","0.00","admin admin","","","2017-05-24");


--
-- Tabel structure for table `v_getstudentpaymentdetail`
--
DROP TABLE  IF EXISTS `v_getstudentpaymentdetail`;
CREATE ALGORITHM=TEMPTABLE DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getstudentpaymentdetail` AS (select `rms_student_paymentdetail`.`id` AS `id`,`rms_student_paymentdetail`.`payment_id` AS `payment_id`,`rms_student_paymentdetail`.`service_id` AS `service_id`,(select `rms_student_payment`.`receipt_number` from `rms_student_payment` where (`rms_student_payment`.`id` = `rms_student_paymentdetail`.`payment_id`) limit 1) AS `receipt_number`,(select (select `rms_student`.`stu_khname` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) from `rms_student_payment` where (`rms_student_payment`.`id` = `rms_student_paymentdetail`.`payment_id`) limit 1) AS `kh_name`,(select (select `rms_student`.`stu_enname` from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) from `rms_student_payment` where (`rms_student_payment`.`id` = `rms_student_paymentdetail`.`payment_id`) limit 1) AS `en_name`,(select `rms_student_payment`.`other_fee` from `rms_student_payment` where (`rms_student_payment`.`id` = `rms_student_paymentdetail`.`payment_id`) limit 1) AS `other_fee`,(select (select (select `rms_view`.`name_kh` from `rms_view` where ((`rms_view`.`type` = 2) and (`rms_view`.`key_code` = `rms_student`.`sex`))) from `rms_student` where (`rms_student`.`stu_id` = `rms_student_payment`.`student_id`) limit 1) from `rms_student_payment` where (`rms_student_payment`.`id` = `rms_student_paymentdetail`.`payment_id`) limit 1) AS `sex`,`rms_student_paymentdetail`.`type` AS `type`,(select `rms_program_name`.`title` from `rms_program_name` where (`rms_program_name`.`service_id` = `rms_student_paymentdetail`.`service_id`) limit 1) AS `service`,(select `rms_view`.`name_en` from `rms_view` where ((`rms_view`.`type` = 6) and (`rms_view`.`key_code` = `rms_student_paymentdetail`.`payment_term`)) limit 1) AS `payment_term`,`rms_student_paymentdetail`.`fee` AS `fee`,`rms_student_paymentdetail`.`qty` AS `qty`,`rms_student_paymentdetail`.`admin_fee` AS `admin_fee`,`rms_student_paymentdetail`.`subtotal` AS `subtotal`,`rms_student_paymentdetail`.`discount_fix` AS `discount_fix`,`rms_student_paymentdetail`.`validate` AS `validate`,`rms_student_paymentdetail`.`discount_percent` AS `discount_percent`,`rms_student_paymentdetail`.`paidamount` AS `paid_amount`,`rms_student_paymentdetail`.`paidamount` AS `receive_amount`,`rms_student_paymentdetail`.`balance` AS `balance_due`,`rms_student_payment`.`is_void` AS `is_void`,`rms_student_payment`.`branch_id` AS `branch_id`,(select `rms_view`.`name_en` from `rms_view` where ((`rms_view`.`type` = 10) and (`rms_view`.`key_code` = `rms_student_payment`.`is_void`))) AS `status_void`,(select concat(`rms_users`.`last_name`,' ',`rms_users`.`first_name`) from `rms_users` where (`rms_users`.`id` = `rms_student_payment`.`user_id`) limit 1) AS `user`,`rms_student_paymentdetail`.`note` AS `note`,`rms_student_payment`.`create_date` AS `create_date` from (`rms_student_paymentdetail` join `rms_student_payment`) where (`rms_student_payment`.`id` = `rms_student_paymentdetail`.`payment_id`));

INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "1","1","4","000001","Sok Chanreaksmey","Sok Chanreaksmey","","?????","1","Tuition Fee","1 Year","320.00","1","3.2","291.20","0","2018-03-03","10","291.20","291.20","0.00","0","1","Using","admin admin","","2017-03-03");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "2","1","58","000001","Sok Chanreaksmey","Sok Chanreaksmey","","?????","4","Female Uniform (Size M)","","12.00","1","","12.00","","","0","12.00","12.00","0.00","0","1","Using","admin admin","","2017-03-03");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "3","2","4","000002","Chea Socheata","Chea Socheata","","?????","1","Tuition Fee","6 Months","165.00","1","1.65","166.65","0","2017-09-03","0","166.65","166.65","0.00","0","1","Using","admin admin","","2017-03-03");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "4","3","4","000003","Hann Nita","Hann Nita","","?????","1","Tuition Fee","6 Months","175.00","1","1.75","176.75","0","2017-09-03","0","176.75","176.75","0.00","1","1","Void","admin admin","","2017-03-03");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "5","4","4","000004","??? ?????????","Sok Dararatanak","","?????","1","Tuition Fee","6 Months","165.00","1","1.65","133.65","0","2017-09-07","20","133.65","133.65","0.00","0","1","Using","","","2017-03-07");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "6","4","12","000004","??? ?????????","Sok Dararatanak","","?????","3","?????????? (??-??)","1 Month","42.00","1","","42.00","","2017-04-07","0","42.00","42.00","0.00","0","1","Using","","","2017-03-07");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "7","4","18","000004","??? ?????????","Sok Dararatanak","","?????","3","????????????????? (??-??)","1 Month","26.00","1","","26.00","","2017-04-07","0","26.00","26.00","0.00","0","1","Using","","","2017-03-07");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "8","5","4","000005","San Dara","San Dara","","?????","1","Tuition Fee","6 Months","250.00","1","2.5","252.50","0","2017-09-10","0","252.50","252.50","0.00","0","1","Using","admin admin","","2017-03-10");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "9","6","4","000006","Sok Chanreaksmey","Sok Chanreaksmey","","?????","1","Tuition Fee","1 Month","35.00","1","0.35","35.35","0","2017-04-10","0","35.35","35.35","0.00","0","1","Using","admin admin","","2017-03-10");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "10","6","12","000006","Sok Chanreaksmey","Sok Chanreaksmey","","?????","3","?????????? (??-??)","1 Month","42.00","1","","42.00","","2017-04-10","0","42.00","42.00","0.00","0","1","Using","admin admin","","2017-03-10");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "11","6","109","000006","Sok Chanreaksmey","Sok Chanreaksmey","","?????","4","Science 3A","","10.00","1","","10.00","","","0","10.00","10.00","0.00","0","1","Using","admin admin","","2017-03-10");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "12","7","4","000007","Sanchez","Sanchez","","?????","1","Tuition Fee","6 Months","165.00","1","1.65","166.65","0","2017-09-10","0","166.65","166.65","0.00","0","1","Using","admin admin","","2017-03-10");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "13","7","18","000007","Sanchez","Sanchez","","?????","3","????????????????? (??-??)","1 Month","26.00","2","","52.00","","2017-05-10","0","52.00","52.00","0.00","0","1","Using","admin admin","","2017-03-10");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "14","8","4","000008","rhdrhdrf","drhdyrydr","","?????","1","Tuition Fee","1 Month","45.00","1","0.45","45.45","0","2017-05-01","0","45.45","45.45","0.00","0","1","Using","admin admin","","2017-03-31");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "15","8","12","000008","rhdrhdrf","drhdyrydr","","?????","3","?????????? (??-??)","1 Month","42.00","1","","42.00","","2017-05-01","0","42.00","42.00","0.00","0","1","Using","admin admin","","2017-03-31");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "16","9","4","000009","Test12","Test12","","?????","1","Tuition Fee","1 Month","35.00","1","0.35","35.35","0","2017-05-05","0","30.35","30.35","5.00","0","1","Using","admin admin","","2017-04-05");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "17","9","14","000009","Test12","Test12","","?????","3","????????? (??-??)","1 Month","32.00","1","","32.00","","2017-05-05","0","32.00","32.00","0.00","0","1","Using","admin admin","","2017-04-05");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "18","10","4","000010","Test12","Test12","","?????","1","Tuition Fee","1 Month","5.00","1","0","5.00","0","2017-05-05","0","5.00","5.00","0.00","0","1","Using","admin admin","??????????????","2017-04-05");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "19","11","4","000011","","","","?????","1","Tuition Fee","1 Month","35.00","1","0.35","35.35","0","2017-06-17","0","35.35","35.35","0.00","0","1","Using","admin admin","","2017-05-17");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "20","11","16","000011","","","","?????","3","???????? (????)","1 Month","8.00","1","","8.00","","2017-06-17","0","8.00","8.00","0.00","0","1","Using","admin admin","","2017-05-17");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "21","12","4","000012","Dan Theo","Dan Theo","","?????","2","Tuition Fee","6 Months","170.00","1","1.7","171.70","0","2017-11-17","0","171.70","171.70","0.00","0","1","Using","admin admin","Dan Theo","2017-05-17");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "22","13","4","000013","fhf","sdgsd","","?????","1","Tuition Fee","1 Month","45.00","1","0.45","45.45","0","2017-06-18","0","45.45","45.45","0.00","0","1","Using","admin admin","","2017-05-18");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "23","13","18","000013","fhf","sdgsd","","?????","3","????????????????? (??-??)","1 Month","26.00","1","","26.00","","2017-06-18","0","26.00","26.00","0.00","0","1","Using","admin admin","","2017-05-18");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "24","14","4","000014","??? ????a","Sok Thida","","????","1","Tuition Fee","6 Months","165.00","1","1.65","166.65","0","2017-11-24","0","166.65","166.65","0.00","0","1","Using","admin admin","","2017-05-24");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "25","14","14","000014","??? ????a","Sok Thida","","????","3","????????? (??-??)","1 Month","32.00","1","","32.00","","2017-06-24","0","32.00","32.00","0.00","0","1","Using","admin admin","","2017-05-24");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "26","15","4","000015","??? ????a","Sok Thida","","????","1","Tuition Fee","1 Month","40.00","1","0.4","40.40","0","2017-06-24","0","40.40","40.40","0.00","0","1","Using","admin admin","","2017-05-24");
INSERT INTO `v_getstudentpaymentdetail`  VALUES ( "27","15","18","000015","??? ????a","Sok Thida","","????","3","????????????????? (??-??)","1 Month","26.00","1","","26.00","","2017-06-24","0","26.00","26.00","0.00","0","1","Using","admin admin","","2017-05-24");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
